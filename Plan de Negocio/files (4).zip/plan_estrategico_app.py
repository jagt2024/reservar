"""
╔══════════════════════════════════════════════════════════════╗
║       Plan Estratégico de Negocio  —  Streamlit App          ║
║       Powered by Claude AI (Anthropic)                       ║
╠══════════════════════════════════════════════════════════════╣
║  INSTALACIÓN                                                 ║
║    pip install -r requirements.txt                           ║
║                                                              ║
║  CONFIGURACIÓN DE API KEY (st.secrets)                       ║
║                                                              ║
║  Local:                                                      ║
║    Crea el archivo  .streamlit/secrets.toml  con:            ║
║      ANTHROPIC_API_KEY = "sk-ant-..."                        ║
║                                                              ║
║  Streamlit Cloud (gratis):                                   ║
║    App → Settings → Secrets → agrega:                        ║
║      ANTHROPIC_API_KEY = "sk-ant-..."                        ║
║                                                              ║
║  EJECUCIÓN                                                   ║
║    streamlit run plan_estrategico_app.py                     ║
╚══════════════════════════════════════════════════════════════╝
"""

import time
import random
import string
from datetime import datetime

import streamlit as st

import anthropic


# ══════════════════════════════════════════════════════════════
# CONFIGURACIÓN DE PÁGINA
# ══════════════════════════════════════════════════════════════
st.set_page_config(
    page_title="Plan Estratégico con IA",
    page_icon="🚀",
    layout="wide",
    initial_sidebar_state="collapsed",
)


# ══════════════════════════════════════════════════════════════
# RESOLUCIÓN DE API KEY  — exclusivamente via st.secrets
# ══════════════════════════════════════════════════════════════
def resolve_api_key() -> str:
    """
    Lee la API Key únicamente desde st.secrets.
    - Local:          .streamlit/secrets.toml
    - Streamlit Cloud: App → Settings → Secrets
    Retorna la key o "" si no se encuentra.
    """
    try:
        return st.secrets.get("ANTHROPIC_API_KEY", "")
    except Exception:
        return ""


API_KEY = resolve_api_key()


def get_client() -> anthropic.Anthropic:
    """Retorna un cliente Anthropic listo para usar. Detiene la app si no hay key."""
    if not API_KEY:
        st.error(
            "⚠️ **API Key no configurada.**\n\n"
            "**Local:** crea `.streamlit/secrets.toml` con:\n"
            "```toml\nANTHROPIC_API_KEY = \"sk-ant-...\"\n```\n\n"
            "**Streamlit Cloud:** ve a *App → Settings → Secrets* y agrega la misma línea."
        )
        st.stop()
    return anthropic.Anthropic(api_key=API_KEY)


# ══════════════════════════════════════════════════════════════
# CSS
# ══════════════════════════════════════════════════════════════
st.markdown("""
<style>
    /* ── Fondo degradado ── */
    .stApp {
        background: linear-gradient(135deg, #0f172a 0%, #1e3a8a 50%, #0f172a 100%);
        color: #f1f5f9;
    }
    /* ── Sidebar ── */
    section[data-testid="stSidebar"] {
        background: rgba(15,23,42,0.90);
        border-right: 1px solid rgba(148,163,184,0.15);
    }
    /* ── Inputs ── */
    .stTextInput input,
    .stTextArea textarea {
        background: rgba(30,41,59,0.65) !important;
        border: 1.5px solid rgba(148,163,184,0.25) !important;
        color: #f1f5f9 !important;
        border-radius: 8px !important;
    }
    .stTextInput input:focus,
    .stTextArea textarea:focus {
        border-color: rgba(59,130,246,0.6) !important;
        box-shadow: 0 0 0 3px rgba(59,130,246,0.12) !important;
    }
    /* ── Botones ── */
    div.stButton > button {
        border-radius: 8px;
        font-weight: 600;
        transition: all .22s;
    }
    div.stButton > button:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 20px rgba(37,99,235,.4);
    }
    /* ── Badges ── */
    .sec-badge {
        display: inline-block;
        padding: 3px 14px;
        border-radius: 20px;
        font-size: 11px;
        font-weight: 800;
        text-transform: uppercase;
        letter-spacing: 1.2px;
        margin-bottom: 6px;
    }
    /* ── Títulos ── */
    h1, h2, h3, h4 { color: #f1f5f9 !important; }
    /* ── Ocultar chrome de Streamlit ── */
    #MainMenu { visibility: hidden; }
    footer    { visibility: hidden; }
    header    { visibility: hidden; }
    /* ── Indicador de estado de conexión ── */
    .api-status-ok  { color: #4ade80; font-size: 13px; font-weight: 600; }
    .api-status-err { color: #f87171; font-size: 13px; font-weight: 600; }
</style>
""", unsafe_allow_html=True)


# ══════════════════════════════════════════════════════════════
# ESTADO DE SESIÓN
# ══════════════════════════════════════════════════════════════
_DEFAULTS = {
    "step":           "auth",   # auth | form | generating | results
    "email":          "",
    "sent_code":      "",
    "business_name":  "",
    "business_desc":  "",
    "generated_plan": None,
    "edit_section":   None,
    "edit_content":   "",
}
for _k, _v in _DEFAULTS.items():
    if _k not in st.session_state:
        st.session_state[_k] = _v


# ══════════════════════════════════════════════════════════════
# CONSTANTES
# ══════════════════════════════════════════════════════════════
SECTIONS = [
    "Resumen Ejecutivo",
    "Mercados Objetivo",
    "Análisis Competitivo",
    "Propuesta de Valor",
    "Plan de Acción",
]

SECTION_META = {
    "Resumen Ejecutivo":    ("📋", "#3b82f6", "rgba(59,130,246,.18)",  "rgba(59,130,246,.35)"),
    "Mercados Objetivo":    ("🎯", "#a78bfa", "rgba(139,92,246,.18)",  "rgba(139,92,246,.35)"),
    "Análisis Competitivo": ("⚔️",  "#34d399", "rgba(16,185,129,.18)",  "rgba(16,185,129,.35)"),
    "Propuesta de Valor":   ("💡", "#fbbf24", "rgba(245,158,11,.18)",  "rgba(245,158,11,.35)"),
    "Plan de Acción":       ("🗺️", "#fb7185", "rgba(244,63,94,.18)",   "rgba(244,63,94,.35)"),
}

PROMPTS = {
    "Resumen Ejecutivo": """\
Eres un consultor estratégico senior. Redacta un Resumen Ejecutivo profesional para:

Negocio: {name}
Descripción: {desc}

Estructura obligatoria:
1. Contexto y oportunidad de mercado
2. Misión (1 oración clara)
3. Visión a 5 años (específica y medible)
4. 5 objetivos estratégicos con KPI y meta numérica
5. Modelo de negocio resumido (cómo genera ingresos)
6. Factores críticos de éxito

Mínimo 400 palabras. Tono ejecutivo, directo y convincente.""",

    "Mercados Objetivo": """\
Eres un analista de mercado experto. Elabora el análisis de Mercados Objetivo para:

Negocio: {name}
Descripción: {desc}

Estructura obligatoria:
1. Marco TAM-SAM-SOM con estimaciones numéricas justificadas
2. 4 segmentos prioritarios (ordenados por potencial):
   - Perfil detallado del cliente
   - Estrategia de entrada
   - Ticket promedio estimado
3. Expansión geográfica por fases (con criterios de entrada)
4. Mercado obtenible en 24 meses

Mínimo 400 palabras. Sé específico con cifras y supuestos.""",

    "Análisis Competitivo": """\
Eres un estratega competitivo. Crea el Análisis Competitivo para:

Negocio: {name}
Descripción: {desc}

Estructura obligatoria:
1. Mapa del panorama competitivo del sector
2. Categorías de competidores: directos / indirectos / sustitutos
3. Análisis 5 Fuerzas de Porter (nivel Alto/Medio/Bajo + explicación)
4. Matriz de posicionamiento (2 ejes clave del sector)
5. 4 brechas u oportunidades concretas identificadas
6. Posicionamiento competitivo recomendado y por qué es defendible

Mínimo 400 palabras. Sé analítico y orientado a decisiones.""",

    "Propuesta de Valor": """\
Eres experto en estrategia de marca y propuesta de valor. Define la PVU para:

Negocio: {name}
Descripción: {desc}

Estructura obligatoria:
1. Declaración de valor central (1 párrafo memorable)
2. 3 pilares de diferenciación (con evidencia o argumentos)
3. Value Proposition Canvas completo:
   - Trabajos del cliente (funcionales, emocionales, sociales)
   - Dolores principales (frustraciones, riesgos, obstáculos)
   - Ganancias deseadas
   - Aliviadores de dolor
   - Creadores de ganancias
4. Estrategia de mensaje por canal (web, RRSS, ventas, email)
5. Hoja de ruta para proteger y evolucionar la propuesta

Mínimo 400 palabras. Creativo pero realista.""",

    "Plan de Acción": """\
Eres consultor de implementación estratégica. Diseña el Plan de Acción para:

Negocio: {name}
Descripción: {desc}

Estructura en 3 fases:
━━ FASE 1 — Fundamentos (Meses 1–3) ━━
  • Objetivo principal
  • 6 acciones prioritarias con responsable sugerido
  • KPIs de fase y meta
  • Recursos / inversión estimada

━━ FASE 2 — Crecimiento (Meses 4–12) ━━
  (misma estructura)

━━ FASE 3 — Consolidación (Meses 13–24) ━━
  (misma estructura)

Agrega al final:
  • 4 riesgos clave con probabilidad, impacto y mitigación
  • Checklist: 10 acciones para los próximos 30 días

Mínimo 500 palabras. Práctico y accionable.""",
}


# ══════════════════════════════════════════════════════════════
# FUNCIONES DE NEGOCIO
# ══════════════════════════════════════════════════════════════
def send_mock_code(email: str) -> str:
    code = "".join(random.choices(string.digits, k=6))
    st.toast(
        f"📬 Código enviado a **{email}**: `{code}`  *(simulado — en producción se envía por email)*",
        icon="📧",
    )
    return code


def generate_section(client: anthropic.Anthropic, section: str, name: str, desc: str) -> str:
    prompt = PROMPTS[section].format(name=name, desc=desc)
    msg = client.messages.create(
        model="claude-haiku-4-5-20251001",   # Haiku: más económico para planes de pago por uso
        max_tokens=2048,
        messages=[{"role": "user", "content": prompt}],
    )
    return msg.content[0].text


def generate_html_report(plan: dict) -> str:
    date_str = datetime.fromisoformat(plan["created_at"]).strftime("%d/%m/%Y %H:%M")
    sections_html = ""
    for title, content in plan["sections"].items():
        icon = SECTION_META.get(title, ("📄",))[0]
        paragraphs = "".join(
            f"<p>{p.strip()}</p>"
            for p in content.split("\n\n") if p.strip()
        )
        sections_html += f"""
        <div class="section">
            <h2>{icon} {title}</h2>
            {paragraphs}
        </div>"""

    return f"""<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Plan Estratégico — {plan['business_name']}</title>
  <style>
    * {{ box-sizing: border-box; margin: 0; padding: 0; }}
    body {{
      font-family: 'Segoe UI', Arial, sans-serif;
      line-height: 1.8; color: #1e293b;
      max-width: 860px; margin: 0 auto; padding: 48px 28px;
      background: #fff;
    }}
    .cover {{
      text-align: center; padding: 72px 0 48px;
      border-bottom: 3px solid #2563eb; margin-bottom: 56px;
    }}
    .cover h1 {{
      font-size: 2.8em; color: #1e3a8a; margin-bottom: 12px;
    }}
    .cover .sub  {{ color: #64748b; font-size: 1.1em; }}
    .cover .date {{ color: #94a3b8; margin-top: 18px; font-size: .88em; }}
    .section {{ margin-bottom: 52px; page-break-inside: avoid; }}
    .section h2 {{
      color: #2563eb; font-size: 1.45em;
      border-bottom: 2px solid #e2e8f0;
      padding-bottom: 10px; margin-bottom: 22px;
    }}
    p {{ margin-bottom: 14px; text-align: justify; }}
    @media print {{ .cover {{ padding: 40px 0 28px; }} }}
  </style>
</head>
<body>
  <div class="cover">
    <h1>🚀 {plan['business_name']}</h1>
    <div class="sub">Plan de Negocio Estratégico · Generado con Claude AI</div>
    <div class="date">📅 {date_str}</div>
  </div>
  {sections_html}
  <hr style="margin:48px 0 24px; border:none; border-top:1px solid #e2e8f0;">
  <p style="text-align:center;color:#94a3b8;font-size:.82em;">
    Generado con <strong>Claude AI</strong> (Anthropic) · Plan Estratégico de Negocio
  </p>
</body>
</html>"""


# ══════════════════════════════════════════════════════════════
# HEADER PRINCIPAL
# ══════════════════════════════════════════════════════════════
_, hcol, _ = st.columns([1, 3, 1])
with hcol:
    # Indicador de conexión (no revela la key)
    conn_status = (
        '<span class="api-status-ok">● API conectada</span>'
        if API_KEY else
        '<span class="api-status-err">● API no configurada</span>'
    )
    st.markdown(f"""
    <div style='text-align:center; padding:8px 0 28px;'>
        <div style='display:inline-flex; align-items:center; gap:10px;
                    padding:6px 20px;
                    background:rgba(37,99,235,0.15);
                    border:1px solid rgba(37,99,235,0.35);
                    border-radius:20px; font-size:13px;
                    font-weight:700; color:#93c5fd; margin-bottom:16px;'>
            ✨ Powered by Claude AI &nbsp;·&nbsp; {conn_status}
        </div>
        <h1 style='font-size:clamp(24px,5vw,46px); font-weight:900; margin:10px 0;
                   background:linear-gradient(90deg,#93c5fd,#60a5fa);
                   -webkit-background-clip:text; -webkit-text-fill-color:transparent;'>
            Plan Estratégico de Negocio
        </h1>
        <p style='color:#94a3b8; font-size:17px; margin:0;'>
            Genera análisis estratégicos profesionales con inteligencia artificial
        </p>
    </div>
    """, unsafe_allow_html=True)


# ══════════════════════════════════════════════════════════════
# SIDEBAR  (solo info, sin campo de API Key)
# ══════════════════════════════════════════════════════════════
with st.sidebar:
    st.markdown("## ℹ️ Acerca de la app")
    st.markdown("""
Esta aplicación genera planes estratégicos completos usando **Claude AI** de Anthropic.

**Secciones generadas:**
- 📋 Resumen Ejecutivo
- 🎯 Mercados Objetivo
- ⚔️ Análisis Competitivo
- 💡 Propuesta de Valor
- 🗺️ Plan de Acción
""")
    st.divider()

    if st.session_state.step == "results":
        if st.button("🔄 Crear Nuevo Plan", use_container_width=True, type="primary"):
            for k in ["step", "business_name", "business_desc",
                      "generated_plan", "edit_section", "edit_content",
                      "sent_code", "email"]:
                st.session_state[k] = _DEFAULTS.get(k, "")
            st.rerun()

    st.divider()
    st.caption("Modelo: `claude-haiku-4-5-20251001`")
    st.caption("Tokens por sección: ~2 048")
    st.caption("[Anthropic Console](https://console.anthropic.com)")


# ══════════════════════════════════════════════════════════════
# PASO 1 — AUTENTICACIÓN
# ══════════════════════════════════════════════════════════════
if st.session_state.step == "auth":
    _, col, _ = st.columns([1, 1.5, 1])
    with col:
        with st.container(border=True):
            st.markdown("### 🔐 Acceso a la Plataforma")
            st.caption("Ingresa tu email para recibir un código de acceso de 6 dígitos.")
            st.divider()

            email_val = st.text_input(
                "📧 Email",
                placeholder="tu@empresa.com",
                key="email_input",
                value=st.session_state.email,
            )

            if not st.session_state.sent_code:
                if st.button("Enviar Código →", type="primary", use_container_width=True):
                    if not email_val or "@" not in email_val:
                        st.error("Por favor ingresa un email válido.")
                    else:
                        code = send_mock_code(email_val)
                        st.session_state.sent_code = code
                        st.session_state.email = email_val
                        st.rerun()
            else:
                st.success(f"✅ Código enviado a **{st.session_state.email}**")
                code_input = st.text_input(
                    "🔑 Código de verificación",
                    max_chars=6,
                    placeholder="000000",
                    key="code_input",
                )
                c1, c2 = st.columns(2)
                with c1:
                    if st.button("✔ Verificar", type="primary", use_container_width=True):
                        if code_input == st.session_state.sent_code:
                            st.session_state.step = "form"
                            st.success("¡Acceso concedido!")
                            time.sleep(0.5)
                            st.rerun()
                        else:
                            st.error("Código incorrecto.")
                with c2:
                    if st.button("↩ Reenviar", use_container_width=True):
                        st.session_state.sent_code = ""
                        st.rerun()


# ══════════════════════════════════════════════════════════════
# PASO 2 — FORMULARIO
# ══════════════════════════════════════════════════════════════
elif st.session_state.step == "form":
    _, col, _ = st.columns([1, 2, 1])
    with col:
        with st.container(border=True):
            st.markdown("### 🏢 Cuéntanos sobre tu Negocio")
            st.caption("Con esta información generaremos un plan estratégico completo y personalizado.")
            st.divider()

            bname = st.text_input(
                "Nombre del Negocio *",
                placeholder="Ej: EcoLogística Andina",
                value=st.session_state.business_name,
            )
            bdesc = st.text_area(
                "Descripción del Negocio *",
                placeholder=(
                    "¿Qué hace tu negocio? ¿A quién va dirigido? "
                    "¿Cuál es tu propuesta de valor? ¿En qué etapa está?..."
                ),
                value=st.session_state.business_desc,
                height=170,
            )

            chars = len(bdesc.strip())
            pct   = min(chars / 30, 1.0)
            st.progress(pct, text=f"{'🟢' if chars >= 30 else '🔴'}  {chars} / 30 caracteres mínimos")

            st.markdown("<br>", unsafe_allow_html=True)

            if st.button("✨ Generar Plan Estratégico", type="primary", use_container_width=True):
                if not bname.strip():
                    st.error("El nombre del negocio es obligatorio.")
                elif chars < 30:
                    st.error("La descripción debe tener al menos 30 caracteres.")
                else:
                    st.session_state.business_name = bname.strip()
                    st.session_state.business_desc = bdesc.strip()
                    st.session_state.step = "generating"
                    st.rerun()


# ══════════════════════════════════════════════════════════════
# PASO 2b — GENERACIÓN
# ══════════════════════════════════════════════════════════════
elif st.session_state.step == "generating":
    _, col, _ = st.columns([1, 2, 1])
    with col:
        st.markdown("""
        <div style='text-align:center; padding:32px 0 20px;'>
            <div style='font-size:60px; margin-bottom:14px;'>🧠</div>
            <h2>Generando tu Plan Estratégico</h2>
            <p style='color:#94a3b8; font-size:16px;'>
                Claude AI está analizando tu negocio y elaborando cada sección…
            </p>
        </div>""", unsafe_allow_html=True)

    bar    = st.progress(0)
    status = st.empty()
    client = get_client()
    results = {}
    n = len(SECTIONS)

    for i, section in enumerate(SECTIONS):
        icon = SECTION_META[section][0]
        status.info(f"{icon} Generando **{section}**… ({i + 1} / {n})")
        bar.progress((i + 0.5) / n)
        try:
            results[section] = generate_section(
                client, section,
                st.session_state.business_name,
                st.session_state.business_desc,
            )
        except anthropic.APIStatusError as e:
            st.error(f"❌ Error de API al generar «{section}»: {e.message}")
            st.session_state.step = "form"
            st.stop()
        except Exception as e:
            st.error(f"❌ Error inesperado al generar «{section}»: {e}")
            st.session_state.step = "form"
            st.stop()
        bar.progress((i + 1) / n)

    status.success("✅ ¡Plan generado exitosamente!")
    st.session_state.generated_plan = {
        "business_name": st.session_state.business_name,
        "business_desc": st.session_state.business_desc,
        "sections":      results,
        "created_at":    datetime.now().isoformat(),
    }
    st.session_state.step = "results"
    time.sleep(0.5)
    st.rerun()


# ══════════════════════════════════════════════════════════════
# PASO 3 — RESULTADOS
# ══════════════════════════════════════════════════════════════
elif st.session_state.step == "results" and st.session_state.generated_plan:
    plan = st.session_state.generated_plan

    # ── Cabecera ──────────────────────────────────
    c_title, c_dl = st.columns([3, 1])
    with c_title:
        st.markdown(f"## 📊 {plan['business_name']}")
        date_str = datetime.fromisoformat(plan["created_at"]).strftime("%d %b %Y  ·  %H:%M")
        st.caption(f"🕐 Generado el {date_str}")
    with c_dl:
        st.download_button(
            label="⬇️ Descargar HTML",
            data=generate_html_report(plan),
            file_name=f"plan_{plan['business_name'].replace(' ', '_').lower()}.html",
            mime="text/html",
            use_container_width=True,
            type="primary",
        )

    st.divider()

    # ── Secciones ─────────────────────────────────
    for section, content in plan["sections"].items():
        icon, color, bg, border = SECTION_META.get(section, ("📄", "#2563eb", "", ""))
        is_editing = st.session_state.edit_section == section

        # Badge colorido
        st.markdown(
            f'<span class="sec-badge" style="background:{bg};border:1px solid {border};color:{color};">'
            f'{icon}&nbsp; {section.upper()}</span>',
            unsafe_allow_html=True,
        )

        # Título + botón editar/cancelar
        h_col, b_col = st.columns([11, 1])
        with h_col:
            st.markdown(f"### {icon} {section}")
        with b_col:
            if not is_editing:
                if st.button("✏️", key=f"ed_{section}", help="Editar sección"):
                    st.session_state.edit_section = section
                    st.session_state.edit_content = content
                    st.rerun()
            else:
                if st.button("✖", key=f"cx_{section}", help="Cancelar edición"):
                    st.session_state.edit_section = None
                    st.rerun()

        # Modo edición
        if is_editing:
            new_text = st.text_area(
                label="Contenido",
                value=st.session_state.edit_content,
                height=380,
                key=f"ta_{section}",
                label_visibility="collapsed",
            )
            s_col, r_col = st.columns(2)
            with s_col:
                if st.button("💾 Guardar", key=f"sv_{section}",
                             type="primary", use_container_width=True):
                    plan["sections"][section]       = new_text
                    st.session_state.generated_plan = plan
                    st.session_state.edit_section   = None
                    st.toast(f"✅ «{section}» guardado.", icon="💾")
                    st.rerun()
            with r_col:
                if st.button("🔄 Regenerar con IA", key=f"rg_{section}",
                             use_container_width=True):
                    with st.spinner(f"Regenerando {section}…"):
                        client = get_client()
                        plan["sections"][section] = generate_section(
                            client, section,
                            plan["business_name"], plan["business_desc"],
                        )
                        st.session_state.generated_plan = plan
                        st.session_state.edit_section   = None
                    st.toast(f"✅ «{section}» regenerado.", icon="🔄")
                    st.rerun()
        else:
            st.markdown(content)

        st.divider()

    # ── Pie de página ──
    st.markdown("""
    <div style='text-align:center; padding:20px 0 40px; color:#475569; font-size:13px;'>
        Generado con <strong style='color:#60a5fa;'>Claude AI</strong> (Anthropic)
        &nbsp;·&nbsp; Plan Estratégico de Negocio
    </div>""", unsafe_allow_html=True)
