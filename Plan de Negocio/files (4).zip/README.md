# 🚀 Plan Estratégico de Negocio — Streamlit App

Generador de planes estratégicos profesionales con **Claude AI** (Anthropic).

---

## ⚡ Inicio rápido

### Requisitos
- Python 3.9+
- API Key de Anthropic → https://console.anthropic.com  
  *(el plan gratuito incluye $5 en créditos de bienvenida)*

### Instalación

```bash
pip install -r requirements.txt
```

---

## 🔑 Configuración de la API Key (st.secrets)

La app usa **exclusivamente `st.secrets`** — sin variables de entorno ni campos en la UI.

### Local
Crea la carpeta y el archivo:
```
tu-proyecto/
└── .streamlit/
    └── secrets.toml     ← créalo manualmente
```

Contenido de `secrets.toml`:
```toml
ANTHROPIC_API_KEY = "sk-ant-aqui-tu-key-real"
```

Luego ejecuta:
```bash
streamlit run plan_estrategico_app.py
```

### ☁️ Streamlit Cloud (gratis)
1. Sube el proyecto a **GitHub** (sin `secrets.toml` — ya está en `.gitignore`)
2. Ve a [share.streamlit.io](https://share.streamlit.io) e inicia sesión con GitHub
3. **New app** → selecciona tu repo y `plan_estrategico_app.py`
4. En **Advanced settings → Secrets** pega:
   ```toml
   ANTHROPIC_API_KEY = "sk-ant-aqui-tu-key-real"
   ```
5. Haz clic en **Deploy** 🚀

Tu app queda en `https://<nombre>.streamlit.app` — **100% gratuito**.

---

## ✨ Funcionalidades

| Feature | Descripción |
|---|---|
| 🔐 Auth por email | Código de 6 dígitos (simulado, enchufable a SendGrid) |
| 🧠 Generación IA | 5 secciones estratégicas con Claude Haiku |
| ✏️ Edición manual | Edita cualquier sección desde la UI |
| 🔄 Regeneración IA | Regenera una sección específica con un clic |
| ⬇️ Descarga HTML | Exporta el plan con diseño profesional |

## 📋 Secciones del plan

1. **Resumen Ejecutivo** — Misión, visión, objetivos y KPIs
2. **Mercados Objetivo** — TAM/SAM/SOM y segmentos prioritarios
3. **Análisis Competitivo** — 5 Fuerzas de Porter y brechas
4. **Propuesta de Valor** — Canvas y pilares de diferenciación
5. **Plan de Acción** — 3 fases con acciones, KPIs y riesgos

---

## 🛡️ Seguridad

- La API Key **nunca aparece en la interfaz**
- `secrets.toml` está en `.gitignore` — nunca va al repositorio
- En Streamlit Cloud los secrets se almacenan cifrados
