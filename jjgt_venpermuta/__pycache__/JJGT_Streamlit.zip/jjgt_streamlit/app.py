"""
JJGT — app.py  v2.2
Plataforma de Venta y Permuta de Vehículos · Colombia

Fixes v2.2:
  4. Guardado bidireccional: Excel descargable + Google Sheets en tiempo real
     Toda acción de escritura (publicar, eliminar, proponer permuta, marcar notif,
     editar perfil) llama a excel_sync para persistir los cambios.
"""
import io
import streamlit as st
from datetime import datetime
from PIL import Image

from data import (
    init_data, get_vehicles, get_usuarios, get_permutas_base,
    get_history_base, get_notifs_base, CHATBOT_REPLIES, load_from_xlsx,
    reconstruct_media,
)
from components import GRAD_COLORS, fmt_price, permuta_card_html
from styles import get_css
from excel_sync import (
    download_button_excel, save_and_notify, save_section_silent,
)

# ── Configuración de página ────────────────────────────────────────────────────
st.set_page_config(
    page_title="JJGT — Vehículos Colombia",
    page_icon="🚗", layout="wide",
    initial_sidebar_state="collapsed",
)
st.markdown(get_css(), unsafe_allow_html=True)

# ── Session state ──────────────────────────────────────────────────────────────
_DEFAULTS = {
    "logged_in": False, "user_name": "", "user_email": "",
    "user_phone": "", "user_city": "Bogotá",
    "page": "home", "selected_vehicle": None,
    "user_publications": [],
    "history_items": None,    # se puebla tras init_data
    "notifications": None,    # se puebla tras init_data
    "permutas": None,         # se puebla tras init_data
    "notif_count": 3,
    "active_cities": ["Bogotá", "Medellín", "Cali"],
    "dark_mode": False,
    "loyalty_points": 200, "loyalty_level": "Silver",
    "chat_messages": [],
    "notif_prefs": {"mensajes": True, "permutas": True, "visitas": True,
                    "nuevos": False, "resenas": True, "push": True},
    # ── Detalle de vehículo — sub-estados de acciones ──
    "det_action":      None,   # "whatsapp"|"llamar"|"permuta"|"compartir"|"perm_login"
    "det_edit_mode":   False,  # True cuando el formulario de edición está abierto
    "det_confirm_del": False,  # True cuando se pidió confirmación de eliminar
}
for k, v in _DEFAULTS.items():
    if k not in st.session_state:
        st.session_state[k] = v

# ── Carga de datos (Google Sheets → fallback local) ────────────────────────────
init_data()

# Inicializar listas mutables de sesión la primera vez
if st.session_state.history_items is None:
    st.session_state.history_items = list(get_history_base())
if st.session_state.notifications is None:
    st.session_state.notifications = list(get_notifs_base())
if st.session_state.permutas is None:
    st.session_state.permutas = list(get_permutas_base())


# ── Utilidades ─────────────────────────────────────────────────────────────────
def go(page: str):
    # Limpiar estados del detalle al salir de esa página
    if page != "vehicle_detail":
        st.session_state.det_action      = None
        st.session_state.det_edit_mode   = False
        st.session_state.det_confirm_del = False
    st.session_state.page = page
    st.rerun()


def _guardar_sheets(sections: list, key: str, label: str = "☁️ Guardar en Google Sheets"):
    """
    Botón de guardado. Intenta siempre guardar en Sheets sin chequear _data_source.
    Si no hay cliente disponible, save_to_sheets lo reporta con detalle.
    """
    if st.button(label, key=key, use_container_width=True, type="primary"):
        save_and_notify(
            sections=sections,
            success_msg=f"✅ Guardado en Google Sheets",
        )


def _grad(index: int):
    return GRAD_COLORS[index % len(GRAD_COLORS)]


# ══════════════════════════════════════════════════════════════════════════════
# FIX 3 — Tarjeta de vehículo NATIVA (sin HTML crudo visible)
# Usa st.container + componentes Streamlit para todo el contenido visual.
# La clave del botón incluye el prefijo de pantalla + id + posición para
# garantizar unicidad global  →  FIX 1 (DuplicateWidgetID).
# ══════════════════════════════════════════════════════════════════════════════
def vehicle_card(v: dict, btn_key: str):
    """
    Tarjeta de vehículo renderizada con componentes nativos de Streamlit.
    btn_key debe ser ÚNICO en toda la sesión para evitar DuplicateWidgetID.
    """
    c1, c2 = _grad(v.get("grad", 0))
    name    = v.get("name", "")
    model   = v.get("model", "")
    year    = v.get("year", "")
    price   = v.get("price", 0)
    city    = v.get("city", "")
    km      = v.get("km", 0)
    fuel    = v.get("fuel", "")
    rating  = v.get("rating", 0)
    tipo    = v.get("type", "venta")
    is_user = v.get("isUserPub", False)
    fotos   = v.get("fotos", [])

    TIPO_LABEL = {"venta": "🏷️ Venta", "permuta": "🔄 Permuta", "ambos": "🔄 Venta+Permuta"}
    TIPO_COLOR = {"venta": "#C41E3A",   "permuta": "#00C9A7",    "ambos": "#F5A623"}
    tc = TIPO_COLOR.get(tipo, "#C41E3A")

    with st.container(border=True):
        # Imagen / gradiente
        if fotos:
            try:
                st.image(Image.open(io.BytesIO(fotos[0]["bytes"])), use_column_width=True)
            except Exception:
                st.markdown(
                    f'<div style="background:linear-gradient(135deg,{c1},{c2});height:130px;'
                    f'border-radius:12px;display:flex;align-items:center;'
                    f'justify-content:center;font-size:40px;">🚗</div>',
                    unsafe_allow_html=True)
        else:
            st.markdown(
                f'<div style="background:linear-gradient(135deg,{c1},{c2});height:130px;'
                f'border-radius:12px;display:flex;align-items:center;'
                f'justify-content:center;font-size:40px;">🚗</div>',
                unsafe_allow_html=True)

        # Badge tipo | año
        col_badge, col_year = st.columns([3, 1])
        with col_badge:
            st.markdown(
                f'<span style="background:{tc}22;color:{tc};font-size:10px;font-weight:700;'
                f'padding:2px 9px;border-radius:8px;">{TIPO_LABEL.get(tipo, tipo)}</span>',
                unsafe_allow_html=True)
        with col_year:
            st.markdown(
                f'<div style="text-align:right;font-size:11px;color:#9999BB;">{year}</div>',
                unsafe_allow_html=True)

        # Nombre + badge "MÍO"
        tag = " 🔴" if is_user else ""
        st.markdown(f"**{name} {model}**{tag}")
        st.caption(f"📍 {city}  ·  {km:,} km  ·  ⛽ {fuel}")

        # Precio + estrellas
        pc, rc = st.columns([3, 2])
        with pc:
            st.markdown(
                f'<div style="font-size:20px;font-weight:800;color:#C41E3A;">'
                f'{fmt_price(price)}</div>', unsafe_allow_html=True)
        with rc:
            stars = "⭐" * int(rating) if rating else ""
            st.markdown(
                f'<div style="text-align:right;font-size:12px;color:#F5A623;padding-top:4px;">'
                f'{stars}</div>', unsafe_allow_html=True)

        # Botón con clave única garantizada
        if st.button("Ver detalle →", key=btn_key, use_container_width=True):
            st.session_state.selected_vehicle = v
            go("vehicle_detail")


# ══════════════════════════════════════════════════════════════════════════════
# SIDEBAR
# ══════════════════════════════════════════════════════════════════════════════
def sidebar():
    src = st.session_state.get("_data_source", "💾 Datos locales")
    with st.sidebar:
        st.markdown(f"""
        <div style="text-align:center;padding:18px 0 8px;">
            <div style="font-size:42px;font-weight:900;letter-spacing:4px;
                background:linear-gradient(135deg,#C41E3A,#F5A623);
                -webkit-background-clip:text;-webkit-text-fill-color:transparent;">JJGT</div>
            <div style="font-size:10px;color:#9999BB;letter-spacing:2px;">VEHÍCULOS · COLOMBIA</div>
            <div style="font-size:10px;color:#7B9B7B;margin-top:3px;">{src}</div>
        </div>""", unsafe_allow_html=True)
        st.divider()

        if st.session_state.logged_in:
            ini = "".join(w[0].upper() for w in st.session_state.user_name.split()[:2])
            st.markdown(f"""
            <div style="text-align:center;padding:6px 0 12px;">
                <div style="width:50px;height:50px;border-radius:25px;margin:0 auto 8px;
                    background:linear-gradient(135deg,#C41E3A,#9B1729);
                    display:flex;align-items:center;justify-content:center;
                    font-size:20px;font-weight:700;color:#fff;">{ini}</div>
                <div style="font-weight:700;font-size:14px;">{st.session_state.user_name}</div>
                <div style="font-size:11px;color:#9999BB;">{st.session_state.user_email}</div>
                <span style="background:rgba(245,166,35,.15);color:#C47D00;font-size:10px;
                    font-weight:700;padding:2px 8px;border-radius:10px;margin-top:4px;display:inline-block;">
                    ⭐ {st.session_state.loyalty_level}</span>
            </div>""", unsafe_allow_html=True)
            st.divider()

        cur = st.session_state.page
        NAV = [
            ("🏠", "Inicio",         "home"),
            ("🔍", "Explorar",       "explore"),
            ("➕", "Publicar",       "publish"),
            ("📋", "Mis avisos",     "history"),
            ("🔔", "Notificaciones", "notifications"),
            ("🔄", "Permutas",       "permutas"),
            ("💬", "Soporte",        "support"),
            ("👤", "Mi perfil",      "profile"),
        ]
        for icon, label, pid in NAV:
            badge = " 🔴" if pid == "notifications" and st.session_state.notif_count > 0 else ""
            btype = "primary" if cur == pid else "secondary"
            # KEY: "sb_{pid}"  —  único porque solo hay una barra lateral
            if st.button(f"{icon} {label}{badge}", key=f"sb_{pid}",
                         use_container_width=True, type=btype):
                go(pid)

        st.divider()
        if st.session_state.logged_in:
            if st.button("🚪 Cerrar sesión", key="sb_logout", use_container_width=True):
                st.session_state.logged_in = False
                st.session_state.user_name = ""
                go("home")
        else:
            a, b = st.columns(2)
            with a:
                if st.button("Ingresar",  key="sb_login",    use_container_width=True, type="primary"):
                    go("login")
            with b:
                if st.button("Registro",  key="sb_register", use_container_width=True):
                    go("register")

        # ── Panel de datos ────────────────────────────────────────────────────
        st.divider()
        src = st.session_state.get("_data_source", "⚠️ Sin fuente")
        src_color = ("#00C9A7" if "Sheets" in src
                     else "#F5A623" if "Excel" in src
                     else "#E53935")
        st.markdown(
            f'<div style="font-size:11px;font-weight:700;color:{src_color};'
            f'text-align:center;padding:4px 0 8px;">{src}</div>',
            unsafe_allow_html=True)

        # ── Cargar Excel local ────────────────────────────────────────────────
        with st.expander("📂 Cargar Excel (jjgt_gestion.xlsx)", expanded=False):
            st.caption("Sube un archivo .xlsx con la misma estructura del archivo jjgt_gestion.")
            uploaded = st.file_uploader(
                "Selecciona el archivo",
                type=["xlsx"],
                key="sb_xlsx_upload",
                label_visibility="collapsed",
            )
            if uploaded is not None:
                with st.spinner("📊 Cargando datos del Excel…"):
                    ok = load_from_xlsx(uploaded.read())
                if ok:
                    # Limpiar flag de carga previa para que init_data lo vea
                    st.session_state._data_loaded = False
                    n = len(st.session_state.get("_vehicles", []))
                    st.success(f"✅ {n} vehículos cargados del Excel")
                    st.rerun()

        # ── Recargar desde Sheets ─────────────────────────────────────────────
        if st.session_state.get("_gs_client") is not None:
            if st.button("🔄 Recargar desde Sheets", key="sb_reload_sheets",
                         use_container_width=True):
                # Forzar recarga limpia
                for k in ["_data_loaded","_vehicles","_usuarios","_permutas_base",
                           "_history_base","_notifs_base","history_items",
                           "notifications","permutas"]:
                    st.session_state.pop(k, None)
                st.rerun()

        # ── Guardar / Exportar ────────────────────────────────────────────────
        st.divider()
        st.markdown(
            '<div style="font-size:11px;color:#9999BB;font-weight:700;'
            'letter-spacing:1px;text-transform:uppercase;margin-bottom:6px;">'
            '💾 Guardar</div>', unsafe_allow_html=True)
        download_button_excel(
            label    = "⬇️ Exportar Excel",
            sections = None,
            key      = "sb_dl_excel",
        )
        _guardar_sheets(
            sections = None,
            key      = "sb_save_sheets",
            label    = "☁️ Guardar todo en Sheets",
        )

        st.markdown(
            '<div style="text-align:center;font-size:10px;color:#9999BB;padding-top:8px;">'
            'JJGT v4.0 · Colombia 🇨🇴</div>', unsafe_allow_html=True)


# ══════════════════════════════════════════════════════════════════════════════
# PÁGINAS
# ══════════════════════════════════════════════════════════════════════════════
def page_home():
    vehicles = get_vehicles() + st.session_state.user_publications

    # Banner
    if not st.session_state.logged_in:
        st.markdown("""
        <div style="background:linear-gradient(135deg,#1A1A2E,#2E2E5A);border-radius:20px;
                    padding:28px;margin-bottom:18px;color:#fff;position:relative;overflow:hidden;">
            <div style="position:absolute;right:-20px;top:-20px;width:120px;height:120px;
                border-radius:60px;background:rgba(196,30,58,.2);"></div>
            <div style="font-size:11px;letter-spacing:2px;color:rgba(255,255,255,.5);
                text-transform:uppercase;margin-bottom:8px;">JJGT · VEHÍCULOS COLOMBIA</div>
            <div style="font-size:32px;font-weight:900;line-height:1.1;margin-bottom:8px;">
                🚗 Compra y vende<br>sin intermediarios</div>
            <div style="font-size:13px;color:rgba(255,255,255,.65);margin-bottom:18px;">
                Miles de vehículos · Publica gratis · Permuta sin complicaciones</div>
            <div style="display:flex;gap:20px;flex-wrap:wrap;">
                <div style="text-align:center;"><div style="font-size:26px;font-weight:900;color:#F5A623;">15K+</div><div style="font-size:11px;opacity:.6;">Vehículos</div></div>
                <div style="width:1px;background:rgba(255,255,255,.15);"></div>
                <div style="text-align:center;"><div style="font-size:26px;font-weight:900;color:#00C9A7;">8.2K</div><div style="font-size:11px;opacity:.6;">Vendedores</div></div>
                <div style="width:1px;background:rgba(255,255,255,.15);"></div>
                <div style="text-align:center;"><div style="font-size:26px;font-weight:900;color:#C41E3A;">4.8★</div><div style="font-size:11px;opacity:.6;">Rating</div></div>
                <div style="width:1px;background:rgba(255,255,255,.15);"></div>
                <div style="text-align:center;"><div style="font-size:26px;font-weight:900;">100%</div><div style="font-size:11px;opacity:.6;">Gratis</div></div>
            </div>
        </div>""", unsafe_allow_html=True)
        hc1, hc2 = st.columns(2)
        with hc1:
            if st.button("🔐 Ingresar",     key="home_login",    type="primary", use_container_width=True): go("login")
        with hc2:
            if st.button("📝 Crear cuenta", key="home_register", use_container_width=True): go("register")
    else:
        h = datetime.now().hour
        greet = "Buenos días" if h < 12 else ("Buenas tardes" if h < 18 else "Buenas noches")
        first = st.session_state.user_name.split()[0]
        st.markdown(f"""
        <div style="background:linear-gradient(135deg,#C41E3A,#1A1A2E);border-radius:18px;
                    padding:22px 28px;margin-bottom:18px;color:#fff;">
            <div style="font-size:13px;opacity:.7;">{greet},</div>
            <div style="font-size:28px;font-weight:800;margin-top:2px;">{first} 👋</div>
            <div style="font-size:12px;opacity:.6;margin-top:4px;">
                🌟 {st.session_state.loyalty_level} · {st.session_state.loyalty_points} pts</div>
        </div>""", unsafe_allow_html=True)

    # KPIs
    k1, k2, k3, k4 = st.columns(4)
    kpis = [("15,234","🚗 Vehículos","#C41E3A"),("8,241","👥 Usuarios","#00C9A7"),
            ("2,847","🔄 Permutas","#F5A623"),("4.8 ⭐","Rating","#2979FF")]
    for col, (val, lbl, col_) in zip([k1,k2,k3,k4], kpis):
        with col:
            st.markdown(f"""
            <div style="background:#fff;border-radius:14px;padding:16px;text-align:center;
                box-shadow:0 4px 20px rgba(26,26,46,.07);border:1px solid #E0E0EC;">
                <div style="font-size:26px;font-weight:800;color:{col_};">{val}</div>
                <div style="font-size:11px;color:#6B6B8A;margin-top:2px;">{lbl}</div>
            </div>""", unsafe_allow_html=True)

    st.markdown("### ⚡ Acciones rápidas")
    qa = [("➕ Publicar","publish"),("🔄 Permuta","permutas"),
          ("📋 Mis avisos","history"),("💬 Soporte","support"),
          ("📝 Registro","register"),("🔍 Explorar","explore"),
          ("🔔 Alertas","notifications"),("❓ Ayuda","support")]
    for row_start in range(0, len(qa), 4):
        cols = st.columns(4)
        for i, (label, dest) in enumerate(qa[row_start:row_start+4]):
            with cols[i]:
                # KEY: "home_qa_{fila}_{columna}"  → único
                if st.button(label, key=f"home_qa_{row_start}_{i}", use_container_width=True):
                    go(dest)

    st.divider()

    # ── Vehículos destacados — FIX 3: tarjetas nativas ────────────────────
    st.markdown("### 🌟 Vehículos destacados")
    featured = vehicles[:6]
    cols = st.columns(3)
    for i, v in enumerate(featured):
        with cols[i % 3]:
            # KEY: "home_feat_{id}_{i}" — combinación id+posición → único
            vehicle_card(v, btn_key=f"home_feat_{v.get('id', i)}_{i}")

    st.divider()

    # Permutas activas
    st.markdown("### 🔄 Permutas activas")
    perm_vehs = [v for v in vehicles if v.get("type") in ("permuta", "ambos")][:4]
    cols2 = st.columns(2)
    for i, v in enumerate(perm_vehs):
        with cols2[i % 2]:
            st.markdown(permuta_card_html(v), unsafe_allow_html=True)
            if st.button("Ver detalle", key=f"home_perm_{v.get('id', i)}_{i}",
                         use_container_width=True):
                st.session_state.selected_vehicle = v
                go("vehicle_detail")


# ── Explorar ───────────────────────────────────────────────────────────────────
def page_explore():
    st.markdown("## 🔍 Explorar vehículos")
    vehicles = get_vehicles() + st.session_state.user_publications

    with st.expander("🎛️ Filtros avanzados", expanded=False):
        f1, f2, f3 = st.columns(3)
        with f1: cat  = st.selectbox("Categoría", ["Todos","Sedán","SUV","Pickup","Hatchback"], key="exp_cat")
        with f2: tipo = st.selectbox("Tipo",       ["Todos","Venta","Permuta","Ambos"],         key="exp_tipo")
        with f3: city = st.selectbox("Ciudad",
                     ["Todas","Bogotá","Medellín","Cali","Barranquilla","Bucaramanga","Pereira"], key="exp_city")
        p1, p2 = st.columns(2)
        with p1: pmin = st.number_input("Precio mín (M COP)", 0, 400, 0,   key="exp_pmin")
        with p2: pmax = st.number_input("Precio máx (M COP)", 0, 400, 400, key="exp_pmax")

    q = st.text_input("🔎 Buscar...", placeholder="Marca, modelo, ciudad...", key="exp_q")

    CAT_MAP  = {"Todos":"all","Sedán":"sedan","SUV":"suv","Pickup":"pickup","Hatchback":"hatchback"}
    TIPO_MAP = {"Todos":None,"Venta":"venta","Permuta":"permuta","Ambos":"ambos"}

    filtered = list(vehicles)
    if q:
        ql = q.lower()
        filtered = [v for v in filtered if ql in
            f"{v.get('name','')} {v.get('model','')} {v.get('year','')} {v.get('city','')}".lower()]
    c = CAT_MAP.get(cat, "all")
    if c != "all":
        filtered = [v for v in filtered if v.get("cat") == c]
    t = TIPO_MAP.get(tipo)
    if t:
        filtered = [v for v in filtered if v.get("type") == t]
    if city != "Todas":
        filtered = [v for v in filtered if v.get("city") == city]
    filtered = [v for v in filtered
                if pmin * 1_000_000 <= v.get("price", 0) <= pmax * 1_000_000]

    st.caption(f"{len(filtered)} vehículo(s) encontrado(s)")

    if not filtered:
        st.info("No se encontraron vehículos con esos filtros.")
        return

    cols = st.columns(3)
    for i, v in enumerate(filtered):
        with cols[i % 3]:
            # KEY: "exp_{id}_{i}" — único por pantalla
            vehicle_card(v, btn_key=f"exp_{v.get('id', i)}_{i}")



# ── Helper: crear notificación ─────────────────────────────────────────────────
def _add_notif(tipo: str, icon: str, title: str, desc: str,
               user: str = "", action: str = "") -> None:
    from datetime import datetime as _dt
    now = _dt.now()
    notif = {
        "id":     f"N-{int(now.timestamp()*1000)}",
        "group":  "Hoy",
        "icon":   icon,
        "tipo":   tipo,
        "title":  title,
        "desc":   desc,
        "user":   user,
        "date":   now.strftime("%d/%m/%Y"),
        "time":   now.strftime("%H:%M"),
        "unread": True,
        "action": action,
    }
    if not isinstance(st.session_state.get("notifications"), list):
        st.session_state.notifications = []
    st.session_state.notifications.insert(0, notif)
    st.session_state.notif_count = sum(
        1 for n in st.session_state.notifications if n.get("unread"))


# ── Helper: métrica HTML ────────────────────────────────────────────────────────
def _metric_card(label: str, value, color: str = "#2979FF") -> str:
    return (
        f'<div style="background:#fff;border-radius:14px;padding:16px;text-align:center;'
        f'box-shadow:0 2px 10px rgba(26,26,46,.07);border-top:3px solid {color};">'
        f'<div style="font-size:28px;font-weight:800;color:{color};">{value}</div>'
        f'<div style="font-size:12px;color:#6B6B8A;margin-top:2px;">{label}</div>'
        f'</div>'
    )


# ── Detalle de vehículo ────────────────────────────────────────────────────────
def page_vehicle_detail():
    v = st.session_state.selected_vehicle
    if not v:
        go("explore")
        return

    # Reconstruir fotos/video desde Drive si solo hay URLs
    v = reconstruct_media(v)

    pub_id  = v.get("id", "")
    name    = v.get("name",  "")
    model   = v.get("model", "")
    year    = v.get("year",  "")
    price   = v.get("price", 0)
    city    = v.get("city",  "")
    km      = v.get("km",    0)
    fuel    = v.get("fuel",  "")
    trans   = v.get("trans", "")
    color   = v.get("color", "")
    tipo    = v.get("type",  "venta")
    rating  = v.get("rating", 0)
    reviews = v.get("reviews", 0)
    desc    = v.get("desc",  "")
    fotos   = v.get("fotos", [])
    video   = v.get("video")
    is_user = v.get("isUserPub", False)
    seller  = v.get("seller", "—")
    s_phone = str(v.get("seller_phone", v.get("phone", ""))).strip()
    s_email = str(v.get("seller_email", "")).strip()
    c1g, c2g = _grad(v.get("grad", 0))

    # ── Navegación ────────────────────────────────────────────────────────────
    if st.button("← Volver", key="det_back"):
        go("explore")

    # Estados de acción (inicializados en _DEFAULTS)
    # det_action: None | "whatsapp" | "llamar" | "permuta" | "compartir" | "perm_login"
    # det_edit_mode: bool
    # det_confirm_del: bool

    # ═══════════════════════════════════════════════════════════════════════════
    # GALERÍA + INFO
    # ═══════════════════════════════════════════════════════════════════════════
    col_m, col_i = st.columns([1.2, 1])

    with col_m:
        # ── Construir lista de fuentes de imagen ──────────────────────────────
        # Prioridad: bytes en memoria → URL de Drive → placeholder
        img_sources = []   # cada item: bytes | str(url)
        for f in fotos:
            if f.get("bytes"):
                try:
                    Image.open(io.BytesIO(f["bytes"]))   # validar
                    img_sources.append(f["bytes"])
                except Exception:
                    if f.get("url"):
                        img_sources.append(f["url"])
            elif f.get("url"):
                img_sources.append(f["url"])

        # Si no hay fotos en memoria, intentar con fotos_urls directamente
        if not img_sources:
            raw_urls = (v.get("fotos_urls") or "").strip()
            for u in [x.strip() for x in raw_urls.split(",") if x.strip()]:
                img_sources.append(u)

        if img_sources:
            # Foto principal
            st.image(img_sources[0], use_column_width=True,
                     caption=f"📸 {len(img_sources)} foto{'s' if len(img_sources)>1 else ''}")
            # Miniaturas (hasta 5)
            if len(img_sources) > 1:
                ths = st.columns(min(len(img_sources), 5))
                for ti, src in enumerate(img_sources[:5]):
                    with ths[ti]:
                        st.image(src, use_column_width=True)
        else:
            st.markdown(
                f'<div style="background:linear-gradient(135deg,{c1g},{c2g});height:240px;'
                f'border-radius:16px;display:flex;align-items:center;justify-content:center;">'
                f'<div style="text-align:center;color:rgba(255,255,255,.7);">'
                f'<div style="font-size:56px;">🚗</div>'
                f'<div style="font-size:13px;margin-top:8px;">{name} {model}</div>'
                f'</div></div>', unsafe_allow_html=True)

        # ── Video ─────────────────────────────────────────────────────────────
        video_src = None
        if video:
            if video.get("bytes"):
                video_src = io.BytesIO(video["bytes"])
            elif video.get("url"):
                video_src = video["url"]
        if not video_src:
            raw_vurl = (v.get("video_url") or "").strip()
            if raw_vurl:
                video_src = raw_vurl
        if video_src:
            try:
                st.video(video_src)
            except Exception as e:
                st.caption(f"⚠️ No se pudo mostrar el video: {e}")

    with col_i:
        TIPO_L = {"venta": "🏷️ Venta", "permuta": "🔄 Permuta", "ambos": "🔄 Venta + Permuta"}
        TIPO_C = {"venta": "#C41E3A",  "permuta": "#00C9A7",    "ambos": "#F5A623"}
        tc = TIPO_C.get(tipo, "#C41E3A")
        st.markdown(
            f'<span style="background:{tc}22;color:{tc};font-size:12px;font-weight:700;'
            f'padding:4px 14px;border-radius:20px;">{TIPO_L.get(tipo,"")}</span>',
            unsafe_allow_html=True)
        st.markdown(f"## {name} {model}")
        st.caption(f"{year} · {city} · {km:,} km")
        st.markdown(
            f'<div style="font-size:34px;font-weight:900;color:#C41E3A;margin:8px 0;">'
            f'{fmt_price(price)}</div>', unsafe_allow_html=True)
        if rating:
            st.markdown(f"{'⭐'*int(rating)} **{rating}/5** ({reviews} reseñas)")

        st.markdown("**Especificaciones**")
        s1, s2 = st.columns(2)
        specs = [("📅 Año", year), ("📏 Km", f"{km:,}"), ("⛽ Comb.", fuel),
                 ("⚙️ Trans.", trans), ("🎨 Color", color), ("📍 Ciudad", city)]
        for idx, (lbl, val) in enumerate(specs):
            with (s1 if idx % 2 == 0 else s2):
                st.markdown(
                    f'<div style="background:#F4F5F7;border-radius:10px;padding:10px 14px;'
                    f'margin-bottom:8px;">'
                    f'<div style="font-size:11px;color:#6B6B8A;">{lbl}</div>'
                    f'<div style="font-weight:700;font-size:14px;">{val}</div></div>',
                    unsafe_allow_html=True)

    if desc:
        st.markdown("**📝 Descripción**")
        st.markdown(
            f'<div style="background:#F4F5F7;border-radius:12px;padding:16px;line-height:1.7;">'
            f'{desc}</div>', unsafe_allow_html=True)

    # ═══════════════════════════════════════════════════════════════════════════
    # VENDEDOR
    # ═══════════════════════════════════════════════════════════════════════════
    st.divider()
    ini = "".join(w[0].upper() for w in seller.split()[:2]) if seller not in ("—", "") else "VD"
    st.markdown("**👤 Vendedor**")
    st.markdown(f"""
    <div style="background:#fff;border-radius:16px;padding:16px;
                box-shadow:0 4px 20px rgba(26,26,46,.08);margin-bottom:14px;">
        <div style="display:flex;gap:14px;align-items:center;">
            <div style="width:50px;height:50px;border-radius:25px;flex-shrink:0;
                background:linear-gradient(135deg,#C41E3A,#9B1729);
                display:flex;align-items:center;justify-content:center;
                font-size:18px;font-weight:700;color:#fff;">{ini}</div>
            <div style="flex:1;">
                <div style="font-weight:700;font-size:15px;">{seller}</div>
                <div style="font-size:12px;color:#6B6B8A;">📍 {city} · 📱 {s_phone}</div>
            </div>
            <span style="background:rgba(0,201,167,.12);color:#00C9A7;font-size:11px;
                font-weight:700;padding:4px 10px;border-radius:8px;">✓ Verificado</span>
        </div>
    </div>""", unsafe_allow_html=True)

    # ═══════════════════════════════════════════════════════════════════════════
    # BOTONES DE ACCIÓN
    # ═══════════════════════════════════════════════════════════════════════════
    phone_clean    = "".join(c for c in s_phone if c.isdigit())
    perm_available = tipo in ("permuta", "ambos")

    bc1, bc2, bc3, bc4 = st.columns(4)
    with bc1:
        if st.button("💬 WhatsApp", key="det_wa", use_container_width=True, type="primary"):
            st.session_state.det_action = (None if st.session_state.det_action == "whatsapp"
                                           else "whatsapp")
            st.rerun()
    with bc2:
        if st.button("📞 Llamar", key="det_call", use_container_width=True):
            st.session_state.det_action = (None if st.session_state.det_action == "llamar"
                                           else "llamar")
            st.rerun()
    with bc3:
        btn_perm_label = "🔄 Permuta" if perm_available else "🔄 Sin permuta"
        if st.button(btn_perm_label, key="det_perm", use_container_width=True,
                     disabled=not perm_available):
            if not st.session_state.logged_in:
                st.session_state.det_action = "perm_login"
            else:
                st.session_state.det_action = (None if st.session_state.det_action == "permuta"
                                               else "permuta")
            st.rerun()
    with bc4:
        if st.button("📤 Compartir", key="det_share", use_container_width=True):
            st.session_state.det_action = (None if st.session_state.det_action == "compartir"
                                           else "compartir")
            st.rerun()

    # ═══════════════════════════════════════════════════════════════════════════
    # PANELES DE ACCIÓN
    # ═══════════════════════════════════════════════════════════════════════════

    # Mensaje de éxito de acciones previas (permuta enviada, etc.)
    _ok_msg = st.session_state.pop("_perm_ok", None)
    if _ok_msg:
        st.success(_ok_msg)

    # ── WhatsApp ──────────────────────────────────────────────────────────────
    if st.session_state.det_action == "whatsapp":
        with st.container(border=True):
            st.markdown("### 💬 Contactar por WhatsApp")
            wa_default = (f"Hola {seller}, vi tu {name} {model} {year} en JJGT "
                          f"por {fmt_price(price)} y me interesa. ¿Está disponible?")
            wa_msg = st.text_area("Mensaje (editable)", value=wa_default,
                                  height=90, key="det_wa_msg")
            wa_url = (f"https://wa.me/57{phone_clean}"
                      f"?text={wa_msg.replace(' ','%20').replace(chr(10),'%0A')}")
            col_wa1, col_wa2 = st.columns(2)
            with col_wa1:
                st.link_button("💬 Abrir WhatsApp", wa_url,
                               use_container_width=True, type="primary")
            with col_wa2:
                if st.button("✖ Cerrar", key="det_wa_cancel", use_container_width=True):
                    st.session_state.det_action = None
                    st.rerun()
            st.caption("Se abrirá WhatsApp Web o la app en tu dispositivo.")

    # ── Llamar ────────────────────────────────────────────────────────────────
    elif st.session_state.det_action == "llamar":
        with st.container(border=True):
            st.markdown("### 📞 Contactar por llamada")
            st.markdown(f"""
            <div style="background:#F4F5F7;border-radius:14px;padding:22px;text-align:center;">
                <div style="font-size:44px;margin-bottom:10px;">📱</div>
                <div style="font-size:24px;font-weight:800;color:#1A1A2E;letter-spacing:3px;">
                    {s_phone}</div>
                <div style="font-size:13px;color:#6B6B8A;margin-top:6px;">{seller}</div>
            </div>""", unsafe_allow_html=True)
            st.markdown("")
            cll1, cll2 = st.columns(2)
            with cll1:
                if s_phone:
                    st.link_button(f"📞 Llamar ahora", f"tel:+57{phone_clean}",
                                   use_container_width=True, type="primary")
            with cll2:
                if st.button("✖ Cerrar", key="det_call_cancel", use_container_width=True):
                    st.session_state.det_action = None
                    st.rerun()
            if s_email:
                st.caption(f"✉️ Correo: {s_email}")

    # ── Permuta — sin sesión ──────────────────────────────────────────────────
    elif st.session_state.det_action == "perm_login":
        with st.container(border=True):
            st.warning("🔐 Debes iniciar sesión para proponer o gestionar permutas.")
            pl1, pl2 = st.columns(2)
            with pl1:
                if st.button("🔐 Iniciar sesión", key="det_perm_login",
                             use_container_width=True, type="primary"):
                    go("login")
            with pl2:
                if st.button("✖ Cerrar", key="det_perm_login_cancel",
                             use_container_width=True):
                    st.session_state.det_action = None
                    st.rerun()

    # ── Permuta — con sesión ──────────────────────────────────────────────────
    elif st.session_state.det_action == "permuta":
        with st.container(border=True):
            st.markdown("### 🔄 Permuta")

            # Propuestas que tiene este vehículo como destino
            propuestas_recibidas = [
                p for p in (st.session_state.permutas or [])
                if f"{name} {model}" in p.get("veh_destino", "")
                and p.get("propietario", "") == seller
            ]

            # El dueño ve un tab extra con propuestas recibidas
            if is_user and propuestas_recibidas:
                tab_recib, tab_enviar = st.tabs([
                    f"📥 Propuestas recibidas ({len(propuestas_recibidas)})",
                    "📤 Proponer nueva"
                ])
            else:
                tab_recib  = None
                tab_enviar = st.container()

            # ── TAB: Propuestas recibidas ─────────────────────────────────────
            if tab_recib is not None:
                with tab_recib:
                    EC = {
                        "Activa":       "#00C9A7",
                        "Contraoferta": "#F5A623",
                        "Aceptada":     "#2979FF",
                        "Rechazada":    "#E53935",
                        "Pendiente":    "#9999BB",
                    }
                    for pi, p in enumerate(propuestas_recibidas):
                        ec     = EC.get(p.get("estado", "Activa"), "#6B6B8A")
                        pid_p  = str(p.get("id","")).replace("-","_")
                        estado = p.get("estado", "Activa")

                        with st.container(border=True):
                            r1, r2 = st.columns([4, 1])
                            with r1:
                                st.markdown(
                                    f"**🚗 {p.get('veh_oferta','')}**  "
                                    f"·  km: {p.get('km_oferta',0):,}  "
                                    f"·  {p.get('color_oferta','')}  "
                                    f"·  {p.get('estado_oferta','')}")
                                st.caption(
                                    f"👤 {p.get('vendedor_oferta','—')}  "
                                    f"📱 {p.get('phone_oferta','')}  "
                                    f"·  📍 {p.get('ciudad','')}  "
                                    f"·  📅 {p.get('fecha','')}")
                                val_of = p.get("valor_oferta", 0)
                                dif    = p.get("diferencia", 0)
                                st.markdown(
                                    f'<div style="display:flex;gap:16px;margin:6px 0;">'
                                    f'<div><div style="font-size:10px;color:#6B6B8A;">Ofrece</div>'
                                    f'<div style="font-weight:700;color:#1A1A2E;">'
                                    f'{fmt_price(val_of)}</div></div>'
                                    f'<div><div style="font-size:10px;color:#6B6B8A;">Diferencia</div>'
                                    f'<div style="font-weight:700;color:#C41E3A;">'
                                    f'{fmt_price(dif)}</div></div>'
                                    f'</div>', unsafe_allow_html=True)
                                if p.get("mensaje"):
                                    st.markdown(
                                        f'<div style="background:#F4F5F7;border-radius:8px;'
                                        f'padding:8px 12px;font-size:13px;font-style:italic;">'
                                        f'"{p["mensaje"]}"</div>', unsafe_allow_html=True)
                            with r2:
                                st.markdown(
                                    f'<div style="background:{ec}22;color:{ec};font-size:11px;'
                                    f'font-weight:700;padding:4px 10px;border-radius:8px;'
                                    f'text-align:center;margin-top:6px;">{estado}</div>',
                                    unsafe_allow_html=True)

                            # Acciones solo si está activa
                            if estado == "Activa":
                                ac1, ac2, ac3 = st.columns(3)
                                with ac1:
                                    if st.button("✅ Aceptar",
                                                 key=f"perm_acp_{pi}_{pid_p}",
                                                 use_container_width=True, type="primary"):
                                        p["estado"]    = "Aceptada"
                                        p["resultado"] = "Aceptada"
                                        _add_notif(
                                            tipo="Permuta", icon="✅",
                                            title=f"¡Permuta aceptada! {p.get('veh_oferta','')}",
                                            desc=(f"{seller} aceptó tu propuesta. "
                                                  f"Contacto: {s_phone}"),
                                            user=p.get("vendedor_oferta", ""),
                                            action="Ver permutas",
                                        )
                                        save_section_silent(["permutas", "notificaciones"])
                                        st.success("✅ Propuesta aceptada · Proponente notificado")
                                        st.rerun()
                                with ac2:
                                    if st.button("❌ Rechazar",
                                                 key=f"perm_rch_{pi}_{pid_p}",
                                                 use_container_width=True):
                                        p["estado"]    = "Rechazada"
                                        p["resultado"] = "Rechazada"
                                        _add_notif(
                                            tipo="Permuta", icon="❌",
                                            title=f"Permuta no aceptada: {p.get('veh_oferta','')}",
                                            desc=f"{seller} no aceptó la propuesta en este momento.",
                                            user=p.get("vendedor_oferta", ""),
                                            action="Ver permutas",
                                        )
                                        save_section_silent(["permutas", "notificaciones"])
                                        st.warning("Propuesta rechazada · Proponente notificado")
                                        st.rerun()
                                with ac3:
                                    if st.button("↩️ Contraoferta",
                                                 key=f"perm_co_{pi}_{pid_p}",
                                                 use_container_width=True):
                                        st.session_state[f"co_open_{pid_p}"] = True
                                        st.rerun()

                                # Sub-formulario contraoferta
                                if st.session_state.get(f"co_open_{pid_p}"):
                                    with st.form(f"form_co_{pid_p}"):
                                        co_dif = st.number_input(
                                            "Nueva diferencia propuesta (COP)",
                                            min_value=0, step=500_000, format="%d",
                                            key=f"co_dif_{pid_p}")
                                        co_msg = st.text_area(
                                            "Mensaje de contraoferta",
                                            placeholder="Explica tus condiciones…",
                                            height=70, key=f"co_msg_{pid_p}")
                                        if st.form_submit_button(
                                                "📤 Enviar contraoferta",
                                                use_container_width=True,
                                                type="primary"):
                                            p["estado"]     = "Contraoferta"
                                            p["diferencia"] = int(co_dif)
                                            p["mensaje"]    = (co_msg.strip()
                                                               or p.get("mensaje", ""))
                                            _add_notif(
                                                tipo="Permuta", icon="↩️",
                                                title=f"Contraoferta: {p.get('veh_oferta','')}",
                                                desc=(f"{seller} propone diferencia "
                                                      f"{fmt_price(int(co_dif))}. "
                                                      f"{co_msg[:50]}"),
                                                user=p.get("vendedor_oferta", ""),
                                                action="Ver permutas",
                                            )
                                            save_section_silent(["permutas", "notificaciones"])
                                            st.session_state.pop(f"co_open_{pid_p}", None)
                                            st.success("↩️ Contraoferta enviada")
                                            st.rerun()

            # ── TAB: Proponer permuta ─────────────────────────────────────────
            with tab_enviar:
                st.markdown(
                    f'<div style="background:rgba(0,201,167,.08);border-radius:10px;'
                    f'padding:12px 16px;margin-bottom:14px;font-size:13px;">'
                    f'Propones cambiar tu vehículo por: '
                    f'<strong>{name} {model} {year}</strong>'
                    f'&nbsp;&nbsp;·&nbsp;&nbsp;{fmt_price(price)}</div>',
                    unsafe_allow_html=True)

                with st.form("form_permuta_det", clear_on_submit=True):
                    fp1, fp2 = st.columns(2)
                    with fp1:
                        mi_veh = st.text_input(
                            "Mi vehículo (marca · modelo · año) *",
                            placeholder="Ej: Chevrolet Onix 2021",
                            key="dpf_miveh")
                        mi_valor = st.number_input(
                            "Valor estimado de mi vehículo (COP) *",
                            min_value=0, step=1_000_000, format="%d",
                            key="dpf_valor")
                        mi_km = st.number_input(
                            "Kilómetros recorridos",
                            min_value=0, step=1000, key="dpf_km")
                    with fp2:
                        mi_ciudad = st.selectbox(
                            "Ciudad del vehículo",
                            ["Bogotá","Medellín","Cali","Barranquilla",
                             "Bucaramanga","Pereira","Cartagena"],
                            key="dpf_ciudad")
                        mi_color = st.text_input(
                            "Color", placeholder="Blanco, Gris…",
                            key="dpf_color")
                        mi_estado_veh = st.selectbox(
                            "Estado del vehículo",
                            ["Excelente","Bueno","Regular","Necesita revisión"],
                            key="dpf_estado_veh")
                    mi_phone = st.text_input(
                        "Tu celular de contacto *",
                        value=st.session_state.get("user_phone",""),
                        key="dpf_phone")
                    mi_mensaje = st.text_area(
                        "Mensaje al vendedor",
                        placeholder="Describe extras, historial de mantenimiento, "
                                    "motivo del cambio…",
                        height=80, key="dpf_msg")

                    sub_perm = st.form_submit_button(
                        "📤 Enviar propuesta de permuta",
                        use_container_width=True, type="primary")

                    if sub_perm:
                        # Usar las variables locales del form (no session_state)
                        err = []
                        if not mi_veh.strip():
                            err.append("el vehículo que ofreces")
                        if mi_valor <= 0:
                            err.append("el valor estimado")
                        if not mi_phone.strip():
                            err.append("tu celular de contacto")
                        if err:
                            st.error(f"❌ Faltan campos obligatorios: {', '.join(err)}.")
                        else:
                            dif_final  = price - mi_valor
                            nueva_perm = {
                                "id":              f"P-{int(datetime.now().timestamp())}",
                                "veh_oferta":      mi_veh.strip(),
                                "vendedor_oferta": st.session_state.user_name,
                                "veh_destino":     f"{name} {model} {year}",
                                "propietario":     seller,
                                "ciudad":          mi_ciudad,
                                "valor_oferta":    int(mi_valor),
                                "diferencia":      abs(int(dif_final)),
                                "fecha":           datetime.now().strftime("%d/%m/%Y"),
                                "estado":          "Activa",
                                "resultado":       "Pendiente",
                                "mensaje":         mi_mensaje.strip() or "Sin mensaje.",
                                "km_oferta":       int(mi_km),
                                "color_oferta":    mi_color.strip(),
                                "estado_oferta":   mi_estado_veh,
                                "phone_oferta":    mi_phone.strip(),
                            }
                            st.session_state.permutas.insert(0, nueva_perm)
                            # Notificación al proponente
                            _add_notif(
                                tipo="Permuta", icon="🔄",
                                title=f"Permuta enviada — {name} {model}",
                                desc=(f"Tu propuesta fue enviada a {seller}. "
                                      f"Recibirás respuesta pronto."),
                                user=st.session_state.user_name,
                                action="Ver permutas",
                            )
                            # Notificación al dueño del vehículo
                            _add_notif(
                                tipo="Permuta", icon="📥",
                                title=f"📥 Nueva propuesta para {name} {model}",
                                desc=(f"{st.session_state.user_name} ofrece "
                                      f"{mi_veh} avaluado en "
                                      f"{fmt_price(int(mi_valor))}. ¡Revísala!"),
                                user=seller,
                                action="Ver permuta",
                            )
                            save_section_silent(["permutas","notificaciones"])
                            st.session_state.det_action = None
                            st.session_state._perm_ok = (
                                f"✅ Propuesta enviada a {seller}. "
                                f"Diferencia estimada: {fmt_price(abs(int(dif_final)))}. "
                                f"Revisa en Notificaciones o Permutas.")
                            st.rerun()

            if st.button("✖ Cerrar panel", key="det_perm_cancel",
                         use_container_width=True):
                st.session_state.det_action = None
                st.rerun()

    # ── Compartir en redes sociales ───────────────────────────────────────────
    elif st.session_state.det_action == "compartir":
        import urllib.parse as _up
        with st.container(border=True):
            st.markdown("### 📤 Compartir vehículo")

            share_title = f"{name} {model} {year} — JJGT Vehículos Colombia"
            share_body  = (f"{name} {model} {year} · {fmt_price(price)} · "
                           f"{km:,} km · {city} · {fuel}\n"
                           f"Publica y vende sin intermediarios en JJGT 🚗🇨🇴")
            share_url   = "https://jjgt.com.co"

            t_enc  = _up.quote(share_body + "\n" + share_url)
            ti_enc = _up.quote(share_title)
            u_enc  = _up.quote(share_url)

            # Texto copiable
            st.markdown("**📋 Texto del aviso**")
            st.code(share_body, language=None)

            # Grid de redes
            st.markdown("**🌐 Compartir en:**")

            REDES = [
                ("💬 WhatsApp",
                 f"https://wa.me/?text={t_enc}", "#25D366"),
                ("📘 Facebook",
                 f"https://www.facebook.com/sharer/sharer.php?u={u_enc}&quote={ti_enc}",
                 "#1877F2"),
                ("🐦 X / Twitter",
                 f"https://twitter.com/intent/tweet?text={t_enc}",
                 "#1DA1F2"),
                ("✈️ Telegram",
                 f"https://t.me/share/url?url={u_enc}&text={t_enc}",
                 "#2AABEE"),
                ("💼 LinkedIn",
                 f"https://www.linkedin.com/sharing/share-offsite/?url={u_enc}",
                 "#0A66C2"),
                ("✉️ Email",
                 f"mailto:?subject={ti_enc}&body={t_enc}",
                 "#C41E3A"),
            ]

            # Fila 1: WhatsApp · Facebook · X
            sh1, sh2, sh3 = st.columns(3)
            for col, (lbl, url_r, _c) in zip([sh1, sh2, sh3], REDES[:3]):
                with col:
                    st.link_button(lbl, url_r, use_container_width=True)

            # Fila 2: Telegram · LinkedIn · Email
            sh4, sh5, sh6 = st.columns(3)
            for col, (lbl, url_r, _c) in zip([sh4, sh5, sh6], REDES[3:]):
                with col:
                    st.link_button(lbl, url_r, use_container_width=True)

            st.divider()

            # YouTube — instrucciones
            with st.expander("📹 ¿Cómo compartir en YouTube?"):
                yt_desc = (
                    f"{share_title}\n"
                    f"Precio: {fmt_price(price)} · {km:,} km · {city}\n"
                    f"Contacto: {s_phone}\n"
                    f"Publicado en: {share_url}")
                st.markdown(
                    "YouTube no tiene enlace directo de compartir. Para publicar:\n\n"
                    "1. Descarga el video del vehículo desde el aviso.\n"
                    "2. Súbelo a tu canal de YouTube.\n"
                    "3. Copia esta descripción:")
                st.code(yt_desc, language=None)

            # QR code
            with st.expander("📱 Código QR para compartir en persona"):
                qr_url = (f"https://api.qrserver.com/v1/create-qr-code/"
                          f"?size=220x220&data={u_enc}&color=1A1A2E")
                qc1, qc2 = st.columns([1, 2])
                with qc1:
                    st.image(qr_url, width=200, caption="Escanea para ver el aviso")
                with qc2:
                    st.markdown(
                        "**Úsalo para:**\n"
                        "- Imprimir en volantes o tarjetas\n"
                        "- Mostrar en ferias de autos\n"
                        "- Compartir en reuniones\n\n"
                        "Apunta la cámara del celular al QR para abrir el aviso.")

            if st.button("✖ Cerrar", key="det_share_close", use_container_width=True):
                st.session_state.det_action = None
                st.rerun()

    # ═══════════════════════════════════════════════════════════════════════════
    # GESTIÓN DEL DUEÑO
    # ═══════════════════════════════════════════════════════════════════════════
    if is_user and st.session_state.logged_in:
        st.divider()
        st.markdown("**🔧 Gestionar mi publicación**")
        mc1, mc2, mc3 = st.columns(3)

        # ── Editar ────────────────────────────────────────────────────────────
        with mc1:
            if st.button("✏️ Editar", key="det_edit",
                         use_container_width=True, type="primary"):
                st.session_state.det_edit_mode   = not st.session_state.det_edit_mode
                st.session_state.det_confirm_del = False
                st.rerun()

        # ── Eliminar ──────────────────────────────────────────────────────────
        with mc2:
            if not st.session_state.det_confirm_del:
                if st.button("🗑️ Eliminar", key="det_del", use_container_width=True):
                    st.session_state.det_confirm_del = True
                    st.session_state.det_edit_mode   = False
                    st.rerun()
            else:
                st.error("¿Confirmas eliminar esta publicación?")
                cd1, cd2 = st.columns(2)
                with cd1:
                    if st.button("✅ Sí, eliminar", key="det_del_confirm",
                                 use_container_width=True, type="primary"):
                        st.session_state.user_publications = [
                            p for p in st.session_state.user_publications
                            if p.get("id") != pub_id]
                        st.session_state.history_items = [
                            h for h in st.session_state.history_items
                            if h.get("id") != pub_id]
                        ok = save_section_silent(["publicaciones","historial","vehiculos"])
                        st.success("✅ Eliminada" + (" · ☁️ Sheets" if ok else ""))
                        st.session_state.det_confirm_del = False
                        st.session_state.selected_vehicle = None
                        go("history")
                with cd2:
                    if st.button("❌ No, cancelar", key="det_del_cancel",
                                 use_container_width=True):
                        st.session_state.det_confirm_del = False
                        st.rerun()

        # ── Cambiar estado ────────────────────────────────────────────────────
        with mc3:
            estado_actual = v.get("estado", "Activo")
            estado_opts   = ["Activo","Pendiente","Completado","Cancelado"]
            nuevo_estado  = st.selectbox(
                "Estado", estado_opts,
                index=estado_opts.index(estado_actual)
                      if estado_actual in estado_opts else 0,
                key="det_estado_sel")
            if nuevo_estado != estado_actual:
                for p in st.session_state.user_publications:
                    if p.get("id") == pub_id:
                        p["estado"] = nuevo_estado
                for h in st.session_state.history_items:
                    if h.get("id") == pub_id:
                        h["status"] = nuevo_estado.lower()
                save_section_silent(["publicaciones","historial"])
                st.toast(f"✅ Estado: {nuevo_estado}")
                st.rerun()

        # ── Formulario edición ────────────────────────────────────────────────
        if st.session_state.det_edit_mode:
            st.markdown("---")
            st.markdown("#### ✏️ Editar publicación")
            ANIOS = [str(a) for a in range(2025, 2014, -1)]
            FUELS = ["Gasolina","Diesel","Híbrido","Eléctrico","Gas"]
            CIUDADES = ["Bogotá","Medellín","Cali","Barranquilla",
                        "Bucaramanga","Pereira","Cartagena"]

            def _idx(lst, val, default=0):
                return lst.index(str(val)) if str(val) in lst else default

            with st.form("form_edit_pub"):
                ee1, ee2 = st.columns(2)
                with ee1:
                    e_modelo = st.text_input("Modelo", value=model, key="de_modelo")
                    e_anio   = st.selectbox("Año", ANIOS,
                                            index=_idx(ANIOS, year), key="de_anio")
                    e_km     = st.number_input("Km", value=int(km),
                                               min_value=0, step=1000, key="de_km")
                    e_precio = st.number_input("Precio (COP)", value=int(price),
                                               min_value=0, step=1_000_000,
                                               format="%d", key="de_precio")
                with ee2:
                    e_comb   = st.selectbox("Combustible", FUELS,
                                            index=_idx(FUELS, fuel), key="de_comb")
                    e_trans  = st.selectbox("Transmisión", ["Automático","Manual"],
                                            index=0 if trans == "Automático" else 1,
                                            key="de_trans")
                    e_color  = st.text_input("Color", value=color, key="de_color")
                    e_ciudad = st.selectbox("Ciudad", CIUDADES,
                                            index=_idx(CIUDADES, city), key="de_ciudad")
                e_tipo  = st.selectbox("Tipo aviso",
                                       ["Venta","Permuta","Venta y Permuta"],
                                       index={"venta":0,"permuta":1,"ambos":2}.get(tipo,0),
                                       key="de_tipo")
                e_desc  = st.text_area("Descripción", value=desc,
                                       height=90, key="de_desc")
                e_phone = st.text_input("Celular", value=s_phone, key="de_phone")

                if st.form_submit_button("💾 Guardar cambios",
                                         use_container_width=True, type="primary"):
                    TIPO2 = {"Venta":"venta","Permuta":"permuta","Venta y Permuta":"ambos"}
                    cambios = {
                        "model":        e_modelo.strip(),
                        "year":         int(e_anio),
                        "km":           int(e_km),
                        "price":        int(e_precio),
                        "fuel":         e_comb,
                        "trans":        e_trans,
                        "color":        e_color.strip() or "—",
                        "city":         e_ciudad,
                        "type":         TIPO2.get(e_tipo, "venta"),
                        "desc":         e_desc.strip(),
                        "phone":        e_phone.strip(),
                        "seller_phone": e_phone.strip(),
                    }
                    for p in st.session_state.user_publications:
                        if p.get("id") == pub_id:
                            p.update(cambios)
                    for h in st.session_state.history_items:
                        if h.get("id") == pub_id and h.get("pubRef"):
                            h["pubRef"].update(cambios)
                    v.update(cambios)
                    st.session_state.selected_vehicle = v
                    ok = save_section_silent(["publicaciones","historial","vehiculos"])
                    st.success("✅ Cambios guardados" + (" · ☁️" if ok else ""))
                    st.session_state.det_edit_mode = False
                    st.rerun()

            if st.button("Cancelar edición", key="det_edit_cancel",
                         use_container_width=True):
                st.session_state.det_edit_mode = False
                st.rerun()

    # ═══════════════════════════════════════════════════════════════════════════
    # RESEÑAS
    # ═══════════════════════════════════════════════════════════════════════════
    st.divider()
    st.markdown("**⭐ Reseñas del vendedor**")
    for rname, rrat, rtext in [
        ("Carlos M.", 5, "Muy buen trato, vehículo tal como en fotos. ¡Recomendado!"),
        ("Ana G.",    4, "Proceso rápido y seguro. Respondió todos los mensajes."),
        ("Pedro L.",  5, "Excelente vendedor, papeles al día y precio justo."),
    ]:
        ri = "".join(w[0].upper() for w in rname.split()[:2])
        st.markdown(f"""
        <div style="display:flex;gap:12px;margin-bottom:12px;padding:14px;
                    background:#F4F5F7;border-radius:12px;">
            <div style="width:36px;height:36px;border-radius:18px;flex-shrink:0;
                background:linear-gradient(135deg,#C41E3A,#1A1A2E);
                display:flex;align-items:center;justify-content:center;
                font-size:13px;font-weight:700;color:#fff;">{ri}</div>
            <div>
                <div style="font-weight:700;font-size:13px;">{rname}</div>
                <div>{"⭐"*rrat}</div>
                <div style="font-size:13px;color:#6B6B8A;">{rtext}</div>
            </div>
        </div>""", unsafe_allow_html=True)



# ── Publicar ───────────────────────────────────────────────────────────────────
def page_publish():
    st.markdown("## ➕ Publicar vehículo")
    if not st.session_state.logged_in:
        st.warning("⚠️ Debes iniciar sesión para publicar.")
        c1, c2 = st.columns(2)
        with c1:
            if st.button("🔐 Ingresar",     key="pub_login",    type="primary", use_container_width=True): go("login")
        with c2:
            if st.button("📝 Registrarme",  key="pub_register", use_container_width=True): go("register")
        return

    ini = "".join(w[0].upper() for w in st.session_state.user_name.split()[:2])
    st.markdown(f"""
    <div style="background:linear-gradient(135deg,#1A1A2E,#2E2E5A);border-radius:16px;
                padding:18px;margin-bottom:20px;display:flex;gap:14px;align-items:center;">
        <div style="width:48px;height:48px;border-radius:24px;flex-shrink:0;
            background:linear-gradient(135deg,#C41E3A,#9B1729);
            display:flex;align-items:center;justify-content:center;
            font-size:18px;font-weight:700;color:#fff;">{ini}</div>
        <div style="flex:1;">
            <div style="font-size:10px;color:rgba(255,255,255,.5);text-transform:uppercase;
                letter-spacing:1px;font-weight:700;">Publicado por</div>
            <div style="font-size:16px;font-weight:700;color:#fff;">{st.session_state.user_name}</div>
            <div style="font-size:11px;color:rgba(255,255,255,.55);">
                📍 {st.session_state.user_city}</div>
        </div>
        <div style="background:rgba(0,201,167,.2);border:1px solid rgba(0,201,167,.4);
            border-radius:8px;padding:4px 10px;font-size:11px;font-weight:700;color:#00C9A7;">
            ✓ Verificado</div>
    </div>""", unsafe_allow_html=True)

    with st.form("publish_form", clear_on_submit=True):
        st.markdown("#### 📸 Fotos y video")
        mc1, mc2 = st.columns(2)
        with mc1:
            fotos_files = st.file_uploader("📷 Fotos (máx. 10)",
                type=["jpg","jpeg","png","webp"], accept_multiple_files=True, key="pub_fotos")
        with mc2:
            video_file = st.file_uploader("🎥 Video", type=["mp4","mov","avi","webm"], key="pub_video")

        if fotos_files:
            th = st.columns(min(len(fotos_files), 5))
            for pi, pf in enumerate(fotos_files[:5]):
                with th[pi]:
                    st.image(Image.open(pf), use_column_width=True,
                             caption="📌 Portada" if pi == 0 else f"Foto {pi+1}")
        if video_file:
            st.video(video_file)

        st.divider()
        st.markdown("#### 📋 Información del vehículo")
        vc1, vc2 = st.columns(2)
        with vc1:
            pub_tipo  = st.selectbox("Tipo", ["Venta","Permuta","Venta y Permuta"], key="pf_tipo")
            pub_marca = st.selectbox("Marca",
                ["Toyota","Chevrolet","Renault","Mazda","Hyundai","Kia","Ford",
                 "Volkswagen","BMW","Mercedes-Benz","Nissan","Honda","Suzuki","Jeep"], key="pf_marca")
            pub_modelo = st.text_input("Modelo *", placeholder="Ej: Corolla XEI", key="pf_modelo")
            pub_anio   = st.selectbox("Año",
                ["2025","2024","2023","2022","2021","2020","2019","2018","2017","2016"], key="pf_anio")
            pub_km     = st.number_input("Km *", 0, 500_000, step=1_000, key="pf_km")
        with vc2:
            pub_comb  = st.selectbox("Combustible", ["Gasolina","Diesel","Híbrido","Eléctrico","Gas"], key="pf_comb")
            pub_trans = st.selectbox("Transmisión", ["Automático","Manual"], key="pf_trans")
            pub_city  = st.selectbox("Ciudad",
                ["Bogotá","Medellín","Cali","Barranquilla","Bucaramanga","Pereira","Cartagena"], key="pf_city")
            pub_color = st.text_input("Color", placeholder="Blanco, Gris…", key="pf_color")
            pub_precio = st.number_input("Precio (COP) *", 0, 2_000_000_000,
                                         step=1_000_000, format="%d", key="pf_precio")
            if pub_precio > 0:
                st.markdown(f'<div style="color:#C41E3A;font-weight:700;font-size:13px;">'
                            f'$ {pub_precio/1_000_000:.1f} M</div>', unsafe_allow_html=True)
        pub_desc = st.text_area("Descripción", height=90, key="pf_desc",
                                placeholder="Describe el estado, extras, historial…")

        st.divider()
        st.markdown("#### 👤 Datos de contacto")
        cc1, cc2, cc3 = st.columns(3)
        with cc1: pub_sname  = st.text_input("Nombre",  value=st.session_state.user_name,  key="pf_sname")
        with cc2: pub_sphone = st.text_input("Celular", value=st.session_state.user_phone or "", key="pf_sphone")
        with cc3: pub_semail = st.text_input("Correo",  value=st.session_state.user_email, key="pf_semail")
        st.checkbox("✅ Contacto por WhatsApp", value=True, key="pf_wa")

        st.divider()
        submitted = st.form_submit_button("🚀 Publicar vehículo", use_container_width=True, type="primary")
        if submitted:
            errs = []
            if not pub_modelo.strip(): errs.append("Modelo")
            if pub_precio <= 0:        errs.append("Precio")
            if not fotos_files and not video_file: errs.append("Al menos una foto o video")
            if errs:
                st.error(f"❌ Campos requeridos: {', '.join(errs)}")
            else:
                fotos_data = []
                for ff in (fotos_files or [])[:10]:
                    ff.seek(0)
                    fotos_data.append({"name": ff.name, "bytes": ff.read()})
                video_data = None
                if video_file:
                    video_file.seek(0)
                    video_data = {"name": video_file.name, "bytes": video_file.read()}

                TIPO_MAP = {"Venta":"venta","Permuta":"permuta","Venta y Permuta":"ambos"}
                new_id = f"PUB-{int(datetime.now().timestamp())}"

                # ── Subir imágenes/video a Google Drive ────────────────────
                fotos_urls_csv = ""
                video_url_str  = ""
                drive_ok = False
                if st.session_state.get("_gs_client"):
                    with st.spinner("📤 Subiendo imágenes a Google Drive…"):
                        try:
                            from media_sync import upload_media
                            fotos_urls_csv, video_url_str = upload_media(
                                new_id, fotos_data, video_data)
                            drive_ok = True
                        except Exception as e_media:
                            st.warning(f"⚠️ No se pudieron subir las imágenes a Drive: {e_media}. "
                                       "Las imágenes solo estarán disponibles en esta sesión.")

                new_pub = {
                    "id": new_id, "name": pub_marca, "model": pub_modelo,
                    "year": int(pub_anio), "price": pub_precio, "km": pub_km,
                    "fuel": pub_comb, "trans": pub_trans, "city": pub_city,
                    "color": pub_color or "—", "type": TIPO_MAP.get(pub_tipo, "venta"),
                    "cat": "sedan", "rating": 0, "reviews": 0,
                    "desc": pub_desc, "seller": pub_sname,
                    "phone": pub_sphone, "seller_phone": pub_sphone, "seller_email": pub_semail,
                    "fotos": fotos_data,    # bytes en sesión para mostrar de inmediato
                    "video": video_data,
                    "fotos_urls": fotos_urls_csv,   # URLs Drive para persistencia
                    "video_url":  video_url_str,
                    "grad": 0,
                    "isUserPub": True, "fecha": datetime.now().strftime("%d/%m/%Y"),
                }
                st.session_state.user_publications.insert(0, new_pub)
                st.session_state.history_items.insert(0, {
                    "id": new_id, "name": f"{pub_marca} {pub_modelo} {pub_anio}",
                    "price": pub_precio, "date": new_pub["fecha"],
                    "status": "activo", "type": pub_tipo, "km": pub_km,
                    "seller": pub_sname, "buyer": "—", "city": pub_city,
                    "notes": "Publicación recién creada", "points": 50,
                    "pubRef": new_pub,
                })
                st.session_state.loyalty_points += 50
                st.session_state.selected_vehicle = new_pub
                # ── Guardar en Google Sheets automáticamente ───────────
                # Guardar inmediatamente en Sheets (silent, sin bloquear UI)
                ok = save_section_silent(["publicaciones", "historial", "vehiculos"])
                media_msg = " · 📸 Imágenes en Drive" if drive_ok else ""
                if ok:
                    st.success(f"🎉 ¡Publicado con éxito! +50 pts · ☁️ Guardado{media_msg}")
                else:
                    st.success("🎉 ¡Publicado con éxito! +50 pts")
                    st.warning("⚠️ No se pudo guardar en Google Sheets. "
                               "Ve a 'Mis avisos' y usa el botón '☁️ Guardar en Google Sheets'.")
                go("vehicle_detail")


# ── Mis avisos (historial) ─────────────────────────────────────────────────────
def page_history():
    st.markdown("## 📋 Mis avisos")
    if not st.session_state.logged_in:
        st.info("🔐 Inicia sesión para ver tus publicaciones.")
        if st.button("Ingresar", key="hist_login", type="primary"): go("login")
        return

    top1, top2 = st.columns([3, 1])
    with top1:
        tab_f = st.radio("Filtrar:", ["Todos","Activos","Pendientes","Cerrados"],
                         horizontal=True, key="hist_tab")
    with top2:
        if st.button("➕ Nueva publicación", key="hist_new", type="primary", use_container_width=True):
            go("publish")

    FMAP = {"Todos":None,"Activos":"activo","Pendientes":"pendiente","Cerrados":"completado"}
    sel  = FMAP[tab_f]
    items = st.session_state.history_items
    if sel:
        items = [h for h in items if h.get("status") == sel]

    if not items:
        st.markdown('<div style="text-align:center;padding:50px;color:#6B6B8A;">'
                    '<div style="font-size:40px;margin-bottom:10px;">📋</div>'
                    'Sin avisos en esta categoría</div>', unsafe_allow_html=True)
        return

    SS = {
        "activo":    ("#00C9A7","#E0FAF6","ACTIVO"),
        "pendiente": ("#F5A623","#FEF6E4","PENDIENTE"),
        "completado":("#2979FF","#E3EDFF","CERRADO"),
        "cancelled": ("#E53935","#FDEAED","CANCELADO"),
    }

    for idx, h in enumerate(items):
        sc = h.get("status","activo")
        sfg, sbg, slbl = SS.get(sc, ("#6B6B8A","#F4F5F7","ESTADO"))
        # clave segura: eliminar caracteres especiales, añadir idx para unicidad
        hkey = str(h.get("id","x")).replace("#","").replace("-","_")

        with st.container(border=True):
            r1, r2 = st.columns([4, 1])
            with r1:
                st.markdown(f"**{h.get('name','')}**")
                st.caption(f"{h.get('date','')} · {h.get('type','')} · {h.get('city','')}")
                st.markdown(f'<div style="font-size:20px;font-weight:800;color:#C41E3A;">'
                            f'{fmt_price(h.get("price",0))}</div>', unsafe_allow_html=True)
            with r2:
                st.markdown(f'<div style="background:{sbg};color:{sfg};font-size:10px;'
                            f'font-weight:700;padding:4px 10px;border-radius:8px;'
                            f'text-align:center;margin-top:6px;">{slbl}</div>',
                            unsafe_allow_html=True)

            can_edit = sc in ("activo","pendiente")
            if can_edit:
                bc1, bc2, bc3 = st.columns(3)
                with bc1:
                    # KEY: "hist_view_{hkey}_{idx}" → único
                    if st.button("👁️ Ver", key=f"hist_view_{hkey}_{idx}", use_container_width=True):
                        ref = h.get("pubRef")
                        if not ref:
                            ref = next((v for v in get_vehicles()
                                        if v.get("name","") in h.get("name","")), None)
                        if ref:
                            st.session_state.selected_vehicle = ref
                            go("vehicle_detail")
                with bc2:
                    st.button("✏️ Editar", key=f"hist_edit_{hkey}_{idx}", use_container_width=True)
                with bc3:
                    if st.button("🗑️ Eliminar", key=f"hist_del_{hkey}_{idx}", use_container_width=True):
                        hid = h.get("id")
                        st.session_state.history_items = [
                            x for x in st.session_state.history_items if x.get("id") != hid]
                        st.session_state.user_publications = [
                            p for p in st.session_state.user_publications if p.get("id") != hid]
                        ok = save_section_silent(["publicaciones", "historial", "vehiculos"])
                        if ok:
                            st.success("✅ Eliminado y guardado en Google Sheets")
                        else:
                            st.warning("⚠️ Eliminado de la sesión. Usa '☁️ Guardar' para sincronizar con Sheets.")
                        st.rerun()
            else:
                bc1, bc2 = st.columns(2)
                with bc1:
                    if st.button("👁️ Ver", key=f"hist_view2_{hkey}_{idx}", use_container_width=True):
                        ref = next((v for v in get_vehicles()
                                    if v.get("name","") in h.get("name","")), None)
                        if ref:
                            st.session_state.selected_vehicle = ref
                            go("vehicle_detail")
                with bc2:
                    st.button("🔁 Republicar", key=f"hist_rep_{hkey}_{idx}", use_container_width=True)

    # ── Guardar / Exportar historial ──────────────────────────────────────────
    st.divider()
    st.markdown("**💾 Guardar cambios**")
    hg1, hg2 = st.columns(2)
    with hg1:
        _guardar_sheets(
            sections=["historial", "publicaciones", "vehiculos"],
            key="hist_save_sheets",
            label="☁️ Guardar avisos en Google Sheets",
        )
    with hg2:
        download_button_excel(
            label    = "⬇️ Exportar avisos a Excel",
            sections = ["historial", "publicaciones"],
            key      = "hist_dl_excel",
        )


# ── Notificaciones ─────────────────────────────────────────────────────────────
def page_notifications():
    """
    Centro de notificaciones JJGT.
    Registra permutas, publicaciones, mensajes y eventos del sistema.
    """
    st.markdown("## 🔔 Notificaciones")

    notifs = st.session_state.notifications or []
    unread = [n for n in notifs if n.get("unread")]
    tipos_disponibles = sorted({n.get("tipo", "General") for n in notifs if n.get("tipo")})

    # ── Métricas resumen ──────────────────────────────────────────────────────
    m1, m2, m3, m4 = st.columns(4)
    with m1:
        st.markdown(_metric_card("Total", len(notifs), "#2979FF"), unsafe_allow_html=True)
    with m2:
        st.markdown(_metric_card("Sin leer 🔴", len(unread), "#C41E3A"), unsafe_allow_html=True)
    with m3:
        st.markdown(_metric_card("Permutas 🔄",
            sum(1 for n in notifs if n.get("tipo") == "Permuta"), "#00C9A7"),
            unsafe_allow_html=True)
    with m4:
        st.markdown(_metric_card("Sistema ⚙️",
            sum(1 for n in notifs if n.get("tipo") == "Sistema"), "#F5A623"),
            unsafe_allow_html=True)

    st.markdown("")

    # ── Barra de controles ────────────────────────────────────────────────────
    c1, c2, c3, c4 = st.columns([2, 2, 2, 2])
    with c1:
        filtro_tipo = st.selectbox(
            "Tipo", ["Todas"] + tipos_disponibles,
            key="notif_filtro_tipo", label_visibility="collapsed")
    with c2:
        filtro_lect = st.selectbox(
            "Estado", ["Todas", "Sin leer", "Leídas"],
            key="notif_filtro_lect", label_visibility="collapsed")
    with c3:
        if st.button("✓ Marcar todas leídas", key="notif_all",
                     use_container_width=True):
            for n in notifs:
                n["unread"] = False
            st.session_state.notif_count = 0
            save_section_silent(["notificaciones"])
            st.rerun()
    with c4:
        if st.button("🗑️ Borrar leídas", key="notif_del_read",
                     use_container_width=True):
            st.session_state.notifications = [n for n in notifs if n.get("unread")]
            st.session_state.notif_count = len(st.session_state.notifications)
            save_section_silent(["notificaciones"])
            st.rerun()

    # ── Filtrar ───────────────────────────────────────────────────────────────
    visibles = list(notifs)
    if filtro_tipo != "Todas":
        visibles = [n for n in visibles if n.get("tipo") == filtro_tipo]
    if filtro_lect == "Sin leer":
        visibles = [n for n in visibles if n.get("unread")]
    elif filtro_lect == "Leídas":
        visibles = [n for n in visibles if not n.get("unread")]

    if not visibles:
        st.markdown(
            '<div style="text-align:center;padding:60px 0;color:#9999BB;">'
            '<div style="font-size:52px;margin-bottom:12px;">🔔</div>'
            '<div style="font-size:16px;font-weight:600;">Sin notificaciones</div>'
            '<div style="font-size:13px;margin-top:4px;">Aquí aparecerán tus permutas,'
            ' mensajes y actividad de tus avisos.</div>'
            '</div>', unsafe_allow_html=True)
    else:
        # Agrupar cronológicamente
        ORDEN_G = ["Hoy", "Esta semana", "Anteriores"]
        groups: dict[str, list] = {}
        for n in visibles:
            groups.setdefault(n.get("group", "Anteriores"), []).append(n)

        grupos_sorted = sorted(
            groups.items(),
            key=lambda x: ORDEN_G.index(x[0]) if x[0] in ORDEN_G else 99)

        TIPO_C = {
            "Permuta":     "#00C9A7",
            "Publicación": "#2979FF",
            "Sistema":     "#F5A623",
            "Venta":       "#C41E3A",
            "Mensaje":     "#9C27B0",
            "General":     "#6B6B8A",
        }

        for grp, items in grupos_sorted:
            st.markdown(
                f'<div style="font-size:11px;font-weight:700;color:#9999BB;'
                f'text-transform:uppercase;letter-spacing:1.5px;'
                f'padding:16px 0 6px;">{grp} · {len(items)}</div>',
                unsafe_allow_html=True)

            for ni, n in enumerate(items):
                nid      = str(n.get("id", f"n{ni}")).replace("-","_").replace(".","_")
                unread_n = n.get("unread", False)
                tipo_n   = n.get("tipo", "General")
                tc       = TIPO_C.get(tipo_n, "#6B6B8A")
                bg       = "rgba(196,30,58,.03)" if unread_n else "#fff"
                border_l = f"border-left:4px solid {tc};"
                fw       = "700" if unread_n else "500"

                # Tarjeta de notificación
                st.markdown(f"""
                <div style="background:{bg};border-radius:12px;padding:14px 16px 10px;
                            margin-bottom:8px;{border_l}
                            box-shadow:0 2px 8px rgba(26,26,46,.06);">
                    <div style="display:flex;gap:12px;align-items:flex-start;">
                        <div style="font-size:24px;flex-shrink:0;padding-top:1px;">
                            {n.get("icon","🔔")}</div>
                        <div style="flex:1;min-width:0;">
                            <div style="display:flex;align-items:center;gap:8px;
                                        flex-wrap:wrap;margin-bottom:3px;">
                                <span style="font-weight:{fw};font-size:14px;color:#1A1A2E;">
                                    {n.get("title","")}</span>
                                <span style="background:{tc}22;color:{tc};font-size:10px;
                                    font-weight:700;padding:1px 8px;border-radius:20px;">
                                    {tipo_n}</span>
                                {"<span style='width:7px;height:7px;border-radius:50%;" +
                                 "background:#C41E3A;display:inline-block;'></span>" if unread_n else ""}
                            </div>
                            <div style="font-size:13px;color:#6B6B8A;line-height:1.5;">
                                {n.get("desc","")}</div>
                            <div style="font-size:11px;color:#ADADCA;margin-top:5px;">
                                🕐 {n.get("date","")} {n.get("time","")}
                                {"&nbsp;·&nbsp;<b>Sin leer</b>" if unread_n else ""}
                            </div>
                        </div>
                    </div>
                </div>""", unsafe_allow_html=True)

                # Botones de acción por notificación
                btn_a, btn_b, btn_c = st.columns([3, 3, 1])
                accion = n.get("action", "")
                with btn_a:
                    if accion in ("Ver permuta", "Ver permutas", "Ir a permutas"):
                        if st.button("🔄 Ver en Permutas",
                                     key=f"nact_{nid}_{ni}",
                                     use_container_width=True):
                            n["unread"] = False
                            st.session_state.notif_count = max(
                                0, st.session_state.notif_count - 1)
                            save_section_silent(["notificaciones"])
                            go("permutas")
                    elif accion in ("Ver aviso", "Mis avisos"):
                        if st.button("📋 Ver mis avisos",
                                     key=f"nact_{nid}_{ni}",
                                     use_container_width=True):
                            n["unread"] = False
                            go("history")
                    elif accion:
                        st.caption(f"→ {accion}")
                with btn_b:
                    if unread_n:
                        if st.button("✓ Marcar leída",
                                     key=f"nread_{nid}_{ni}",
                                     use_container_width=True):
                            n["unread"] = False
                            st.session_state.notif_count = max(
                                0, st.session_state.notif_count - 1)
                            save_section_silent(["notificaciones"])
                            st.rerun()
                with btn_c:
                    if st.button("🗑", key=f"ndel_{nid}_{ni}",
                                 use_container_width=True,
                                 help="Eliminar esta notificación"):
                        st.session_state.notifications = [
                            x for x in st.session_state.notifications
                            if x.get("id") != n.get("id")]
                        st.session_state.notif_count = sum(
                            1 for x in st.session_state.notifications
                            if x.get("unread"))
                        save_section_silent(["notificaciones"])
                        st.rerun()

    # ── Preferencias ──────────────────────────────────────────────────────────
    st.divider()
    with st.expander("⚙️ Preferencias de notificación"):
        prefs = st.session_state.notif_prefs
        p1, p2, p3 = st.columns(3)
        with p1:
            prefs["permutas"] = st.toggle("🔄 Permutas",      value=prefs.get("permutas", True),  key="np_permutas")
            prefs["mensajes"] = st.toggle("💬 Mensajes",       value=prefs.get("mensajes", True),  key="np_mensajes")
        with p2:
            prefs["visitas"]  = st.toggle("👁️ Visitas al aviso",value=prefs.get("visitas", True),  key="np_visitas")
            prefs["nuevos"]   = st.toggle("🚗 Nuevos avisos",  value=prefs.get("nuevos", False),   key="np_nuevos")
        with p3:
            prefs["resenas"]  = st.toggle("⭐ Reseñas",        value=prefs.get("resenas", True),   key="np_resenas")
            prefs["push"]     = st.toggle("📲 Notif. push",    value=prefs.get("push", True),      key="np_push")
        if st.button("💾 Guardar preferencias", key="np_save", use_container_width=True):
            st.toast("✅ Preferencias guardadas")

    # ── Persistencia ──────────────────────────────────────────────────────────
    ng1, ng2 = st.columns(2)
    with ng1:
        _guardar_sheets(sections=["notificaciones"], key="notif_save_sheets",
                        label="☁️ Guardar en Google Sheets")
    with ng2:
        download_button_excel(label="⬇️ Exportar Excel",
                              sections=["notificaciones"], key="notif_dl_excel")



# ── Soporte / chat ─────────────────────────────────────────────────────────────
def page_support():
    st.markdown("## 💬 Soporte JJGT")
    st.markdown("""
    <div style="background:linear-gradient(135deg,#C41E3A,#1A1A2E);border-radius:16px;
                padding:20px;margin-bottom:20px;text-align:center;color:#fff;">
        <div style="font-size:20px;font-weight:800;">¿Necesitas ayuda?</div>
        <div style="font-size:12px;opacity:.7;">Lun–Sáb 8:00am – 6:00pm</div>
    </div>""", unsafe_allow_html=True)

    if not st.session_state.chat_messages:
        st.session_state.chat_messages = [{
            "role": "bot",
            "text": "¡Hola! Soy el asistente de JJGT 🚗. ¿En qué puedo ayudarte?"
        }]

    for msg in st.session_state.chat_messages:
        if msg["role"] == "bot":
            st.markdown(f"""
            <div style="display:flex;gap:10px;margin-bottom:10px;">
                <div style="width:30px;height:30px;border-radius:15px;flex-shrink:0;
                    background:linear-gradient(135deg,#C41E3A,#1A1A2E);
                    display:flex;align-items:center;justify-content:center;">🚗</div>
                <div style="background:#F4F5F7;border-radius:0 12px 12px 12px;
                    padding:12px 16px;max-width:80%;font-size:14px;">{msg['text']}</div>
            </div>""", unsafe_allow_html=True)
        else:
            st.markdown(f"""
            <div style="display:flex;justify-content:flex-end;margin-bottom:10px;">
                <div style="background:linear-gradient(135deg,#C41E3A,#9B1729);color:#fff;
                    border-radius:12px 0 12px 12px;padding:12px 16px;
                    max-width:80%;font-size:14px;">{msg['text']}</div>
            </div>""", unsafe_allow_html=True)

    st.markdown("**Preguntas frecuentes:**")
    QRS = [("¿Cómo publico?","publicar"),("¿Cómo hago permuta?","permuta"),
           ("Verificar precio","precio"),("Documentos","soat"),
           ("Pagos seguros","pago"),("Hablar con agente","default")]
    qr_cols = st.columns(3)
    for i, (label, key) in enumerate(QRS):
        with qr_cols[i % 3]:
            # KEY: "chat_qr_{i}" — único por índice
            if st.button(label, key=f"chat_qr_{i}", use_container_width=True):
                st.session_state.chat_messages.append({"role":"user","text":label})
                st.session_state.chat_messages.append(
                    {"role":"bot","text":CHATBOT_REPLIES.get(key, CHATBOT_REPLIES["default"])})
                st.rerun()

    with st.form("chat_form", clear_on_submit=True):
        ci1, ci2 = st.columns([4, 1])
        with ci1: user_msg = st.text_input("Escribe…", label_visibility="collapsed", key="chat_in")
        with ci2: send = st.form_submit_button("→", use_container_width=True)
        if send and user_msg.strip():
            st.session_state.chat_messages.append({"role":"user","text":user_msg.strip()})
            found = next((k for k in CHATBOT_REPLIES if k in user_msg.lower()), "default")
            st.session_state.chat_messages.append(
                {"role":"bot","text":CHATBOT_REPLIES[found]})
            st.rerun()

    st.divider()
    st.markdown("**📚 FAQ**")
    for q, a in [
        ("¿Cómo publico un vehículo?",
         "Ve a 'Publicar' en el menú, completa los datos, agrega fotos/video y establece el precio."),
        ("¿Qué es una permuta?",
         "Es el intercambio de tu vehículo por otro, con o sin diferencia de precio."),
        ("¿Es seguro negociar en JJGT?",
         "Verificamos identidad de usuarios. Revisa en persona antes de cerrar cualquier trato."),
        ("¿Cuánto cuesta publicar?",
         "¡Completamente gratis! Hasta 3 avisos activos simultáneamente."),
        ("¿Cómo funcionan los puntos?",
         "Ganas puntos por publicar, vender e invitar amigos. Canjéalos por avisos destacados."),
    ]:
        with st.expander(q):
            st.write(a)


# ── Permutas ───────────────────────────────────────────────────────────────────
def page_permutas():
    st.markdown("## 🔄 Permutas activas")
    st.caption("Intercambios de vehículos sin intermediarios en toda Colombia.")
    vehicles = get_vehicles() + st.session_state.user_publications
    perm_vehs = [v for v in vehicles if v.get("type") in ("permuta", "ambos")]
    permutas_list = st.session_state.permutas

    k1, k2, k3 = st.columns(3)
    with k1: st.metric("🔄 Activas",     sum(1 for p in permutas_list if p.get("estado")=="Activa"))
    with k2: st.metric("✅ Completadas", sum(1 for p in permutas_list if p.get("resultado")=="Completada"))
    with k3: st.metric("🚗 Disponibles", len(perm_vehs))

    st.divider()
    t1, t2 = st.tabs(["🚗 Vehículos disponibles", "📋 Propuestas"])

    with t1:
        cols = st.columns(2)
        for i, v in enumerate(perm_vehs):
            with cols[i % 2]:
                st.markdown(permuta_card_html(v), unsafe_allow_html=True)
                pc1, pc2 = st.columns(2)
                with pc1:
                    # KEY: "perm_det_{id}_{i}" → único
                    if st.button("Ver detalle", key=f"perm_det_{v.get('id',i)}_{i}",
                                 use_container_width=True):
                        st.session_state.selected_vehicle = v
                        go("vehicle_detail")
                with pc2:
                    if st.button("Proponer", key=f"perm_prop_{v.get('id',i)}_{i}",
                                 type="primary", use_container_width=True):
                        if not st.session_state.logged_in:
                            st.error("Inicia sesión primero")
                        else:
                            nueva_perm = {
                                "id": f"P-{int(datetime.now().timestamp())}",
                                "veh_oferta": f"{v.get('name','')} {v.get('model','')}",
                                "vendedor_oferta": st.session_state.user_name,
                                "veh_destino": f"{v.get('name','')} {v.get('model','')}",
                                "propietario": v.get("seller","—"),
                                "ciudad": v.get("city","Bogotá"),
                                "valor_oferta": v.get("price",0),
                                "diferencia": 0,
                                "fecha": datetime.now().strftime("%d/%m/%Y"),
                                "estado": "Activa",
                                "mensaje": "Propuesta enviada desde la app",
                                "resultado": "Pendiente",
                            }
                            st.session_state.permutas.insert(0, nueva_perm)
                            save_section_silent(["permutas"])
                            st.success(f"✅ Propuesta enviada para {v.get('name','')} {v.get('model','')}")

    with t2:
        EC = {"Activa":"#00C9A7","Contraoferta":"#F5A623","Cerrada":"#2979FF","Cancelada":"#E53935"}
        for p in permutas_list:
            ec = EC.get(p.get("estado","Activa"),"#6B6B8A")
            with st.container(border=True):
                ra, rb = st.columns([4, 1])
                with ra:
                    st.markdown(f"**{p.get('veh_oferta','')}**  ⇄  **{p.get('veh_destino','')}**")
                    st.caption(f"🏙️ {p.get('ciudad','')} · 📅 {p.get('fecha','')} · {p.get('vendedor_oferta','')}")
                    if p.get("mensaje"):
                        st.markdown(f'*"{p["mensaje"]}"*')
                with rb:
                    st.markdown(
                        f'<div style="background:{ec}22;color:{ec};font-size:11px;'
                        f'font-weight:700;padding:4px 10px;border-radius:8px;'
                        f'text-align:center;margin-top:4px;">{p.get("estado","")}</div>',
                        unsafe_allow_html=True)
                    st.caption(fmt_price(p.get("diferencia",0)) + " dif.")

    # ── Guardar / Exportar permutas ───────────────────────────────────────────
    st.divider()
    st.markdown("**💾 Guardar cambios**")
    pg1, pg2 = st.columns(2)
    with pg1:
        _guardar_sheets(
            sections=["permutas"],
            key="perm_save_sheets",
            label="☁️ Guardar permutas en Google Sheets",
        )
    with pg2:
        download_button_excel(
            label    = "⬇️ Exportar permutas a Excel",
            sections = ["permutas"],
            key      = "perm_dl_excel",
        )


# ── Perfil ─────────────────────────────────────────────────────────────────────
def page_profile():
    if not st.session_state.logged_in:
        st.markdown("## 👤 Mi Perfil")
        st.info("🔐 Inicia sesión para ver tu perfil.")
        c1, c2 = st.columns(2)
        with c1:
            if st.button("Ingresar",     key="prof_login",    type="primary", use_container_width=True): go("login")
        with c2:
            if st.button("Crear cuenta", key="prof_register", use_container_width=True): go("register")
        return

    ini = "".join(w[0].upper() for w in st.session_state.user_name.split()[:2])
    n_av  = len(st.session_state.history_items)
    n_vt  = sum(1 for h in st.session_state.history_items if h.get("status")=="completado")
    pts   = st.session_state.loyalty_points

    st.markdown(f"""
    <div style="background:linear-gradient(135deg,#C41E3A,#1A1A2E);border-radius:20px;
                padding:28px;margin-bottom:20px;text-align:center;color:#fff;">
        <div style="width:68px;height:68px;border-radius:34px;margin:0 auto 12px;
            background:linear-gradient(135deg,#E8384F,#9B1729);
            display:flex;align-items:center;justify-content:center;
            font-size:26px;font-weight:700;">{ini}</div>
        <div style="font-size:22px;font-weight:800;">{st.session_state.user_name}</div>
        <div style="font-size:12px;opacity:.7;margin-top:2px;">{st.session_state.user_email}</div>
        <div style="display:flex;justify-content:center;gap:28px;margin-top:18px;">
            <div><div style="font-size:26px;font-weight:800;">{n_av}</div>
                 <div style="font-size:11px;opacity:.6;">Avisos</div></div>
            <div style="width:1px;background:rgba(255,255,255,.2);"></div>
            <div><div style="font-size:26px;font-weight:800;">{n_vt}</div>
                 <div style="font-size:11px;opacity:.6;">Ventas</div></div>
            <div style="width:1px;background:rgba(255,255,255,.2);"></div>
            <div><div style="font-size:26px;font-weight:800;">{pts}</div>
                 <div style="font-size:11px;opacity:.6;">Puntos</div></div>
        </div>
    </div>""", unsafe_allow_html=True)

    prog = min(pts / 500, 1.0)
    st.markdown(f"""
    <div style="background:linear-gradient(135deg,#1A1A2E,#2E2E5A);border-radius:18px;
                padding:22px;margin-bottom:20px;color:#fff;">
        <div style="font-size:11px;font-weight:700;letter-spacing:2px;color:#F5A623;">
            ⭐ MIEMBRO {st.session_state.loyalty_level.upper()}</div>
        <div style="font-size:44px;font-weight:900;margin:6px 0;">{pts} pts</div>
        <div style="display:flex;justify-content:space-between;font-size:11px;opacity:.5;margin-bottom:5px;">
            <span>Silver ({pts})</span><span>Gold (500)</span></div>
        <div style="height:8px;background:rgba(255,255,255,.1);border-radius:4px;">
            <div style="height:100%;width:{prog*100:.0f}%;border-radius:4px;
                background:linear-gradient(90deg,#F5A623,#C41E3A);"></div>
        </div>
    </div>""", unsafe_allow_html=True)

    for icon, label, pid in [
        ("👤","Mis datos","profile_mydata"),
        ("📍","Mis ciudades","profile_cities"),
        ("🔔","Notificaciones","profile_notifconfig"),
        ("🔒","Privacidad","profile_privacy"),
        ("❓","Ayuda","support"),
    ]:
        if st.button(f"{icon} {label}", key=f"prof_{pid}", use_container_width=True):
            go(pid)

    # ── Panel de guardado completo ────────────────────────────────────────────
    st.divider()
    st.markdown("**💾 Guardar y exportar datos**")
    src = st.session_state.get("_data_source","💾 Datos locales")
    color_src = "#00C9A7" if "Sheets" in src else "#F5A623"
    st.markdown(
        f'<div style="background:rgba(0,0,0,.04);border-radius:10px;'
        f'padding:10px 14px;margin-bottom:14px;font-size:12px;">'
        f'📡 Fuente: <strong style="color:{color_src}">{src}</strong></div>',
        unsafe_allow_html=True)

    # Botón SIEMPRE visible — guarda en Sheets si hay conexión
    _guardar_sheets(
        sections = None,
        key      = "prof_save_all",
        label    = "☁️ Guardar TODO en Google Sheets",
    )

    vg1, vg2 = st.columns(2)
    with vg1:
        _guardar_sheets(
            sections = ["vehiculos", "publicaciones"],
            key      = "prof_save_veh",
            label    = "🚗 Guardar Vehículos",
        )
    with vg2:
        _guardar_sheets(
            sections = ["usuarios"],
            key      = "prof_save_usr",
            label    = "👥 Guardar Usuarios",
        )

    ug1, ug2 = st.columns(2)
    with ug1:
        _guardar_sheets(
            sections = ["historial", "publicaciones"],
            key      = "prof_save_hist",
            label    = "📋 Guardar Historial",
        )
    with ug2:
        _guardar_sheets(
            sections = ["permutas"],
            key      = "prof_save_perm",
            label    = "🔄 Guardar Permutas",
        )

    eg1, eg2 = st.columns(2)
    with eg1:
        _guardar_sheets(
            sections = ["notificaciones"],
            key      = "prof_save_notif",
            label    = "🔔 Guardar Notificaciones",
        )
    with eg2:
        download_button_excel(
            label    = "⬇️ Exportar TODO a Excel",
            sections = None,
            key      = "prof_dl_all",
        )

    st.divider()
    dark = st.toggle("🌙 Modo oscuro", value=st.session_state.dark_mode, key="prof_dark")
    st.session_state.dark_mode = dark
    st.divider()
    if st.button("🚪 Cerrar sesión", key="prof_logout", use_container_width=True):
        st.session_state.logged_in = False
        st.session_state.user_name = ""
        go("home")


def page_profile_mydata():
    if st.button("← Volver", key="myd_back"): go("profile")
    st.markdown("## 👤 Mis datos")
    with st.form("myd_form"):
        c1, c2 = st.columns(2)
        with c1:
            nm = st.text_input("Nombre",  value=st.session_state.user_name,  key="myd_name")
            em = st.text_input("Correo",  value=st.session_state.user_email, key="myd_email")
            ph = st.text_input("Celular", value=st.session_state.user_phone or "", key="myd_phone")
        with c2:
            st.text_input("Documento", value="10.234.567", key="myd_doc")
            st.selectbox("Ciudad",
                ["Bogotá","Medellín","Cali","Barranquilla","Bucaramanga","Pereira"], key="myd_city")
        if st.form_submit_button("💾 Guardar datos en Google Sheets", type="primary", use_container_width=True):
            st.session_state.user_name  = nm
            st.session_state.user_email = em
            st.session_state.user_phone = ph
            # Actualizar registro del usuario en la lista
            for u in st.session_state.get("_usuarios", []):
                if u.get("correo","").lower() == st.session_state.user_email.lower():
                    u["nombre"]  = nm
                    u["correo"]  = em
                    u["celular"] = ph
                    break
            save_and_notify(
                sections=["usuarios"],
                success_msg="✅ Datos del usuario actualizados y guardados en Google Sheets",
            )


def page_profile_cities():
    if st.button("← Volver", key="cit_back"): go("profile")
    st.markdown("## 📍 Mis ciudades")
    ALL_CITIES = ["Bogotá","Medellín","Cali","Barranquilla","Bucaramanga",
                  "Pereira","Cartagena","Manizales","Ibagué","Pasto"]
    remove = []
    for city in st.session_state.active_cities:
        cc1, cc2 = st.columns([5, 1])
        with cc1:
            is_main = city == st.session_state.active_cities[0]
            st.markdown(
                f'<div style="background:#fff;border-radius:12px;padding:12px 16px;'
                f'margin-bottom:8px;border:1px solid #E0E0EC;">📍 <strong>{city}</strong>'
                f'{"  <small style=\'color:#C41E3A;\'>(Principal)</small>" if is_main else ""}'
                f'</div>', unsafe_allow_html=True)
        if not is_main:
            with cc2:
                if st.button("✕", key=f"cit_rem_{city}", use_container_width=True):
                    remove.append(city)
    for c in remove:
        st.session_state.active_cities.remove(c)
        st.rerun()

    avail = [c for c in ALL_CITIES if c not in st.session_state.active_cities]
    if avail:
        new_c = st.selectbox("Agregar ciudad", avail, key="cit_add_sel")
        if st.button("➕ Agregar", key="cit_add_btn", type="primary"):
            st.session_state.active_cities.append(new_c)
            st.rerun()


def page_profile_notifconfig():
    if st.button("← Volver", key="nc_back"): go("profile")
    st.markdown("## 🔔 Notificaciones")
    prefs = st.session_state.notif_prefs
    for k, label, desc in [
        ("mensajes","💬 Mensajes nuevos","Cuando alguien te escriba"),
        ("permutas","🔄 Propuestas de permuta","Ofertas de intercambio"),
        ("visitas", "👁️ Visitas a mis avisos","Cuántas personas ven tus publicaciones"),
        ("nuevos",  "🚗 Nuevos vehículos","En tus ciudades de interés"),
        ("resenas", "⭐ Reseñas","Cuando alguien califique tu perfil"),
        ("push",    "📱 Push","Alertas en tu dispositivo"),
    ]:
        nc1, nc2 = st.columns([5, 1])
        with nc1:  st.markdown(f"**{label}**  \n{desc}")
        with nc2:  prefs[k] = st.toggle("", value=prefs.get(k,True), key=f"nc_{k}")
    st.session_state.notif_prefs = prefs
    st.divider()
    page_notifications()


def page_profile_privacy():
    if st.button("← Volver", key="priv_back"): go("profile")
    st.markdown("## 🔒 Privacidad y seguridad")
    st.info("🛡️ Tu información es tuya. Solo compartimos lo necesario.")
    for label, default in [
        ("Mostrar mi número de celular", True),
        ("Mostrar correo electrónico",   False),
        ("Perfil público",               True),
        ("Mostrar ciudad exacta",        True),
    ]:
        st.toggle(label, value=default, key=f"priv_{label[:18].replace(' ','_')}")
    st.divider()
    c1, c2 = st.columns(2)
    with c1:
        if st.button("🔑 Cambiar contraseña", key="priv_pw",  use_container_width=True): st.success("✉️ Enlace enviado")
        if st.button("📱 Auth 2 pasos",        key="priv_2fa", use_container_width=True): st.success("✅ 2FA activado")
    with c2:
        if st.button("⬇️ Mis datos",           key="priv_dl",  use_container_width=True): st.success("📧 Recibirás info en 24h")
        if st.button("🗑️ Eliminar cuenta",     key="priv_del", use_container_width=True): st.warning("⚠️ Contacta soporte.")


# ── Login ──────────────────────────────────────────────────────────────────────
def page_login():
    _, col, _ = st.columns([1, 2, 1])
    with col:
        st.markdown("""
        <div style="text-align:center;padding:24px 0 16px;">
            <div style="font-size:56px;font-weight:900;letter-spacing:5px;
                background:linear-gradient(135deg,#C41E3A,#F5A623);
                -webkit-background-clip:text;-webkit-text-fill-color:transparent;">JJGT</div>
            <div style="font-size:11px;color:#6B6B8A;letter-spacing:2px;">VEHÍCULOS COLOMBIA</div>
        </div>""", unsafe_allow_html=True)
        st.markdown("### Ingresar a tu cuenta")
        with st.form("login_form"):
            email = st.text_input("✉️ Correo", placeholder="correo@ejemplo.com", key="lg_email")
            pw    = st.text_input("🔑 Contraseña", type="password",              key="lg_pw")
            st.checkbox("Recordarme", key="lg_rem")
            sub = st.form_submit_button("🚀 Ingresar", use_container_width=True, type="primary")
            if sub:
                if not email or not pw:
                    st.error("❌ Completa todos los campos")
                else:
                    # Buscar usuario en datos cargados
                    usuarios = get_usuarios()
                    match = next((u for u in usuarios if u.get("correo","").lower()==email.lower()), None)
                    name = match["nombre"] if match else email.split("@")[0].replace("."," ").title()
                    if match:
                        st.session_state.loyalty_points = match.get("puntos", 200)
                        st.session_state.loyalty_level  = match.get("nivel",  "Silver")
                        st.session_state.user_city      = match.get("ciudad", "Bogotá")
                        st.session_state.user_phone     = match.get("celular","")
                    st.session_state.logged_in  = True
                    st.session_state.user_name  = name
                    st.session_state.user_email = email
                    st.session_state.history_items = list(get_history_base())
                    st.session_state.notifications = list(get_notifs_base())
                    st.success(f"✅ ¡Bienvenido {name.split()[0]}!")
                    go("home")

        c1, c2 = st.columns(2)
        with c1:
            if st.button("📝 Crear cuenta",        key="lg_register", use_container_width=True): go("register")
        with c2:
            if st.button("🔓 Recuperar contraseña", key="lg_forgot",   use_container_width=True): go("forgot")
        if st.button("🏠 Inicio", key="lg_home", use_container_width=True): go("home")


# ── Registro ───────────────────────────────────────────────────────────────────
def page_register():
    _, col, _ = st.columns([1, 2, 1])
    with col:
        st.markdown("""
        <div style="text-align:center;padding:16px 0 12px;">
            <div style="font-size:44px;font-weight:900;letter-spacing:4px;
                background:linear-gradient(135deg,#C41E3A,#F5A623);
                -webkit-background-clip:text;-webkit-text-fill-color:transparent;">JJGT</div>
        </div>""", unsafe_allow_html=True)
        st.markdown("### Crear cuenta")
        with st.form("register_form"):
            name  = st.text_input("👤 Nombre *",   key="rg_name")
            phone = st.text_input("📱 Celular *",  placeholder="300 000 0000", key="rg_phone")
            email = st.text_input("✉️ Correo *",   key="rg_email")
            city  = st.selectbox("📍 Ciudad",
                ["Bogotá","Medellín","Cali","Barranquilla","Bucaramanga","Pereira","Cartagena"], key="rg_city")
            pw1   = st.text_input("🔑 Contraseña *",        type="password", key="rg_pw1")
            pw2   = st.text_input("🔑 Confirmar contraseña *", type="password", key="rg_pw2")
            terms = st.checkbox("✅ Acepto Términos y condiciones", key="rg_terms")
            sub   = st.form_submit_button("🎉 Crear cuenta", use_container_width=True, type="primary")
            if sub:
                errs = []
                if not name.strip():  errs.append("Nombre")
                if not email.strip(): errs.append("Correo")
                if not phone.strip(): errs.append("Celular")
                if not pw1:           errs.append("Contraseña")
                if pw1 != pw2:        errs.append("Las contraseñas no coinciden")
                if not terms:         errs.append("Acepta los términos")
                if errs:
                    st.error("❌ " + " · ".join(errs))
                else:
                    st.session_state.logged_in     = True
                    st.session_state.user_name     = name
                    st.session_state.user_email    = email
                    st.session_state.user_phone    = phone
                    st.session_state.user_city     = city
                    st.session_state.active_cities = [city]
                    st.session_state.history_items = []
                    st.session_state.notifications = list(get_notifs_base())
                    # Agregar nuevo usuario a la lista y guardar en Sheets
                    new_user = {
                        "id": int(datetime.now().timestamp()),
                        "nombre": name, "correo": email, "celular": phone,
                        "documento": "", "ciudad": city, "rol": "Usuario",
                        "publicaciones": 0, "ventas": 0, "puntos": 50,
                        "nivel": "Bronze",
                        "fecha_registro": datetime.now().strftime("%d/%m/%Y"),
                    }
                    usuarios_list = list(st.session_state.get("_usuarios", []))
                    usuarios_list.append(new_user)
                    st.session_state._usuarios = usuarios_list
                    save_section_silent(["usuarios"])
                    st.success(f"🎉 ¡Bienvenido {name.split()[0]}!")
                    go("home")

        c1, c2 = st.columns(2)
        with c1:
            if st.button("🔐 Ya tengo cuenta", key="rg_login", type="primary", use_container_width=True): go("login")
        with c2:
            if st.button("🏠 Inicio",           key="rg_home",                  use_container_width=True): go("home")


# ── Recuperar contraseña ───────────────────────────────────────────────────────
def page_forgot():
    _, col, _ = st.columns([1, 2, 1])
    with col:
        st.markdown("## 🔓 Recuperar contraseña")
        with st.form("forgot_form"):
            email = st.text_input("✉️ Correo electrónico", key="fg_email")
            if st.form_submit_button("📧 Enviar enlace", use_container_width=True, type="primary"):
                if email:
                    st.success("✅ Enlace enviado a tu correo")
                    go("login")
        if st.button("← Volver al login", key="fg_back"):
            go("login")


# ══════════════════════════════════════════════════════════════════════════════
# HEADER + ROUTER
# ══════════════════════════════════════════════════════════════════════════════
sidebar()

src = st.session_state.get("_data_source", "💾 Datos locales")
user_tag = f"👤 {st.session_state.user_name}" if st.session_state.logged_in else "🔐 Sin sesión"
st.markdown(f"""
<div style="background:linear-gradient(135deg,#C41E3A,#9B1729);color:#fff;
            padding:11px 20px;border-radius:14px;margin-bottom:18px;
            display:flex;align-items:center;justify-content:space-between;">
    <div>
        <span style="font-size:18px;font-weight:900;letter-spacing:3px;">🚗 JJGT</span>
        <span style="font-size:10px;opacity:.7;margin-left:10px;">VEHÍCULOS COLOMBIA</span>
    </div>
    <div style="font-size:11px;opacity:.8;text-align:right;">
        {user_tag}<br>{src}
    </div>
</div>""", unsafe_allow_html=True)

ROUTES = {
    "home":                page_home,
    "explore":             page_explore,
    "vehicle_detail":      page_vehicle_detail,
    "publish":             page_publish,
    "history":             page_history,
    "notifications":       page_notifications,
    "support":             page_support,
    "profile":             page_profile,
    "profile_mydata":      page_profile_mydata,
    "profile_cities":      page_profile_cities,
    "profile_notifconfig": page_profile_notifconfig,
    "profile_privacy":     page_profile_privacy,
    "permutas":            page_permutas,
    "login":               page_login,
    "register":            page_register,
    "forgot":              page_forgot,
    "help":                page_support,
}
ROUTES.get(st.session_state.page, page_home)()
