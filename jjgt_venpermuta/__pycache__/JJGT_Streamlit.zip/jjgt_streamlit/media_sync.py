"""
JJGT — media_sync.py  v2.0
═══════════════════════════════════════════════════════════════════════════════
Persistencia de imágenes y videos en Google Drive.

CONFIGURACIÓN (Opción A — carpeta en tu Drive personal)
────────────────────────────────────────────────────────
1. Crea una carpeta "JJGT_Media" en tu Google Drive personal.
2. Compártela con la cuenta de servicio (client_email del secrets.toml)
   con rol Editor.
3. Copia el ID de la carpeta desde la URL de Drive:
      drive.google.com/drive/folders/AQUI_ESTA_EL_ID
4. Pega ese ID en la constante DRIVE_FOLDER_ID de abajo.

FORMATO EN SHEETS (hoja 📋 PUBLICACIONES)
──────────────────────────────────────────
  "Fotos URLs" → "https://drive.google.com/uc?id=XXX,https://..."
  "Video URL"  → "https://drive.google.com/uc?id=YYY"  (vacío si no hay)
═══════════════════════════════════════════════════════════════════════════════
"""
from __future__ import annotations
import io, time, random, mimetypes
import streamlit as st
import requests

# ════════════════════════════════════════════════════════════════════════════
# ▶ CONFIGURA AQUÍ el ID de tu carpeta JJGT_Media en Google Drive
#   Ejemplo: "1A2B3C4D5E6F7G8H9I0J"
#   Lo encuentras en la URL:  drive.google.com/drive/folders/<ID>
# ════════════════════════════════════════════════════════════════════════════
DRIVE_FOLDER_ID = ""   # ← pega aquí el ID de la carpeta

# ── Retry ────────────────────────────────────────────────────────────────────
_MAX_RETRIES = 5
_BASE_DELAY  = 2.0
_MAX_DELAY   = 32.0

def _is_quota_err(e: Exception) -> bool:
    msg = str(e).lower()
    return any(x in msg for x in ["429", "quota", "rate limit", "exhausted", "too many"])

def _retry(fn, *args, **kwargs):
    """Reintenta fn(*args, **kwargs) ante errores 429/5xx con backoff exponencial."""
    delay = _BASE_DELAY
    for attempt in range(_MAX_RETRIES):
        try:
            return fn(*args, **kwargs)
        except Exception as e:
            if attempt == _MAX_RETRIES - 1:
                raise
            if _is_quota_err(e) or any(c in str(e) for c in ["500","502","503","504"]):
                time.sleep(min(delay + random.uniform(0, delay * 0.25), _MAX_DELAY))
                delay = min(delay * 2, _MAX_DELAY)
            else:
                raise


# ════════════════════════════════════════════════════════════════════════════
# CLIENTE DE DRIVE
# ════════════════════════════════════════════════════════════════════════════
def _get_drive_service():
    """
    Devuelve un servicio autenticado de Google Drive API v3.
    Reutiliza el que ya esté en session_state._drive_service.
    """
    svc = st.session_state.get("_drive_service")
    if svc is not None:
        return svc

    try:
        from googleapiclient.discovery import build
        from google.oauth2.service_account import Credentials
        from data import load_credentials_from_toml

        creds_dict, _ = load_credentials_from_toml()
        if not creds_dict:
            st.warning("⚠️ No se encontraron credenciales para Google Drive.")
            return None

        creds = Credentials.from_service_account_info(
            creds_dict,
            scopes=["https://www.googleapis.com/auth/drive"],
        )
        svc = build("drive", "v3", credentials=creds, cache_discovery=False)
        st.session_state._drive_service = svc
        return svc

    except Exception as e:
        st.warning(f"⚠️ No se pudo conectar a Google Drive: {e}")
        return None


# ════════════════════════════════════════════════════════════════════════════
# CARPETA — usa el ID fijo configurado arriba (Opción A)
# ════════════════════════════════════════════════════════════════════════════
def _get_folder_id() -> str | None:
    """
    Devuelve el ID de la carpeta JJGT_Media.
    - Si DRIVE_FOLDER_ID está configurado, lo usa directamente (Opción A).
    - Si no está configurado, muestra un error claro.
    """
    # Usar ID configurado directamente
    folder_id = DRIVE_FOLDER_ID.strip()
    if folder_id:
        return folder_id

    # Sin configurar → error claro
    st.error(
        "❌ **DRIVE_FOLDER_ID no configurado** en media_sync.py.\n\n"
        "Pasos:\n"
        "1. Crea la carpeta `JJGT_Media` en tu Google Drive.\n"
        "2. Compártela con la cuenta de servicio (campo `client_email` del secrets.toml).\n"
        "3. Copia el ID desde la URL de Drive y pégalo en `DRIVE_FOLDER_ID` en media_sync.py."
    )
    return None


# ════════════════════════════════════════════════════════════════════════════
# SUBIR UN ARCHIVO A DRIVE
# ════════════════════════════════════════════════════════════════════════════
def upload_file(file_bytes: bytes, filename: str, folder_id: str, svc) -> str | None:
    """
    Sube file_bytes a la carpeta folder_id con el nombre filename.
    Devuelve la URL de descarga directa o None si falla.
    """
    try:
        from googleapiclient.http import MediaIoBaseUpload

        mime  = mimetypes.guess_type(filename)[0] or "application/octet-stream"
        media = MediaIoBaseUpload(io.BytesIO(file_bytes), mimetype=mime, resumable=False)
        meta  = {"name": filename, "parents": [folder_id]}

        # Subir archivo
        file_id = _retry(
            svc.files().create(body=meta, media_body=media, fields="id").execute
        )["id"]

        # Dar acceso público de lectura (anyone with link)
        _retry(
            svc.permissions().create(
                fileId=file_id,
                body={"type": "anyone", "role": "reader"},
                fields="id",
            ).execute
        )

        return f"https://drive.google.com/uc?id={file_id}&export=download"

    except Exception as e:
        st.warning(f"⚠️ Error subiendo '{filename}' a Drive: {e}")
        return None


# ════════════════════════════════════════════════════════════════════════════
# API PÚBLICA
# ════════════════════════════════════════════════════════════════════════════
def upload_media(pub_id: str,
                 fotos: list[dict],
                 video: dict | None) -> tuple[str, str]:
    """
    Sube fotos y video de una publicación a Google Drive.

    Parámetros
    ----------
    pub_id : ID de la publicación  (ej: "PUB-1234567890")
    fotos  : lista de {"name": str, "bytes": bytes}
    video  : {"name": str, "bytes": bytes}  o  None

    Retorna
    -------
    (fotos_urls_csv, video_url)
      fotos_urls_csv → "url1,url2,..."  (vacío si falló)
      video_url      → "url"            (vacío si no hay o falló)
    """
    svc = _get_drive_service()
    if not svc:
        return "", ""

    folder_id = _get_folder_id()
    if not folder_id:
        return "", ""

    foto_urls = []
    for i, f in enumerate(fotos or []):
        url = upload_file(
            f["bytes"],
            f"{pub_id}_foto{i:02d}_{f['name']}",
            folder_id,
            svc,
        )
        if url:
            foto_urls.append(url)
        time.sleep(0.3)   # pequeña pausa entre subidas

    video_url = ""
    if video:
        url = upload_file(
            video["bytes"],
            f"{pub_id}_video_{video['name']}",
            folder_id,
            svc,
        )
        if url:
            video_url = url

    return ",".join(foto_urls), video_url


def load_media_from_urls(fotos_csv: str, video_url: str) -> tuple[list[dict], dict | None]:
    """
    Descarga los archivos desde las URLs de Drive y reconstruye
    los dicts {"name", "bytes", "url"} que espera el resto de la app.
    Usa caché en session_state._media_cache para no re-descargar en cada rerun.
    """
    cache = st.session_state.setdefault("_media_cache", {})

    def _download(url: str) -> bytes | None:
        if url in cache:
            return cache[url]
        try:
            r = requests.get(url, timeout=20)
            if r.status_code == 200:
                cache[url] = r.content
                return r.content
        except Exception:
            pass
        return None

    fotos = []
    for url in [u.strip() for u in fotos_csv.split(",") if u.strip()]:
        data = _download(url)
        if data:
            name = url.split("id=")[-1].split("&")[0] + ".jpg"
            fotos.append({"name": name, "bytes": data, "url": url})

    video = None
    vurl  = (video_url or "").strip()
    if vurl:
        data = _download(vurl)
        if data:
            video = {"name": "video.mp4", "bytes": data, "url": vurl}

    return fotos, video
