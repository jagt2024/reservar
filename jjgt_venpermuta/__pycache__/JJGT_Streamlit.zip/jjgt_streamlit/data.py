"""
JJGT — data.py  v3.0
Carga datos desde Google Sheets (jjgt_gestion).
Fallback automático a datos estáticos si no hay conexión.
"""
import os, json, time, random, gspread, pandas as pd, streamlit as st
from google.oauth2.service_account import Credentials

# ════════════════════════════════════════════════════════════════════════════
# RETRY CON BACKOFF EXPONENCIAL — manejo del error 429 (Quota exceeded)
# ════════════════════════════════════════════════════════════════════════════
_MAX_RETRIES = 6
_BASE_DELAY  = 2.0
_MAX_DELAY   = 64.0

def _is_quota_err(e: Exception) -> bool:
    msg = str(e).lower()
    return any(x in msg for x in ["429","quota","rate limit","exhausted","too many"])

def _api_call(fn, *args, **kwargs):
    """
    Envuelve cualquier llamada a la API de Google Sheets con reintentos
    automáticos ante errores 429 (Quota exceeded) o 5xx.

    Backoff exponencial con jitter:
      intento 1 → ~2s · 2 → ~4s · 3 → ~8s · 4 → ~16s · 5 → ~32s · 6 → error
    """
    delay = _BASE_DELAY
    for attempt in range(_MAX_RETRIES):
        try:
            return fn(*args, **kwargs)
        except Exception as e:
            if attempt == _MAX_RETRIES - 1:
                raise
            recoverable = _is_quota_err(e) or any(
                c in str(e) for c in ["500","502","503","504"])
            if recoverable:
                jitter = random.uniform(0, delay * 0.25)
                time.sleep(min(delay + jitter, _MAX_DELAY))
                delay  = min(delay * 2, _MAX_DELAY)
            else:
                raise

# ── Nombres de hojas ──────────────────────────────────────────────────────────
SHEET_FILE = "jjgt_gestion"
WS_VEH     = "🚗 VEHÍCULOS"
WS_USR     = "👥 USUARIOS"
WS_PERM    = "🔄 PERMUTAS"
WS_PUB     = "📋 PUBLICACIONES"
WS_HIST    = "📦 HISTORIAL"
WS_NOTIF   = "🔔 NOTIFICACIONES"

_SCOPES = [
    "https://spreadsheets.google.com/feeds",
    "https://www.googleapis.com/auth/drive",
]

# ── Helpers ───────────────────────────────────────────────────────────────────
def _int(v, d=0):
    try:    return int(float(str(v).replace(",","").replace("$","").strip() or d))
    except: return d

def _float(v, d=0.0):
    try:    return float(str(v).replace(",",".").strip() or d)
    except: return d

def _tipo(s):
    t = str(s).lower()
    return "ambos" if ("venta" in t and "permuta" in t) else ("permuta" if "permuta" in t else "venta")

def _cat(nombre, modelo):
    txt = f"{nombre} {modelo}".lower()
    if any(x in txt for x in ["hilux","ranger","oroch","frontier","l200"]): return "pickup"
    if any(x in txt for x in ["tracker","tucson","cx-5","cx5","sportage","explorer",
                                "wrangler","tiguan","ecosport","sorento","duster suv"]): return "suv"
    if any(x in txt for x in ["golf","sandero","stepway","swift","polo",
                                "mazda 2","mazda2","spark","picanto","hb20"]): return "hatchback"
    return "sedan"

GRAD_N = 15

# ════════════════════════════════════════════════════════════════════════════
# CREDENCIALES — lee st.secrets primero, luego secrets.toml como fallback
# ════════════════════════════════════════════════════════════════════════════
def load_credentials_from_toml():
    """
    Obtiene las credenciales de servicio de Google.
    Orden de búsqueda:
      1. st.secrets["sheetsemp"]["credentials_sheet"]  (Streamlit Cloud / local con secrets.toml)
      2. Archivo .streamlit/secrets.toml leído manualmente con toml
      3. None si no se encuentra nada
    Devuelve (dict_credenciales, None)
    """
    # ── Intento 1: st.secrets (funciona tanto en Cloud como en local) ─────────
    try:
        raw = st.secrets["sheetsemp"]["credentials_sheet"]
        if isinstance(raw, str):
            creds = json.loads(raw)
        else:
            # st.secrets devuelve AttrDict → convertir a dict plano
            creds = dict(raw)
        # Validar que tenga las claves mínimas de una service account
        if "private_key" in creds and "client_email" in creds:
            return creds, None
    except Exception:
        pass   # st.secrets no disponible o clave no existe → probar con toml

    # ── Intento 2: leer secrets.toml directamente ─────────────────────────────
    # Buscar el archivo en varias ubicaciones posibles
    toml_candidates = [
        ".streamlit/secrets.toml",
        os.path.join(os.path.dirname(os.path.abspath(__file__)), ".streamlit", "secrets.toml"),
        os.path.expanduser("~/.streamlit/secrets.toml"),
    ]
    for toml_path in toml_candidates:
        if not os.path.isfile(toml_path):
            continue
        try:
            import toml as toml_lib
            config = toml_lib.load(toml_path)
            raw = config.get("sheetsemp", {}).get("credentials_sheet")
            if raw is None:
                continue
            if isinstance(raw, str):
                creds = json.loads(raw)
            else:
                creds = dict(raw)
            if "private_key" in creds and "client_email" in creds:
                return creds, None
        except Exception:
            continue

    return None, None


# ════════════════════════════════════════════════════════════════════════════
# CONEXIÓN — sin @st.cache_resource para evitar problemas de hasheo con dicts
# ════════════════════════════════════════════════════════════════════════════
def get_google_sheets_connection(creds: dict):
    """
    Crea y devuelve un cliente gspread autenticado.
    No usa @st.cache_resource porque los dicts/AttrDicts no son hasheables.
    El cliente se guarda manualmente en st.session_state._gs_client.
    """
    try:
        # Si ya hay un cliente vivo en session_state, reutilizarlo
        existing = st.session_state.get("_gs_client")
        if existing is not None:
            return existing

        credentials = Credentials.from_service_account_info(creds, scopes=_SCOPES)
        client = gspread.authorize(credentials)
        st.session_state._gs_client = client   # guardar para futuras escrituras
        return client
    except Exception as e:
        st.error(f"❌ Error conectando a Google Sheets: {e}")
        return None


# ════════════════════════════════════════════════════════════════════════════
# CARGA DE UNA HOJA — robusto, sin get_all_records
# ════════════════════════════════════════════════════════════════════════════
def _parse_sheet_values(all_values: list) -> pd.DataFrame:
    """Convierte lista de listas (get_all_values) en DataFrame limpio."""
    if not all_values or len(all_values) < 2:
        return pd.DataFrame()
    raw_headers = all_values[0]
    headers, seen = [], {}
    for h in raw_headers:
        h = str(h).strip()
        if not h:
            h = f"_col{len(headers)}"
        if h in seen:
            seen[h] += 1
            h = f"{h}_{seen[h]}"
        else:
            seen[h] = 0
        headers.append(h)
    data_rows = []
    for row in all_values[1:]:
        padded = (row + [""] * len(headers))[:len(headers)]
        if any(str(v).strip() for v in padded):
            data_rows.append(padded)
    return pd.DataFrame(data_rows, columns=headers)


def load_data_from_sheet(client, sheet_name: str, worksheet_name: str) -> pd.DataFrame:
    """
    Carga una hoja usando get_all_values() con reintentos automáticos ante 429.
    """
    try:
        sheet     = _api_call(client.open, sheet_name)
        worksheet = _api_call(sheet.worksheet, worksheet_name)
        all_values = _api_call(worksheet.get_all_values)
        return _parse_sheet_values(all_values)

    except gspread.exceptions.WorksheetNotFound:
        st.warning(f"⚠️ Hoja '{worksheet_name}' no existe en '{sheet_name}'.")
        return pd.DataFrame()
    except Exception as e:
        if _is_quota_err(e):
            st.warning(
                f"⚠️ Límite de solicitudes alcanzado al cargar '{worksheet_name}'. "
                f"La API de Google Sheets permite 60 lecturas/minuto. "
                f"Espera un momento y recarga la página.")
        else:
            st.warning(f"⚠️ Error cargando '{worksheet_name}': {e}")
        return pd.DataFrame()


# ════════════════════════════════════════════════════════════════════════════
# TRANSFORMADORES  DataFrame → listas internas
# ════════════════════════════════════════════════════════════════════════════
def _df_to_vehicles(df: pd.DataFrame) -> list:
    """Lee hoja de vehículos — acepta nombres de columna con o sin tilde."""
    def g(row, *keys, default=""):
        for k in keys:
            v = row.get(k)
            if v is not None and str(v).strip() not in ("", "nan", "None"):
                return v
        return default

    out = []
    for i, row in df.iterrows():
        n = str(g(row, "Nombre", default="")).strip()
        if not n or n.upper().startswith("TOTAL"):
            continue
        m = str(g(row, "Modelo", default="")).strip()
        out.append({
            "id":           _int(g(row, "ID", default=i + 1)),
            "name":         n,
            "model":        m,
            "year":         _int(g(row, "Año", "Ano", default=2022)),
            "price":        _int(g(row, "Precio (COP)", "Precio", default=0)),
            "km":           _int(g(row, "Km", default=0)),
            "fuel":         str(g(row, "Combustible", default="Gasolina")),
            "trans":        str(g(row, "Transmisión", "Transmision", default="Automático")),
            "city":         str(g(row, "Ciudad", default="Bogotá")),
            "color":        str(g(row, "Color", default="—")),
            "type":         _tipo(g(row, "Tipo Aviso", default="Venta")),
            "cat":          _cat(n, m),
            "rating":       _float(g(row, "Calificación", "Calificacion", default=4.5)),
            "reviews":      _int(g(row, "Reseñas", "Resenas", default=0)),
            "estado":       str(g(row, "Estado", default="Activo")),
            "desc":         str(g(row, "Descripción", "Descripcion", default="")),
            "seller":       str(g(row, "Vendedor", default="—")),
            "phone":        str(g(row, "Celular Vendedor", "Celular", default="")),
            "seller_phone": str(g(row, "Celular Vendedor", "Celular", default="")),
            "seller_email": str(g(row, "Correo Vendedor", "Correo", default="")),
            "grad":         i % GRAD_N,
            "fotos_urls":   str(g(row, "Fotos URLs", default="")),
            "video_url":    str(g(row, "Video URL",  default="")),
            "fotos":        [],     # se reconstruye lazy en page_vehicle_detail
            "video":        None,   # idem
            "isUserPub":    False,
        })
    return out


def _df_to_history(df: pd.DataFrame) -> list:
    STATUS_MAP = {
        "activo": "activo", "pendiente": "pendiente",
        "completado": "completado", "cancelado": "cancelled", "cerrado": "completado",
    }
    out = []
    for _, row in df.iterrows():
        hid = str(row.get("ID", "")).strip()
        if not hid or hid.upper() in ("ID", "TOTALES"):
            continue
        raw_est = str(row.get("Estado", "activo")).strip().lower()
        out.append({
            "id":     hid,
            "name":   str(row.get("Vehículo", row.get("Vehiculo", ""))),
            "price":  _int(row.get("Precio Final", row.get("Precio", 0))),
            "date":   str(row.get("Fecha", "—")),
            "status": STATUS_MAP.get(raw_est, "activo"),
            "type":   str(row.get("Tipo", "Publicación")),
            "km":     0,
            "seller": str(row.get("Vendedor", "—")),
            "buyer":  str(row.get("Comprador / Permutante", row.get("Comprador", "—"))),
            "city":   str(row.get("Ciudad", "Bogotá")),
            "notes":  str(row.get("Notas", "—")),
            "points": _int(row.get("Puntos Generados", 0)),
        })
    return out


def _df_to_notifications(df: pd.DataFrame) -> list:
    ICON_MAP = {
        "mensaje": "💬", "visita": "👁️", "permuta": "🔄", "reseña": "⭐",
        "sistema": "✅", "alerta": "🔔", "puntos": "🏆", "favorito": "❤️",
    }
    out = []
    for _, row in df.iterrows():
        nid = str(row.get("ID", "")).strip()
        if not nid or nid.upper() == "ID":
            continue
        tipo  = str(row.get("Tipo", "Sistema")).strip()
        leida = str(row.get("Leída", row.get("Leida", "Sí"))).strip().lower()
        fecha = str(row.get("Fecha", "—"))
        grupo = ("Hoy" if "26/02/2024" in fecha else "Ayer" if "25/02/2024" in fecha else "Esta semana")
        out.append({
            "id":     nid,
            "group":  grupo,
            "icon":   ICON_MAP.get(tipo.lower(), "🔔"),
            "tipo":   tipo,
            "title":  str(row.get("Título", row.get("Titulo", "Notificación"))),
            "desc":   str(row.get("Descripción", row.get("Descripcion", ""))),
            "user":   str(row.get("Usuario Destino", "—")),
            "date":   fecha,
            "time":   str(row.get("Hora", "—")),
            "unread": leida in ("no", "false", "0"),
            "action": str(row.get("Acción", row.get("Accion", "—"))),
        })
    return out


def _df_to_permutas(df: pd.DataFrame) -> list:
    """Lee hoja de permutas — acepta nombres con/sin punto abreviado."""
    out = []
    for _, row in df.iterrows():
        pid = str(row.get("ID", "")).strip()
        if not pid or pid.upper() == "ID":
            continue
        out.append({
            "id":              pid,
            "veh_oferta":      str(row.get("Veh. Ofertado", row.get("Veh Ofertado", ""))),
            "vendedor_oferta": str(row.get("Vendedor Oferta", "")),
            "veh_destino":     str(row.get("Veh. Solicitado", row.get("Veh Solicitado", ""))),
            "propietario":     str(row.get("Propietario Destino", row.get("Propietario", ""))),
            "ciudad":          str(row.get("Ciudad", "Bogotá")),
            "valor_oferta":    _int(row.get("Valor Estimado", 0)),
            "diferencia":      _int(row.get("Diferencia", 0)),
            "fecha":           str(row.get("Fecha", "—")),
            "estado":          str(row.get("Estado", "Activa")),
            "mensaje":         str(row.get("Mensaje", "")),
            "resultado":       str(row.get("Resultado", "Pendiente")),
        })
    return out


def _df_to_usuarios(df: pd.DataFrame) -> list:
    """Lee hoja de usuarios — acepta 'Nombre Completo' o 'Nombre'."""
    out = []
    for _, row in df.iterrows():
        # El xlsx exportado usa "Nombre", el original usa "Nombre Completo"
        n = str(row.get("Nombre Completo", row.get("Nombre", ""))).strip()
        if not n or n.upper() in ("TOTALES", "NOMBRE COMPLETO", "NOMBRE"):
            continue
        out.append({
            "id":             _int(row.get("ID", 0)),
            "nombre":         n,
            "correo":         str(row.get("Correo", "")),
            "celular":        str(row.get("Celular", "")),
            "documento":      str(row.get("Documento", "")),
            "ciudad":         str(row.get("Ciudad", "Bogotá")),
            "rol":            str(row.get("Rol", "Usuario")),
            "publicaciones":  _int(row.get("Publicaciones", 0)),
            "ventas":         _int(row.get("Ventas", 0)),
            "puntos":         _int(row.get("Puntos", 0)),
            "nivel":          str(row.get("Nivel", "Bronze")),
            "fecha_registro": str(row.get("Fecha Registro", "—")),
        })
    return out


# ════════════════════════════════════════════════════════════════════════════
# INICIALIZACIÓN ÚNICA POR SESIÓN
# ════════════════════════════════════════════════════════════════════════════
def load_from_xlsx(file_bytes: bytes) -> bool:
    """
    Carga datos desde un archivo .xlsx con la misma estructura que jjgt_gestion.
    Hojas esperadas (por nombre exacto o contenido de columnas):
      🚗 VEHÍCULOS, 👥 USUARIOS, 🔄 PERMUTAS, 📦 HISTORIAL, 🔔 NOTIFICACIONES
    Devuelve True si al menos la hoja de vehículos se cargó con datos.
    """
    import io as _io
    try:
        xls = pd.ExcelFile(_io.BytesIO(file_bytes))
    except Exception as e:
        st.error(f"❌ No se pudo leer el archivo Excel: {e}")
        return False

    # Mapeo de nombres alternativos de hoja → clave interna
    SHEET_MAP = {
        WS_VEH:    "veh",   "VEHICULOS": "veh",   "VEHÍCULOS": "veh",
        WS_USR:    "usr",   "USUARIOS":  "usr",
        WS_PERM:   "perm",  "PERMUTAS":  "perm",
        WS_PUB:    "pub",   "PUBLICACIONES": "pub",
        WS_HIST:   "hist",  "HISTORIAL": "hist",
        WS_NOTIF:  "notif", "NOTIFICACIONES": "notif",
    }

    dfs = {"veh": pd.DataFrame(), "usr": pd.DataFrame(),
           "perm": pd.DataFrame(), "pub": pd.DataFrame(),
           "hist": pd.DataFrame(), "notif": pd.DataFrame()}

    for sheet in xls.sheet_names:
        key = SHEET_MAP.get(sheet) or SHEET_MAP.get(sheet.upper().strip())
        if key:
            try:
                dfs[key] = xls.parse(sheet)
            except Exception:
                pass

    vehs = _df_to_vehicles(dfs["veh"])
    if not vehs:
        st.error("❌ El archivo no contiene vehículos válidos. "
                 "Verifica que la hoja se llame '🚗 VEHÍCULOS'.")
        return False

    st.session_state._vehicles      = vehs
    st.session_state._usuarios      = _df_to_usuarios(dfs["usr"])
    st.session_state._permutas_base = _df_to_permutas(dfs["perm"])
    st.session_state._history_base  = _df_to_history(dfs["hist"])
    st.session_state._notifs_base   = _df_to_notifications(dfs["notif"])
    st.session_state._data_source   = "📂 Archivo Excel"
    st.session_state._xlsx_loaded   = True
    st.session_state._data_loaded   = False   # permitir que init_data detecte xlsx
    return True


def init_data():
    """
    Prioridad de carga:
      1. Google Sheets  → SIEMPRE se usa si hay credenciales, sin fallback a estáticos.
         Si una hoja está vacía en Sheets, esa lista queda vacía (no se mezcla con estáticos).
      2. Excel subido   → si el usuario cargó un .xlsx se usa en lugar de Sheets.
      3. Sin conexión   → lista vacía (no datos estáticos inventados).
    Solo se ejecuta UNA VEZ por sesión (_data_loaded).
    """
    if st.session_state.get("_data_loaded"):
        return

    # ── Prioridad 1: Google Sheets ───────────────────────────────────────────
    creds, _ = load_credentials_from_toml()
    client    = None

    if creds:
        client = get_google_sheets_connection(creds)

    if client:
        st.session_state._gs_client   = client
        st.session_state._data_source = "☁️ Google Sheets"
        try:
            _hojas = [
                (WS_VEH,  "🚗 Vehículos",      "_vehicles",      _df_to_vehicles),
                (WS_USR,  "👥 Usuarios",        "_usuarios",      _df_to_usuarios),
                (WS_PERM, "🔄 Permutas",        "_permutas_base", _df_to_permutas),
                (WS_HIST, "📦 Historial",       "_history_base",  _df_to_history),
                (WS_NOTIF,"🔔 Notificaciones",  "_notifs_base",   _df_to_notifications),
            ]
            errores = []
            with st.status("📊 Cargando jjgt_gestion…", expanded=True) as status:
                for ws_name, label, ss_key, transformer in _hojas:
                    st.write(f"Leyendo {label}…")
                    try:
                        df = load_data_from_sheet(client, SHEET_FILE, ws_name)
                        st.session_state[ss_key] = transformer(df)
                        n_rows = len(st.session_state[ss_key])
                        st.write(f"✅ {label}: {n_rows} registros")
                        time.sleep(0.6)   # pausa entre lecturas para no saturar cuota
                    except Exception as e_hoja:
                        st.session_state[ss_key] = []
                        msg = str(e_hoja)
                        if _is_quota_err(e_hoja):
                            msg = (f"⚠️ Cuota excedida ({label}). "
                                   f"Espera ~1 minuto y recarga la página. "
                                   f"(Error 429 – Quota exceeded)")
                        else:
                            msg = f"⚠️ Error en {label}: {e_hoja}"
                        st.write(msg)
                        errores.append(label)

                if errores:
                    status.update(
                        label=f"⚠️ Cargado con errores en: {', '.join(errores)}",
                        state="error", expanded=True)
                else:
                    n = len(st.session_state.get("_vehicles", []))
                    status.update(
                        label=f"☁️ jjgt_gestion cargado · {n} vehículos",
                        state="complete", expanded=False)

        except Exception as e:
            msg = str(e)
            if _is_quota_err(e):
                st.warning(
                    "⚠️ **Límite de lectura de Google Sheets alcanzado (Error 429)**\n\n"
                    "La API permite 60 solicitudes/minuto por usuario. "
                    "Espera ~1 minuto y recarga la página.\n\n"
                    "Mientras tanto puedes cargar un archivo Excel con los mismos datos "
                    "usando el panel '📂 Cargar Excel' del menú lateral.")
            else:
                st.warning(f"⚠️ Error cargando hojas: {msg}")
            st.session_state._vehicles      = []
            st.session_state._usuarios      = []
            st.session_state._permutas_base = []
            st.session_state._history_base  = []
            st.session_state._notifs_base   = []

        st.session_state._data_loaded = True
        return

    # ── Prioridad 2: Excel subido por el usuario ─────────────────────────────
    if st.session_state.get("_xlsx_loaded"):
        st.session_state._data_source = "📂 Archivo Excel"
        st.session_state._data_loaded = True
        return

    # ── Sin ninguna fuente disponible ────────────────────────────────────────
    st.session_state._vehicles      = []
    st.session_state._usuarios      = []
    st.session_state._permutas_base = []
    st.session_state._history_base  = []
    st.session_state._notifs_base   = []
    st.session_state._data_source   = "⚠️ Sin fuente de datos"
    st.session_state._gs_client     = None
    st.session_state._data_loaded   = True


# ════════════════════════════════════════════════════════════════════════════
# RECONSTRUCCIÓN LAZY DE MEDIA (fotos/video desde Drive)
# ════════════════════════════════════════════════════════════════════════════
def reconstruct_media(v: dict) -> dict:
    """
    Descarga fotos/video desde Drive para el vehículo v cuando:
      - fotos_urls o video_url tienen contenido, Y
      - fotos está vacía O video es None  (bytes no cargados aún)
    Usa caché en session_state._media_cache para no re-descargar.
    """
    fotos_urls = (v.get("fotos_urls") or "").strip()
    video_url  = (v.get("video_url")  or "").strip()

    # Verificar si ya hay bytes cargados (lista con elementos, no vacía)
    fotos_ok = bool(v.get("fotos"))   # True solo si lista no vacía con dicts
    video_ok = bool(v.get("video"))   # True solo si dict no None

    # Si ya todo está cargado no hay nada que hacer
    if fotos_ok and (video_ok or not video_url):
        return v

    # Si no hay URLs que descargar tampoco hay nada que hacer
    if not fotos_urls and not video_url:
        return v

    try:
        from media_sync import load_media_from_urls
        fotos_nuevas, video_nuevo = load_media_from_urls(fotos_urls, video_url)
        if fotos_nuevas:                    # solo sobrescribir si descargó algo
            v["fotos"] = fotos_nuevas
        if video_nuevo:
            v["video"] = video_nuevo
        # Reflejar en session_state para que persista en la sesión
        sv = st.session_state.get("selected_vehicle")
        if sv is not None and sv.get("id") == v.get("id"):
            st.session_state.selected_vehicle = v
    except Exception as e:
        st.warning(f"⚠️ No se pudieron cargar las imágenes desde Drive: {e}")
    return v


# ── Getters públicos — devuelven lista vacía si no hay datos cargados ─────────
def get_vehicles():      return st.session_state.get("_vehicles",      [])
def get_usuarios():      return st.session_state.get("_usuarios",      [])
def get_permutas_base(): return st.session_state.get("_permutas_base", [])
def get_history_base():  return st.session_state.get("_history_base",  [])
def get_notifs_base():   return st.session_state.get("_notifs_base",   [])


# ════════════════════════════════════════════════════════════════════════════
# DATOS ESTÁTICOS — fallback fiel al Excel adjunto
# ════════════════════════════════════════════════════════════════════════════
STATIC_VEHICLES = [
    {"id":1,"name":"Toyota Corolla","model":"Corolla XEI","year":2022,"price":85_000_000,
     "km":28_000,"fuel":"Gasolina","trans":"Automático","city":"Bogotá","color":"Blanco",
     "type":"venta","cat":"sedan","rating":4.8,"reviews":24,"grad":0,
     "desc":"Único dueño. Servicios al día. Llantas nuevas, vidrios eléctricos, cámara de reversa.",
     "seller":"Juan Carlos Gómez","phone":"300 512 3456",
     "seller_phone":"300 512 3456","seller_email":"juancarlos@gmail.com",
     "fotos":[],"video":None,"isUserPub":False},
    {"id":2,"name":"Chevrolet Tracker","model":"Premier","year":2023,"price":102_000_000,
     "km":12_000,"fuel":"Gasolina","trans":"Automático","city":"Medellín","color":"Azul",
     "type":"ambos","cat":"suv","rating":4.9,"reviews":8,"grad":1,
     "desc":"Turbo automático, pantalla táctil, Apple CarPlay, techo panorámico.",
     "seller":"Mario Rodríguez","phone":"315 678 9012",
     "seller_phone":"315 678 9012","seller_email":"mario.rod@gmail.com",
     "fotos":[],"video":None,"isUserPub":False},
    {"id":3,"name":"Renault Sandero","model":"Stepway","year":2021,"price":48_000_000,
     "km":45_000,"fuel":"Gasolina","trans":"Manual","city":"Cali","color":"Gris",
     "type":"permuta","cat":"hatchback","rating":4.5,"reviews":15,"grad":2,
     "desc":"SOAT y tecnomecánica vigentes. Audio Bluetooth, control de estabilidad.",
     "seller":"Ana Lucía Martínez","phone":"310 234 5678",
     "seller_phone":"310 234 5678","seller_email":"analucia@hotmail.com",
     "fotos":[],"video":None,"isUserPub":False},
    {"id":4,"name":"Mazda CX-5","model":"Grand Touring","year":2022,"price":125_000_000,
     "km":35_000,"fuel":"Gasolina","trans":"Automático","city":"Bogotá","color":"Rojo",
     "type":"venta","cat":"suv","rating":4.7,"reviews":19,"grad":3,
     "desc":"Head-up display, asientos de cuero, techo solar, cámara 360.",
     "seller":"Carlos Betancur","phone":"320 890 1234",
     "seller_phone":"320 890 1234","seller_email":"carlos.b@empresa.co",
     "fotos":[],"video":None,"isUserPub":False},
    {"id":5,"name":"Ford Ranger","model":"XLT 4x4","year":2021,"price":138_000_000,
     "km":52_000,"fuel":"Diesel","trans":"Automático","city":"Bucaramanga","color":"Negro",
     "type":"ambos","cat":"pickup","rating":4.6,"reviews":11,"grad":4,
     "desc":"2.2 TDCi 160hp. Tracción 4x4 seleccionable. Carga 1 tonelada.",
     "seller":"Pedro Lozano","phone":"318 345 6789",
     "seller_phone":"318 345 6789","seller_email":"pedro.loz@gmail.com",
     "fotos":[],"video":None,"isUserPub":False},
    {"id":6,"name":"Hyundai Tucson","model":"Premium","year":2023,"price":118_000_000,
     "km":8_000,"fuel":"Gasolina","trans":"Automático","city":"Barranquilla","color":"Gris Perlado",
     "type":"venta","cat":"suv","rating":5.0,"reviews":5,"grad":5,
     "desc":"Garantía de fábrica vigente, frenos AEB, reconocimiento de señales.",
     "seller":"Valentina Torres","phone":"312 456 7890",
     "seller_phone":"312 456 7890","seller_email":"vale.torres@gmail.com",
     "fotos":[],"video":None,"isUserPub":False},
    {"id":7,"name":"Volkswagen Golf","model":"Highline TSI","year":2020,"price":72_000_000,
     "km":61_000,"fuel":"Gasolina","trans":"Automático","city":"Bogotá","color":"Blanco",
     "type":"permuta","cat":"hatchback","rating":4.4,"reviews":28,"grad":6,
     "desc":"1.4 turbo 150hp, caja DSG, faros LED, parking automático.",
     "seller":"Andrés Ospina","phone":"317 789 0123",
     "seller_phone":"317 789 0123","seller_email":"andres.os@gmail.com",
     "fotos":[],"video":None,"isUserPub":False},
    {"id":8,"name":"Kia Sportage","model":"EX Premium","year":2022,"price":108_000_000,
     "km":22_000,"fuel":"Gasolina","trans":"Automático","city":"Pereira","color":"Naranja",
     "type":"venta","cat":"suv","rating":4.7,"reviews":17,"grad":7,
     "desc":"Pantalla 10.25\", Bose, asientos ventilados y calefactados.",
     "seller":"Mario Rodríguez","phone":"315 678 9012",
     "seller_phone":"315 678 9012","seller_email":"mario.rod@gmail.com",
     "fotos":[],"video":None,"isUserPub":False},
    {"id":9,"name":"Toyota Hilux","model":"SRV 4x4","year":2021,"price":155_000_000,
     "km":43_000,"fuel":"Diesel","trans":"Automático","city":"Bogotá","color":"Blanco",
     "type":"venta","cat":"pickup","rating":4.9,"reviews":32,"grad":8,
     "desc":"2.8 GD6 204hp. Cuero, multimedia, control de descenso.",
     "seller":"Andrés Ospina","phone":"317 789 0123",
     "seller_phone":"317 789 0123","seller_email":"andres.os@gmail.com",
     "fotos":[],"video":None,"isUserPub":False},
    {"id":10,"name":"Renault Duster","model":"Oroch","year":2022,"price":78_000_000,
     "km":30_000,"fuel":"Gasolina","trans":"Manual","city":"Cali","color":"Verde",
     "type":"ambos","cat":"pickup","rating":4.3,"reviews":21,"grad":9,
     "desc":"Doble cabina, 6 velocidades, multimedia táctil.",
     "seller":"Luisa Fernanda Díaz","phone":"319 678 9012",
     "seller_phone":"319 678 9012","seller_email":"luisaf@gmail.com",
     "fotos":[],"video":None,"isUserPub":False},
    {"id":11,"name":"Chevrolet Onix","model":"LTZ Turbo","year":2023,"price":62_000_000,
     "km":6_000,"fuel":"Gasolina","trans":"Automático","city":"Medellín","color":"Azul",
     "type":"venta","cat":"sedan","rating":4.6,"reviews":9,"grad":10,
     "desc":"Solo 6,000 km. Cámara reversa, Apple CarPlay, ABS, airbags dobles.",
     "seller":"Valentina Torres","phone":"312 456 7890",
     "seller_phone":"312 456 7890","seller_email":"vale.torres@gmail.com",
     "fotos":[],"video":None,"isUserPub":False},
    {"id":12,"name":"BMW Serie 3","model":"320i Sport","year":2020,"price":175_000_000,
     "km":48_000,"fuel":"Gasolina","trans":"Automático","city":"Bogotá","color":"Azul Zafiro",
     "type":"venta","cat":"sedan","rating":4.8,"reviews":14,"grad":11,
     "desc":"2.0 Twin Power Turbo 184hp, iDrive 10.25\", Harman Kardon.",
     "seller":"Juan Carlos Gómez","phone":"300 512 3456",
     "seller_phone":"300 512 3456","seller_email":"juancarlos@gmail.com",
     "fotos":[],"video":None,"isUserPub":False},
    {"id":13,"name":"Jeep Wrangler","model":"Rubicon 4xe","year":2022,"price":280_000_000,
     "km":18_000,"fuel":"Híbrido","trans":"Automático","city":"Bogotá","color":"Naranja",
     "type":"permuta","cat":"suv","rating":4.9,"reviews":6,"grad":12,
     "desc":"Híbrido enchufable, techo desmontable, portal axles, spool valve shocks.",
     "seller":"Carlos Betancur","phone":"320 890 1234",
     "seller_phone":"320 890 1234","seller_email":"carlos.b@empresa.co",
     "fotos":[],"video":None,"isUserPub":False},
    {"id":14,"name":"Mazda 2","model":"Grand Touring","year":2022,"price":58_000_000,
     "km":24_000,"fuel":"Gasolina","trans":"Automático","city":"Cali","color":"Rojo",
     "type":"venta","cat":"hatchback","rating":4.5,"reviews":18,"grad":13,
     "desc":"Pantalla táctil 8\", techo solar corredizo, Bose, llantas 16\".",
     "seller":"Pedro Lozano","phone":"318 345 6789",
     "seller_phone":"318 345 6789","seller_email":"pedro.loz@gmail.com",
     "fotos":[],"video":None,"isUserPub":False},
    {"id":15,"name":"Ford Explorer","model":"XLT 4x4","year":2021,"price":210_000_000,
     "km":38_000,"fuel":"Gasolina","trans":"Automático","city":"Bogotá","color":"Gris Magnético",
     "type":"ambos","cat":"suv","rating":4.7,"reviews":22,"grad":14,
     "desc":"7 puestos, V6 3.0T 400hp, B&O, techo panorámico doble.",
     "seller":"Andrés Ospina","phone":"317 789 0123",
     "seller_phone":"317 789 0123","seller_email":"andres.os@gmail.com",
     "fotos":[],"video":None,"isUserPub":False},
]

STATIC_HISTORIAL = [
    {"id":"#JG-2024-001","name":"Toyota Corolla 2022","price":85_000_000,"date":"15/02/2024",
     "status":"activo","type":"Publicación","km":28_000,"seller":"Juan Carlos G.","buyer":"—",
     "city":"Bogotá","notes":"Aviso activo con 287 visitas","points":50},
    {"id":"#JG-2024-002","name":"Chevrolet Tracker 2023","price":102_000_000,"date":"10/02/2024",
     "status":"activo","type":"Publicación","km":12_000,"seller":"Mario R.","buyer":"—",
     "city":"Medellín","notes":"Aviso activo · 142 visitas","points":50},
    {"id":"#JG-2024-003","name":"Renault Sandero 2021","price":48_000_000,"date":"01/02/2024",
     "status":"completado","type":"Permuta","km":45_000,"seller":"Ana M.","buyer":"Pedro L.",
     "city":"Cali","notes":"Permuta completada con VW Golf","points":150},
    {"id":"#JG-2024-004","name":"Mazda CX-5 2022","price":125_000_000,"date":"25/01/2024",
     "status":"pendiente","type":"Venta","km":35_000,"seller":"Carlos B.","buyer":"Valentina T.",
     "city":"Bogotá","notes":"Negociación en curso","points":0},
    {"id":"#JG-2024-005","name":"Ford Ranger 2021","price":138_000_000,"date":"15/01/2024",
     "status":"completado","type":"Venta","km":52_000,"seller":"Pedro L.","buyer":"Andrés O.",
     "city":"Bucaramanga","notes":"Venta completada exitosamente","points":200},
]

STATIC_NOTIFS = [
    {"id":"N-001","group":"Hoy","icon":"💬","tipo":"Mensaje","title":"Nuevo mensaje de Mario R.",
     "desc":"¿El Corolla acepta permuta por un Tracker?","user":"Juan Carlos G.",
     "date":"26/02/2024","time":"14:32","unread":True,"action":"Ver mensaje"},
    {"id":"N-002","group":"Hoy","icon":"👁️","tipo":"Visita","title":"47 visitas hoy a tu Corolla",
     "desc":"Tu publicación está generando mucho interés","user":"Juan Carlos G.",
     "date":"26/02/2024","time":"12:00","unread":True,"action":"Ver aviso"},
    {"id":"N-003","group":"Hoy","icon":"🔄","tipo":"Permuta","title":"Nueva propuesta de permuta",
     "desc":"Andrés O. ofrece su Hilux por tu Corolla","user":"Juan Carlos G.",
     "date":"26/02/2024","time":"10:15","unread":True,"action":"Ver propuesta"},
    {"id":"N-004","group":"Ayer","icon":"⭐","tipo":"Reseña","title":"Nueva reseña 5 estrellas",
     "desc":"Carlos B. te calificó con 5 estrellas","user":"Juan Carlos G.",
     "date":"25/02/2024","time":"18:45","unread":False,"action":"Ver reseña"},
    {"id":"N-005","group":"Ayer","icon":"✅","tipo":"Sistema","title":"Publicación verificada",
     "desc":"Chevrolet Tracker aprobada con éxito","user":"Mario R.",
     "date":"25/02/2024","time":"11:00","unread":False,"action":"Ver aviso"},
    {"id":"N-006","group":"Esta semana","icon":"🔔","tipo":"Alerta","title":"Aviso por vencer",
     "desc":"Renueva la publicación del Sandero 2021","user":"Ana M.",
     "date":"24/02/2024","time":"09:00","unread":False,"action":"Renovar"},
    {"id":"N-007","group":"Esta semana","icon":"🏆","tipo":"Puntos","title":"Puntos ganados",
     "desc":"Ganaste 50 puntos por completar tu perfil","user":"Valentina T.",
     "date":"23/02/2024","time":"14:15","unread":False,"action":"Ver puntos"},
    {"id":"N-008","group":"Esta semana","icon":"❤️","tipo":"Favorito",
     "title":"23 personas guardaron tu Corolla",
     "desc":"Actualiza el precio para mayor visibilidad","user":"Juan Carlos G.",
     "date":"22/02/2024","time":"10:00","unread":False,"action":"Ver aviso"},
    {"id":"N-009","group":"Esta semana","icon":"💬","tipo":"Mensaje","title":"Consulta sobre permuta",
     "desc":"¿El vehículo acepta financiamiento?","user":"Pedro L.",
     "date":"21/02/2024","time":"16:30","unread":False,"action":"Ver chat"},
    {"id":"N-010","group":"Esta semana","icon":"✅","tipo":"Sistema","title":"Bienvenido a JJGT",
     "desc":"Tu cuenta ha sido creada exitosamente","user":"Carlos B.",
     "date":"10/02/2024","time":"08:00","unread":False,"action":"Ir al inicio"},
    {"id":"N-011","group":"Esta semana","icon":"🔔","tipo":"Alerta","title":"Verificación pendiente",
     "desc":"Sube tu documento para verificar tu cuenta","user":"Ana M.",
     "date":"20/02/2024","time":"12:00","unread":False,"action":"Verificar"},
    {"id":"N-012","group":"Esta semana","icon":"🔄","tipo":"Permuta","title":"Contraoferta recibida",
     "desc":"Valentina T. hizo una contraoferta por tu Sportage","user":"Carlos B.",
     "date":"19/02/2024","time":"17:45","unread":False,"action":"Ver oferta"},
]

STATIC_PERMUTAS = [
    {"id":"P-001","veh_oferta":"Mazda 3 2020","vendedor_oferta":"Juan Carlos G.",
     "veh_destino":"Toyota Corolla 2022","propietario":"Mario R.","ciudad":"Bogotá",
     "valor_oferta":65_000_000,"diferencia":20_000_000,"fecha":"15/02/2024",
     "estado":"Activa","mensaje":"Interesado en tu Corolla, ofrezco mi Mazda 3","resultado":"Pendiente"},
    {"id":"P-002","veh_oferta":"VW Golf 2020","vendedor_oferta":"Pedro L.",
     "veh_destino":"Renault Sandero 2021","propietario":"Ana M.","ciudad":"Cali",
     "valor_oferta":72_000_000,"diferencia":24_000_000,"fecha":"12/02/2024",
     "estado":"Activa","mensaje":"Cambio Golf por Sandero, muy buen estado","resultado":"Pendiente"},
    {"id":"P-003","veh_oferta":"Chevrolet Onix 2023","vendedor_oferta":"Valentina T.",
     "veh_destino":"Kia Sportage 2022","propietario":"Carlos B.","ciudad":"Bogotá",
     "valor_oferta":62_000_000,"diferencia":46_000_000,"fecha":"10/02/2024",
     "estado":"Contraoferta","mensaje":"¿Aceptas el Onix + diferencia?","resultado":"Negociando"},
    {"id":"P-004","veh_oferta":"Renault Duster 2022","vendedor_oferta":"Andrés O.",
     "veh_destino":"Ford Ranger 2021","propietario":"Pedro L.","ciudad":"Bucaramanga",
     "valor_oferta":78_000_000,"diferencia":60_000_000,"fecha":"08/02/2024",
     "estado":"Activa","mensaje":"Duster por Ranger, el mío tiene extras","resultado":"Pendiente"},
    {"id":"P-005","veh_oferta":"Mazda 2 2022","vendedor_oferta":"Ana M.",
     "veh_destino":"Chevrolet Tracker 2023","propietario":"Mario R.","ciudad":"Medellín",
     "valor_oferta":58_000_000,"diferencia":44_000_000,"fecha":"05/02/2024",
     "estado":"Cerrada","mensaje":"Excelente proceso, muy satisfecho","resultado":"Completada"},
    {"id":"P-006","veh_oferta":"Ford Explorer 2021","vendedor_oferta":"Carlos B.",
     "veh_destino":"Jeep Wrangler 2022","propietario":"Valentina T.","ciudad":"Bogotá",
     "valor_oferta":210_000_000,"diferencia":70_000_000,"fecha":"01/02/2024",
     "estado":"Cancelada","mensaje":"Desistí de la permuta","resultado":"Cancelada"},
    {"id":"P-007","veh_oferta":"Toyota Hilux 2021","vendedor_oferta":"Andrés O.",
     "veh_destino":"BMW Serie 3 2020","propietario":"Luisa D.","ciudad":"Bogotá",
     "valor_oferta":155_000_000,"diferencia":20_000_000,"fecha":"25/01/2024",
     "estado":"Cerrada","mensaje":"Cerramos, muy buena experiencia","resultado":"Completada"},
    {"id":"P-008","veh_oferta":"Hyundai Tucson 2023","vendedor_oferta":"Mario R.",
     "veh_destino":"Mazda CX-5 2022","propietario":"Luisa D.","ciudad":"Bogotá",
     "valor_oferta":118_000_000,"diferencia":7_000_000,"fecha":"20/01/2024",
     "estado":"Activa","mensaje":"Casi el mismo precio, ¿hacemos el cambio?","resultado":"Pendiente"},
]

STATIC_USUARIOS = [
    {"id":1,"nombre":"Juan Carlos Gómez","correo":"juancarlos@gmail.com","celular":"300 512 3456",
     "documento":"10.234.567","ciudad":"Bogotá","rol":"Vendedor/Comprador",
     "publicaciones":8,"ventas":3,"puntos":200,"nivel":"Silver","fecha_registro":"15/01/2024"},
    {"id":2,"nombre":"Mario Rodríguez","correo":"mario.rod@gmail.com","celular":"315 678 9012",
     "documento":"20.345.678","ciudad":"Medellín","rol":"Vendedor",
     "publicaciones":12,"ventas":7,"puntos":450,"nivel":"Silver","fecha_registro":"03/11/2023"},
    {"id":3,"nombre":"Ana Lucía Martínez","correo":"analucia@hotmail.com","celular":"310 234 5678",
     "documento":"30.456.789","ciudad":"Cali","rol":"Vendedor/Comprador",
     "publicaciones":5,"ventas":2,"puntos":120,"nivel":"Bronze","fecha_registro":"22/02/2024"},
    {"id":4,"nombre":"Carlos Betancur","correo":"carlos.b@empresa.co","celular":"320 890 1234",
     "documento":"40.567.890","ciudad":"Bogotá","rol":"Comprador",
     "publicaciones":0,"ventas":0,"puntos":50,"nivel":"Bronze","fecha_registro":"10/03/2024"},
    {"id":5,"nombre":"Pedro Lozano","correo":"pedro.loz@gmail.com","celular":"318 345 6789",
     "documento":"50.678.901","ciudad":"Bucaramanga","rol":"Vendedor",
     "publicaciones":3,"ventas":1,"puntos":80,"nivel":"Bronze","fecha_registro":"05/12/2023"},
    {"id":6,"nombre":"Valentina Torres","correo":"vale.torres@gmail.com","celular":"312 456 7890",
     "documento":"60.789.012","ciudad":"Barranquilla","rol":"Vendedor",
     "publicaciones":6,"ventas":4,"puntos":310,"nivel":"Silver","fecha_registro":"18/09/2023"},
    {"id":7,"nombre":"Santiago Herrera","correo":"santi.h@outlook.com","celular":"316 567 8901",
     "documento":"70.890.123","ciudad":"Pereira","rol":"Comprador",
     "publicaciones":0,"ventas":0,"puntos":20,"nivel":"Bronze","fecha_registro":"01/04/2024"},
    {"id":8,"nombre":"Luisa Fernanda Díaz","correo":"luisaf@gmail.com","celular":"319 678 9012",
     "documento":"80.901.234","ciudad":"Bogotá","rol":"Vendedor/Comprador",
     "publicaciones":4,"ventas":2,"puntos":160,"nivel":"Bronze","fecha_registro":"12/10/2023"},
    {"id":9,"nombre":"Andrés Ospina","correo":"andres.os@gmail.com","celular":"317 789 0123",
     "documento":"90.012.345","ciudad":"Cali","rol":"Vendedor",
     "publicaciones":9,"ventas":5,"puntos":520,"nivel":"Gold","fecha_registro":"07/07/2023"},
    {"id":10,"nombre":"JJGT Admin","correo":"josegarjagt@gmail.com","celular":"300 000 0001",
     "documento":"900.123.456","ciudad":"Bogotá","rol":"Administrador",
     "publicaciones":0,"ventas":0,"puntos":9999,"nivel":"Admin","fecha_registro":"01/01/2024"},
]

CHATBOT_REPLIES = {
    "publicar": "Para publicar ve a 'Publicar' en el menú. Necesitarás fotos/video y datos del vehículo. ¿Tienes alguna duda?",
    "permuta":  "La permuta es muy sencilla. Busca el vehículo y toca 'Proponer permuta'. ¡Sin intermediarios! 🔄",
    "precio":   "Para verificar precios compara vehículos similares en la plataforma. ¿Qué marca te interesa?",
    "soat":     "El SOAT y tecnomecánica son responsabilidad del vendedor. Revisa en persona antes de cerrar.",
    "pago":     "Usa consignación bancaria o transferencia. Nunca envíes dinero sin ver el vehículo.",
    "seguro":   "Verificamos identidad de usuarios. Siempre revisa el vehículo en persona.",
    "gratis":   "¡Publicar es completamente gratis! Hasta 3 avisos activos.",
    "puntos":   "Ganas puntos por publicar, completar ventas e invitar amigos.",
    "default":  "Nuestro equipo está disponible Lun–Sáb 8am–6pm. ¿Te contactamos por WhatsApp? 😊",
}
