"""
JJGT — Plataforma de Venta y Permuta de Vehículos · Colombia
Aplicación Streamlit completa
"""
import streamlit as st
import base64
import io
from datetime import datetime
from PIL import Image
from data import VEHICLES, HISTORY_ITEMS, NOTIFICATIONS, CHATBOT_REPLIES, PERMUTAS, USUARIOS
from styles import get_css
from components import (
    render_vehicle_card, render_hero_banner, render_stats_row,
    render_quick_actions, render_vehicle_detail, render_notification_item,
    render_history_item, render_permuta_card, render_seller_card,
    render_loyalty_card, render_kpi_card, render_chat_bubble
)

# ─── PAGE CONFIG ────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="JJGT — Vehículos Colombia",
    page_icon="🚗",
    layout="wide",
    initial_sidebar_state="collapsed",
)

# ─── INJECT GLOBAL CSS ──────────────────────────────────────────────────────
st.markdown(get_css(), unsafe_allow_html=True)

# ─── SESSION STATE INIT ─────────────────────────────────────────────────────
def init_state():
    defaults = {
        "logged_in": False,
        "user_name": "",
        "user_email": "",
        "user_phone": "",
        "user_city": "Bogotá",
        "favorites": [],
        "page": "home",
        "selected_vehicle": None,
        "search_query": "",
        "cat_filter": "Todos",
        "tipo_filter": "Todos",
        "city_filter": "Todas",
        "price_min": 0,
        "price_max": 400,
        "chat_messages": [],
        "chat_input": "",
        "user_publications": [],
        "history_items": list(HISTORY_ITEMS),
        "notifications": list(NOTIFICATIONS),
        "permutas": list(PERMUTAS),
        "notif_count": 3,
        "active_cities": ["Bogotá", "Medellín", "Cali"],
        "dark_mode": False,
        "loyalty_points": 200,
        "loyalty_level": "Silver",
        "user_verified": True,
        "notif_prefs": {
            "mensajes": True, "permutas": True, "visitas": True,
            "nuevos": False, "resenas": True, "push": True
        },
        "profile_tab": "datos",
        "auth_mode": "login",
        "register_success": False,
    }
    for k, v in defaults.items():
        if k not in st.session_state:
            st.session_state[k] = v

init_state()

# ─── NAVIGATION SIDEBAR ─────────────────────────────────────────────────────
def sidebar_nav():
    with st.sidebar:
        st.markdown("""
        <div style="text-align:center;padding:20px 0 10px;">
            <div style="font-family:'Arial Black',sans-serif;font-size:48px;font-weight:900;
                        background:linear-gradient(135deg,#C41E3A,#F5A623);
                        -webkit-background-clip:text;-webkit-text-fill-color:transparent;
                        letter-spacing:4px;">JJGT</div>
            <div style="font-size:11px;color:#6B6B8A;letter-spacing:2px;margin-top:2px;">
                VEHÍCULOS · COLOMBIA</div>
        </div>""", unsafe_allow_html=True)

        st.divider()

        # Usuario logueado
        if st.session_state.logged_in:
            initials = "".join(w[0].upper() for w in st.session_state.user_name.split()[:2])
            st.markdown(f"""
            <div style="text-align:center;padding:10px 0 16px;">
                <div style="width:56px;height:56px;border-radius:28px;
                            background:linear-gradient(135deg,#C41E3A,#9B1729);
                            display:flex;align-items:center;justify-content:center;
                            font-size:22px;font-weight:700;color:#fff;margin:0 auto 10px;
                            box-shadow:0 4px 14px rgba(196,30,58,0.35);">{initials}</div>
                <div style="font-weight:700;font-size:15px;">{st.session_state.user_name}</div>
                <div style="font-size:12px;color:#6B6B8A;">{st.session_state.user_email}</div>
                <div style="margin-top:6px;">
                    <span style="background:rgba(245,166,35,0.15);color:#C47D00;
                                 font-size:11px;font-weight:700;padding:3px 10px;
                                 border-radius:20px;">⭐ {st.session_state.loyalty_level}</span>
                </div>
            </div>""", unsafe_allow_html=True)
            st.divider()

        # Menú navegación
        nav_items = [
            ("🏠", "Inicio", "home"),
            ("🔍", "Explorar", "explore"),
            ("➕", "Publicar", "publish"),
            ("📋", "Mis Avisos", "history"),
            ("🔔", "Notificaciones", "notifications"),
            ("💬", "Soporte", "support"),
            ("👤", "Mi Perfil", "profile"),
        ]
        for icon, label, page_id in nav_items:
            is_active = st.session_state.page == page_id
            badge = ""
            if page_id == "notifications" and st.session_state.notif_count > 0:
                badge = f" 🔴"
            btn_style = "primary" if is_active else "secondary"
            if st.button(f"{icon} {label}{badge}", key=f"nav_{page_id}",
                        use_container_width=True, type=btn_style):
                st.session_state.page = page_id
                st.rerun()

        st.divider()

        # Auth buttons
        if st.session_state.logged_in:
            if st.button("🚪 Cerrar sesión", use_container_width=True):
                st.session_state.logged_in = False
                st.session_state.user_name = ""
                st.session_state.user_email = ""
                st.session_state.page = "home"
                st.rerun()
        else:
            col1, col2 = st.columns(2)
            with col1:
                if st.button("Ingresar", use_container_width=True, type="primary"):
                    st.session_state.page = "login"
                    st.rerun()
            with col2:
                if st.button("Registro", use_container_width=True):
                    st.session_state.page = "register"
                    st.rerun()

        st.markdown("""
        <div style="text-align:center;padding:16px 0 0;font-size:10px;color:#9999BB;">
            JJGT v2.0 · Colombia 🇨🇴<br>Hecho con ❤️ para colombianos
        </div>""", unsafe_allow_html=True)

# ─── PAGE: HOME ──────────────────────────────────────────────────────────────
def page_home():
    # Banner acceso (sin sesión)
    if not st.session_state.logged_in:
        st.markdown(render_hero_banner(
            logged_in=False,
            user_name=""
        ), unsafe_allow_html=True)
        col1, col2, col3 = st.columns([1,1,2])
        with col1:
            if st.button("🔐 Ingresar a mi cuenta", type="primary", use_container_width=True):
                st.session_state.page = "login"; st.rerun()
        with col2:
            if st.button("📝 Crear cuenta", use_container_width=True):
                st.session_state.page = "register"; st.rerun()
    else:
        h = datetime.now().hour
        greet = "Buenos días" if h < 12 else "Buenas tardes" if h < 18 else "Buenas noches"
        first = st.session_state.user_name.split()[0]
        st.markdown(f"""
        <div style="background:linear-gradient(135deg,#C41E3A,#1A1A2E);border-radius:18px;
                    padding:24px 28px;margin-bottom:20px;color:#fff;">
            <div style="font-size:13px;opacity:0.7;">{greet},</div>
            <div style="font-size:30px;font-weight:800;margin-top:2px;">{first} 👋</div>
            <div style="font-size:12px;opacity:0.6;margin-top:6px;">
                🌟 {st.session_state.loyalty_level} · {st.session_state.loyalty_points} pts
            </div>
        </div>""", unsafe_allow_html=True)

    # Stats
    st.markdown(render_stats_row(), unsafe_allow_html=True)

    # Acciones rápidas
    st.markdown("### ⚡ Acciones rápidas")
    cols = st.columns(4)
    actions = [
        ("➕ Publicar", "publish", "#C41E3A"),
        ("🔄 Permuta", "permutas", "#00C9A7"),
        ("📋 Mis avisos", "history", "#F5A623"),
        ("💬 Soporte", "support", "#2979FF"),
    ]
    for i, (label, dest, color) in enumerate(actions):
        with cols[i]:
            if st.button(label, key=f"qa_{dest}", use_container_width=True):
                st.session_state.page = dest; st.rerun()

    cols2 = st.columns(4)
    actions2 = [
        ("📝 Registro", "register", "#9C27B0"),
        ("🔍 Explorar", "explore", "#C41E3A"),
        ("🔔 Alertas", "notifications", "#F5A623"),
        ("❓ Ayuda", "help", "#00C9A7"),
    ]
    for i, (label, dest, color) in enumerate(actions2):
        with cols2[i]:
            if st.button(label, key=f"qa2_{dest}", use_container_width=True):
                st.session_state.page = dest; st.rerun()

    st.divider()

    # Vehículos destacados
    st.markdown("### 🌟 Vehículos destacados")
    featured = VEHICLES[:6]
    cols = st.columns(3)
    for i, v in enumerate(featured):
        with cols[i % 3]:
            card_html = render_vehicle_card(v)
            st.markdown(card_html, unsafe_allow_html=True)
            if st.button(f"Ver detalle", key=f"feat_{v['id']}", use_container_width=True):
                st.session_state.selected_vehicle = v
                st.session_state.page = "vehicle_detail"
                st.rerun()

    st.divider()

    # Permutas activas
    st.markdown("### 🔄 Permutas activas")
    permutas_vehs = [v for v in VEHICLES if v["type"] in ("permuta", "ambos")][:4]
    cols = st.columns(2)
    for i, v in enumerate(permutas_vehs):
        with cols[i % 2]:
            st.markdown(render_permuta_card(v), unsafe_allow_html=True)
            if st.button("Proponer permuta", key=f"perm_{v['id']}", use_container_width=True):
                st.session_state.selected_vehicle = v
                st.session_state.page = "vehicle_detail"
                st.rerun()

# ─── PAGE: EXPLORE ───────────────────────────────────────────────────────────
def page_explore():
    st.markdown("## 🔍 Explorar vehículos")

    # Filtros
    with st.expander("🎛️ Filtros avanzados", expanded=False):
        fc1, fc2, fc3 = st.columns(3)
        with fc1:
            cat = st.selectbox("Categoría", ["Todos","Sedán","SUV","Pickup","Hatchback","Camioneta"],
                               key="cat_filter_sel")
            st.session_state.cat_filter = cat
        with fc2:
            tipo = st.selectbox("Tipo anuncio", ["Todos","Venta","Permuta","Ambos"],
                                key="tipo_filter_sel")
            st.session_state.tipo_filter = tipo
        with fc3:
            city = st.selectbox("Ciudad",
                                ["Todas","Bogotá","Medellín","Cali","Barranquilla","Bucaramanga","Pereira"],
                                key="city_filter_sel")
            st.session_state.city_filter = city
        pc1, pc2 = st.columns(2)
        with pc1:
            pmin = st.number_input("Precio mínimo (M COP)", 0, 400, 0, key="pmin")
        with pc2:
            pmax = st.number_input("Precio máximo (M COP)", 0, 400, 400, key="pmax")

    # Búsqueda
    q = st.text_input("🔎 Buscar vehículo...", placeholder="Marca, modelo, ciudad...",
                      key="search_inp")
    st.session_state.search_query = q

    # Aplicar filtros
    cat_map = {"Todos":"all","Sedán":"sedan","SUV":"suv","Pickup":"pickup",
               "Hatchback":"hatchback","Camioneta":"camioneta"}
    tipo_map = {"Todos":None,"Venta":"venta","Permuta":"permuta","Ambos":"ambos"}

    filtered = list(VEHICLES) + st.session_state.user_publications
    if q:
        ql = q.lower()
        filtered = [v for v in filtered if ql in f"{v['name']} {v.get('model',v.get('modelo',''))} {v.get('year',v.get('anio',''))} {v.get('city',v.get('ciudad',''))}".lower()]
    sel_cat = cat_map.get(st.session_state.cat_filter, "all")
    if sel_cat != "all":
        filtered = [v for v in filtered if v.get("cat","") == sel_cat]
    sel_tipo = tipo_map.get(st.session_state.tipo_filter)
    if sel_tipo:
        filtered = [v for v in filtered if v.get("type","") == sel_tipo]
    sel_city = st.session_state.city_filter
    if sel_city != "Todas":
        filtered = [v for v in filtered if v.get("city", v.get("ciudad","")) == sel_city]
    # precio
    filtered = [v for v in filtered if pmin*1_000_000 <= v.get("price", v.get("precio",0)) <= pmax*1_000_000]

    st.markdown(f"<div style='color:#6B6B8A;font-size:13px;margin-bottom:12px;'>{len(filtered)} vehículos encontrados</div>", unsafe_allow_html=True)

    if not filtered:
        st.info("No se encontraron vehículos con esos filtros.")
        return

    cols = st.columns(3)
    for i, v in enumerate(filtered):
        with cols[i % 3]:
            st.markdown(render_vehicle_card(v), unsafe_allow_html=True)
            btn_key = f"exp_v_{v.get('id', v.get('id',''))}__{i}"
            if st.button("Ver detalle →", key=btn_key, use_container_width=True):
                st.session_state.selected_vehicle = v
                st.session_state.page = "vehicle_detail"
                st.rerun()

# ─── PAGE: VEHICLE DETAIL ────────────────────────────────────────────────────
def page_vehicle_detail():
    v = st.session_state.selected_vehicle
    if not v:
        st.session_state.page = "explore"; st.rerun()
        return

    if st.button("← Volver", type="secondary"):
        st.session_state.page = "explore"; st.rerun()

    is_user_pub = v.get("isUserPub", False)

    # Hero / Galería
    fotos = v.get("fotos", [])
    video = v.get("video")

    col_media, col_info = st.columns([1.2, 1])

    with col_media:
        if fotos:
            # Mostrar galería de fotos del usuario
            imgs = []
            for f in fotos:
                try:
                    img = Image.open(io.BytesIO(f["bytes"])) if "bytes" in f else None
                    if img: imgs.append(img)
                except: pass
            if imgs:
                st.image(imgs[0], use_container_width=True,
                         caption=f"📸 {len(imgs)} foto{'s' if len(imgs)>1 else ''}")
                if len(imgs) > 1:
                    thumb_cols = st.columns(min(len(imgs), 5))
                    for ti, img in enumerate(imgs[:5]):
                        with thumb_cols[ti]:
                            st.image(img, use_container_width=True)
            if video:
                try:
                    st.video(video["bytes"])
                except: pass
        else:
            # Placeholder gradiente
            g = v.get("grad", 0)
            grad_colors = [
                ("#C41E3A","#1A1A2E"),("#1A1A2E","#2E2E5A"),("#00C9A7","#007A65"),
                ("#F5A623","#C47D00"),("#2979FF","#1A4BAA"),("#9C27B0","#6A1B9A"),
            ]
            c1, c2 = grad_colors[g % len(grad_colors)]
            st.markdown(f"""
            <div style="background:linear-gradient(135deg,{c1},{c2});
                        border-radius:16px;height:240px;
                        display:flex;align-items:center;justify-content:center;">
                <div style="text-align:center;color:rgba(255,255,255,0.6);">
                    <div style="font-size:48px;">🚗</div>
                    <div style="font-size:13px;margin-top:8px;">Sin fotos disponibles</div>
                </div>
            </div>""", unsafe_allow_html=True)

    with col_info:
        name = v.get("name", v.get("marca",""))
        model = v.get("model", v.get("modelo",""))
        year = v.get("year", v.get("anio",""))
        price = v.get("price", v.get("precio", 0))
        city = v.get("city", v.get("ciudad",""))
        km = v.get("km", 0)
        fuel = v.get("fuel", v.get("comb",""))
        trans = v.get("trans","")
        color = v.get("color","")
        tipo = v.get("type", v.get("tipo","venta"))
        rating = v.get("rating", 0)
        reviews = v.get("reviews", 0)
        desc = v.get("desc", v.get("description",""))

        tipo_labels = {"venta":"🏷️ Venta","permuta":"🔄 Permuta","ambos":"🏷️🔄 Venta + Permuta"}
        tipo_colors = {"venta":"#C41E3A","permuta":"#00C9A7","ambos":"#F5A623"}
        tc = tipo_colors.get(tipo, "#C41E3A")

        st.markdown(f"""
        <div style="background:{tc}20;color:{tc};display:inline-block;
                    padding:4px 14px;border-radius:20px;font-size:12px;font-weight:700;
                    margin-bottom:10px;">{tipo_labels.get(tipo, tipo.upper())}</div>
        <h2 style="margin:0 0 4px;">{name} {model}</h2>
        <div style="color:#6B6B8A;font-size:14px;">{year} · {city} · {km:,} km</div>
        <div style="font-size:36px;font-weight:900;color:#C41E3A;margin:12px 0;">
            ${price/1_000_000:.0f} M
        </div>""", unsafe_allow_html=True)

        if rating:
            stars = "⭐" * int(rating)
            st.markdown(f"**{stars}** {rating}/5.0 ({reviews} reseñas)")

        # Specs grid
        st.markdown("**Especificaciones**")
        s1, s2 = st.columns(2)
        specs = [("📅 Año", year), ("📏 Km", f"{km:,}"),
                 ("⛽ Combustible", fuel), ("⚙️ Transmisión", trans),
                 ("🎨 Color", color), ("📍 Ciudad", city)]
        for i, (label, val) in enumerate(specs):
            with (s1 if i % 2 == 0 else s2):
                st.markdown(f"""
                <div style="background:#F4F5F7;border-radius:10px;padding:10px 14px;margin-bottom:8px;">
                    <div style="font-size:11px;color:#6B6B8A;">{label}</div>
                    <div style="font-weight:700;font-size:14px;">{val}</div>
                </div>""", unsafe_allow_html=True)

    # Descripción
    if desc:
        st.markdown("**📝 Descripción**")
        st.markdown(f"""
        <div style="background:#F4F5F7;border-radius:12px;padding:16px;
                    line-height:1.7;color:#1A1A2E;">{desc}</div>""", unsafe_allow_html=True)

    st.divider()

    # Vendedor
    seller_name = v.get("seller", "Juan Carlos Gómez")
    seller_phone = v.get("phone", v.get("seller_phone","300 512 3456"))
    seller_email = v.get("email", v.get("seller_email","juancarlos@gmail.com"))
    seller_city = v.get("city", v.get("ciudad","Bogotá"))

    st.markdown("**👤 Vendedor**")
    initials = "".join(w[0].upper() for w in seller_name.split()[:2]) if seller_name else "VD"
    st.markdown(f"""
    <div style="background:#fff;border-radius:16px;padding:18px;
                box-shadow:0 4px 20px rgba(26,26,46,0.08);margin-bottom:16px;">
        <div style="display:flex;gap:14px;align-items:center;margin-bottom:14px;">
            <div style="width:52px;height:52px;border-radius:26px;flex-shrink:0;
                        background:linear-gradient(135deg,#C41E3A,#9B1729);
                        display:flex;align-items:center;justify-content:center;
                        font-size:20px;font-weight:700;color:#fff;">{initials}</div>
            <div>
                <div style="font-weight:700;font-size:16px;">{seller_name}</div>
                <div style="font-size:12px;color:#6B6B8A;">📍 {seller_city} · ⭐ Vendedor Silver</div>
                <div style="font-size:12px;color:#6B6B8A;">📱 {seller_phone}</div>
            </div>
            <div style="margin-left:auto;">
                <span style="background:rgba(0,201,167,0.12);color:#00C9A7;
                             font-size:11px;font-weight:700;padding:4px 10px;
                             border-radius:8px;">✓ Verificado</span>
            </div>
        </div>
    </div>""", unsafe_allow_html=True)

    bc1, bc2, bc3 = st.columns(3)
    with bc1:
        st.button("💬 WhatsApp", use_container_width=True, type="primary")
    with bc2:
        st.button("📞 Llamar", use_container_width=True)
    with bc3:
        st.button("🔄 Proponer permuta", use_container_width=True)

    # Si es publicación propia del usuario
    if is_user_pub and st.session_state.logged_in:
        st.divider()
        st.markdown("**🔧 Gestionar mi publicación**")
        mc1, mc2, mc3 = st.columns(3)
        with mc1:
            st.button("✏️ Editar", use_container_width=True)
        with mc2:
            if st.button("🗑️ Eliminar", use_container_width=True):
                pub_id = v.get("id")
                st.session_state.user_publications = [
                    p for p in st.session_state.user_publications if p.get("id") != pub_id]
                st.session_state.history_items = [
                    h for h in st.session_state.history_items if h.get("id") != pub_id]
                st.session_state.page = "history"
                st.success("✅ Publicación eliminada")
                st.rerun()
        with mc3:
            st.button("📤 Compartir", use_container_width=True)

    # Reseñas
    st.divider()
    st.markdown("**⭐ Reseñas del vendedor**")
    reviews_data = [
        ("Carlos M.", 5, "Muy buen trato, vehículo tal como aparecía en fotos. ¡Recomendado!"),
        ("Ana G.", 4, "Proceso rápido y seguro. Respondió todos los mensajes al instante."),
        ("Pedro L.", 5, "Excelente vendedor, papeles al día y precio justo."),
    ]
    for rname, rrat, rtext in reviews_data:
        ri = "".join(w[0].upper() for w in rname.split()[:2])
        st.markdown(f"""
        <div style="display:flex;gap:12px;margin-bottom:14px;padding:14px;
                    background:#F4F5F7;border-radius:12px;">
            <div style="width:38px;height:38px;border-radius:19px;flex-shrink:0;
                        background:linear-gradient(135deg,#C41E3A,#1A1A2E);
                        display:flex;align-items:center;justify-content:center;
                        font-size:14px;font-weight:700;color:#fff;">{ri}</div>
            <div>
                <div style="font-weight:700;font-size:13px;">{rname}</div>
                <div style="font-size:13px;margin:2px 0;">{"⭐"*rrat}</div>
                <div style="font-size:13px;color:#6B6B8A;">{rtext}</div>
            </div>
        </div>""", unsafe_allow_html=True)

# ─── PAGE: PUBLISH ───────────────────────────────────────────────────────────
def page_publish():
    st.markdown("## ➕ Publicar vehículo")

    if not st.session_state.logged_in:
        st.markdown("""
        <div style="background:rgba(196,30,58,0.08);border:1.5px solid rgba(196,30,58,0.3);
                    border-radius:14px;padding:20px;text-align:center;margin-bottom:20px;">
            <div style="font-size:16px;font-weight:700;color:#C41E3A;margin-bottom:12px;">
                ⚠️ Debes tener una cuenta para publicar
            </div>
        </div>""", unsafe_allow_html=True)
        c1, c2 = st.columns(2)
        with c1:
            if st.button("🔐 Ingresar", type="primary", use_container_width=True):
                st.session_state.page = "login"; st.rerun()
        with c2:
            if st.button("📝 Registrarme", use_container_width=True):
                st.session_state.page = "register"; st.rerun()
        return

    # Tarjeta vendedor
    initials = "".join(w[0].upper() for w in st.session_state.user_name.split()[:2])
    st.markdown(f"""
    <div style="background:linear-gradient(135deg,#1A1A2E,#2E2E5A);
                border-radius:16px;padding:18px;margin-bottom:20px;
                display:flex;gap:14px;align-items:center;">
        <div style="width:52px;height:52px;border-radius:26px;
                    background:linear-gradient(135deg,#C41E3A,#9B1729);
                    display:flex;align-items:center;justify-content:center;
                    font-size:22px;font-weight:700;color:#fff;flex-shrink:0;">{initials}</div>
        <div style="flex:1;">
            <div style="font-size:11px;color:rgba(255,255,255,0.5);
                        text-transform:uppercase;letter-spacing:1px;font-weight:700;">Publicado por</div>
            <div style="font-size:16px;font-weight:700;color:#fff;margin-top:2px;">
                {st.session_state.user_name}</div>
            <div style="font-size:12px;color:rgba(255,255,255,0.55);margin-top:4px;">
                📱 {st.session_state.user_phone or '300 512 3456'} &nbsp;·&nbsp;
                📍 {st.session_state.user_city}</div>
        </div>
        <div style="background:rgba(0,201,167,0.2);border:1px solid rgba(0,201,167,0.4);
                    border-radius:8px;padding:5px 10px;font-size:11px;
                    font-weight:700;color:#00C9A7;">✓ Verificado</div>
    </div>""", unsafe_allow_html=True)

    with st.form("publish_form", clear_on_submit=True):
        # ── MULTIMEDIA ──
        st.markdown("#### 📸 Fotos y video del vehículo")
        mc1, mc2 = st.columns(2)
        with mc1:
            fotos_files = st.file_uploader(
                "📷 Fotos (máx. 10)",
                type=["jpg","jpeg","png","webp"],
                accept_multiple_files=True,
                key="pub_fotos",
                help="JPG, PNG, WEBP · Máximo 10 fotos"
            )
        with mc2:
            video_file = st.file_uploader(
                "🎥 Video (máx. 60 seg)",
                type=["mp4","mov","avi","webm"],
                key="pub_video",
                help="MP4, MOV · Máximo 100 MB"
            )

        # Preview fotos
        if fotos_files:
            st.markdown(f"**{len(fotos_files)} foto(s) seleccionada(s)**")
            preview_cols = st.columns(min(len(fotos_files), 5))
            for pi, pf in enumerate(fotos_files[:5]):
                with preview_cols[pi]:
                    img = Image.open(pf)
                    st.image(img, use_container_width=True,
                             caption="📌 Portada" if pi == 0 else f"Foto {pi+1}")
        if video_file:
            st.video(video_file)
            st.success(f"🎥 Video: {video_file.name}")

        st.divider()

        # ── INFO VEHÍCULO ──
        st.markdown("#### 📋 Información del vehículo")
        pc1, pc2 = st.columns(2)
        with pc1:
            pub_tipo = st.selectbox("Tipo de anuncio",
                                    ["Venta","Permuta","Venta y Permuta"], key="pub_tipo")
            pub_marca = st.selectbox("Marca",
                ["Toyota","Chevrolet","Renault","Mazda","Hyundai","Kia","Ford",
                 "Volkswagen","BMW","Mercedes-Benz","Nissan","Honda","Suzuki","Jeep"],
                key="pub_marca")
            pub_modelo = st.text_input("Modelo *", placeholder="Ej: Corolla XEI, Tracker Premier...",
                                       key="pub_modelo")
            pub_anio = st.selectbox("Año",
                ["2025","2024","2023","2022","2021","2020","2019","2018","2017","2016","2015"],
                key="pub_anio")
            pub_km = st.number_input("Kilometraje (km) *", min_value=0, max_value=500000,
                                     step=1000, key="pub_km")
        with pc2:
            pub_combustible = st.selectbox("Combustible",
                ["Gasolina","Diesel","Híbrido","Eléctrico","Gas"], key="pub_comb")
            pub_transmision = st.selectbox("Transmisión",
                ["Automático","Manual"], key="pub_trans")
            pub_ciudad = st.selectbox("Ciudad",
                ["Bogotá","Medellín","Cali","Barranquilla","Bucaramanga","Pereira","Cartagena"],
                key="pub_ciudad")
            pub_color = st.text_input("Color", placeholder="Ej: Blanco, Gris, Negro...",
                                      key="pub_color")
            pub_precio = st.number_input("Precio (COP) *", min_value=0, max_value=2000000000,
                                         step=1000000, key="pub_precio",
                                         format="%d")
            if pub_precio > 0:
                st.markdown(f"<div style='color:#C41E3A;font-weight:700;font-size:14px;'>$ {pub_precio/1_000_000:.1f} millones</div>", unsafe_allow_html=True)

        pub_desc = st.text_area("Descripción",
                                placeholder="Describe el estado, extras, historial de mantenimiento...",
                                height=100, key="pub_desc")

        st.divider()

        # ── CONTACTO ──
        st.markdown("#### 👤 Datos de contacto del vendedor")
        st.caption("Estos datos serán visibles para los compradores interesados")
        cc1, cc2, cc3 = st.columns(3)
        with cc1:
            pub_seller_name = st.text_input("Nombre", value=st.session_state.user_name,
                                            key="pub_sname")
        with cc2:
            pub_seller_phone = st.text_input("Celular",
                                             value=st.session_state.user_phone or "300 512 3456",
                                             key="pub_sphone")
        with cc3:
            pub_seller_email = st.text_input("Correo",
                                             value=st.session_state.user_email,
                                             key="pub_semail")
        pub_whatsapp = st.checkbox("✅ Permitir contacto por WhatsApp", value=True, key="pub_wa")

        st.divider()
        submitted = st.form_submit_button("🚀 Publicar vehículo", use_container_width=True,
                                           type="primary")

        if submitted:
            errors = []
            if not pub_modelo.strip(): errors.append("Modelo del vehículo")
            if pub_precio <= 0: errors.append("Precio del vehículo")
            if not fotos_files and not video_file: errors.append("Al menos una foto o video")

            if errors:
                st.error(f"❌ Campos requeridos: {', '.join(errors)}")
            else:
                # Procesar fotos
                fotos_data = []
                if fotos_files:
                    for ff in fotos_files[:10]:
                        ff.seek(0)
                        fotos_data.append({
                            "name": ff.name,
                            "bytes": ff.read(),
                        })

                video_data = None
                if video_file:
                    video_file.seek(0)
                    video_data = {"name": video_file.name, "bytes": video_file.read()}

                tipo_map_inv = {"Venta":"venta","Permuta":"permuta","Venta y Permuta":"ambos"}
                cat_guess = "sedan"
                if pub_marca in ["Ford","Toyota","Renault","Chevrolet"] and "Ranger" in pub_modelo or "Oroch" in pub_modelo:
                    cat_guess = "pickup"
                elif any(x in pub_modelo for x in ["SUV","CX","Tracker","Tucson","Sportage","Wrangler","Explorer"]):
                    cat_guess = "suv"

                new_pub = {
                    "id": f"PUB-{int(datetime.now().timestamp())}",
                    "name": pub_marca,
                    "model": pub_modelo,
                    "modelo": pub_modelo,
                    "marca": pub_marca,
                    "year": int(pub_anio),
                    "anio": pub_anio,
                    "price": pub_precio,
                    "precio": pub_precio,
                    "km": pub_km,
                    "fuel": pub_combustible,
                    "comb": pub_combustible,
                    "trans": pub_transmision,
                    "city": pub_ciudad,
                    "ciudad": pub_ciudad,
                    "color": pub_color or "No especificado",
                    "type": tipo_map_inv.get(pub_tipo, "venta"),
                    "tipo": pub_tipo,
                    "cat": cat_guess,
                    "rating": 0,
                    "reviews": 0,
                    "desc": pub_desc,
                    "description": pub_desc,
                    "seller": pub_seller_name,
                    "phone": pub_seller_phone,
                    "seller_phone": pub_seller_phone,
                    "email": pub_seller_email,
                    "seller_email": pub_seller_email,
                    "fotos": fotos_data,
                    "video": video_data,
                    "fecha": datetime.now().strftime("%d/%m/%Y"),
                    "date": datetime.now().strftime("%d %b %Y"),
                    "isUserPub": True,
                    "grad": 0,
                    "whatsapp": pub_whatsapp,
                    "status": "activo",
                }

                st.session_state.user_publications.insert(0, new_pub)
                st.session_state.history_items.insert(0, {
                    "id": new_pub["id"],
                    "name": f"{pub_marca} {pub_modelo} {pub_anio}",
                    "price": pub_precio,
                    "date": new_pub["date"],
                    "status": "activo",
                    "type": pub_tipo,
                    "km": pub_km,
                    "pubRef": new_pub,
                })
                st.session_state.loyalty_points += 50
                st.session_state.selected_vehicle = new_pub
                st.session_state.page = "vehicle_detail"
                st.success("🎉 ¡Vehículo publicado con éxito!")
                st.rerun()

# ─── PAGE: HISTORY ────────────────────────────────────────────────────────────
def page_history():
    st.markdown("## 📋 Mis avisos")

    if not st.session_state.logged_in:
        st.info("🔐 Inicia sesión para ver tus publicaciones")
        if st.button("Ingresar", type="primary"):
            st.session_state.page = "login"; st.rerun()
        return

    col_h, col_btn = st.columns([3,1])
    with col_h:
        tab_filter = st.radio("Filtrar por:", ["Todos","Activos","Pendientes","Cerrados"],
                               horizontal=True, key="hist_tab")
    with col_btn:
        if st.button("➕ Nueva publicación", type="primary", use_container_width=True):
            st.session_state.page = "publish"; st.rerun()

    filter_map = {"Todos":None,"Activos":"activo","Pendientes":"pendiente","Cerrados":"completado"}
    sel = filter_map[tab_filter]
    items = st.session_state.history_items
    if sel: items = [h for h in items if h.get("status") == sel]

    if not items:
        st.markdown("""
        <div style="text-align:center;padding:60px 20px;color:#6B6B8A;">
            <div style="font-size:48px;margin-bottom:12px;">📋</div>
            <div style="font-size:18px;font-weight:700;margin-bottom:8px;">Sin avisos</div>
            <div style="font-size:14px;">No tienes avisos en esta categoría</div>
        </div>""", unsafe_allow_html=True)
        return

    status_colors = {
        "activo": ("#00C9A7","#E0FAF6","ACTIVO"),
        "pendiente": ("#F5A623","#FEF6E4","PENDIENTE"),
        "completado": ("#2979FF","#E3EDFF","CERRADO"),
        "cancelled": ("#E53935","#FDEAED","CANCELADO"),
    }

    for h in items:
        sc = h.get("status","activo")
        sfg, sbg, slabel = status_colors.get(sc, ("#6B6B8A","#F4F5F7","ESTADO"))
        can_delete = sc in ("activo","pendiente")

        with st.container():
            st.markdown(f"""
            <div style="background:#fff;border-radius:14px;padding:16px;
                        box-shadow:0 4px 20px rgba(26,26,46,0.08);margin-bottom:12px;">
                <div style="display:flex;justify-content:space-between;align-items:flex-start;">
                    <div style="flex:1;">
                        <div style="font-weight:700;font-size:15px;">{h.get('name','')}</div>
                        <div style="font-size:12px;color:#6B6B8A;margin-top:2px;">
                            {h.get('date','')} · {h.get('type','')}
                        </div>
                        <div style="font-size:22px;font-weight:800;color:#C41E3A;margin-top:6px;">
                            ${h.get('price',0)/1_000_000:.0f} M
                        </div>
                    </div>
                    <div style="background:{sbg};color:{sfg};font-size:10px;font-weight:700;
                                padding:4px 10px;border-radius:8px;white-space:nowrap;">
                        {slabel}
                    </div>
                </div>
            </div>""", unsafe_allow_html=True)

            hc1, hc2, hc3 = st.columns(3) if can_delete else st.columns([1,1,1])
            with hc1:
                if st.button("👁️ Ver aviso", key=f"hist_view_{h['id']}", use_container_width=True):
                    ref = h.get("pubRef")
                    if ref:
                        st.session_state.selected_vehicle = ref
                        st.session_state.page = "vehicle_detail"
                        st.rerun()
                    else:
                        # Buscar en vehicles
                        found = next((v for v in VEHICLES if v["name"] in h.get("name","")), None)
                        if found:
                            st.session_state.selected_vehicle = found
                            st.session_state.page = "vehicle_detail"
                            st.rerun()
            if can_delete:
                with hc2:
                    st.button("✏️ Editar", key=f"hist_edit_{h['id']}", use_container_width=True)
                with hc3:
                    if st.button("🗑️ Eliminar", key=f"hist_del_{h['id']}", use_container_width=True):
                        hid = h["id"]
                        st.session_state.history_items = [
                            x for x in st.session_state.history_items if x["id"] != hid]
                        st.session_state.user_publications = [
                            p for p in st.session_state.user_publications if p.get("id") != hid]
                        st.success("✅ Publicación eliminada")
                        st.rerun()
            else:
                with hc2:
                    st.button("🔁 Republicar", key=f"hist_rep_{h['id']}", use_container_width=True)

# ─── PAGE: NOTIFICATIONS ─────────────────────────────────────────────────────
def page_notifications():
    st.markdown("## 🔔 Notificaciones")

    col_h, col_b = st.columns([3,1])
    with col_b:
        if st.button("✓ Marcar todas leídas", use_container_width=True):
            for n in st.session_state.notifications:
                n["unread"] = False
            st.session_state.notif_count = 0
            st.success("Todas las notificaciones leídas ✓")
            st.rerun()

    unread = [n for n in st.session_state.notifications if n.get("unread")]
    if unread:
        st.markdown(f"""
        <div style="background:rgba(196,30,58,0.08);border-radius:10px;
                    padding:10px 16px;margin-bottom:16px;font-size:13px;color:#C41E3A;font-weight:600;">
            🔴 Tienes {len(unread)} notificación{'es' if len(unread)>1 else ''} sin leer
        </div>""", unsafe_allow_html=True)

    icon_map = {
        "chat": "💬", "eye": "👁️", "swap": "🔄", "star": "⭐",
        "check": "✅", "bell": "🔔", "points": "🏆", "heart": "❤️",
        "message": "✉️", "visit": "👁️", "permuta": "🔄", "review": "⭐",
        "system": "⚙️", "alert": "⚠️",
    }

    groups = {}
    for n in st.session_state.notifications:
        g = n.get("group","General")
        if g not in groups: groups[g] = []
        groups[g].append(n)

    for group, items in groups.items():
        st.markdown(f"**{group}**")
        for n in items:
            icon = icon_map.get(n.get("icon","bell"), "🔔")
            unread_style = "border-left:4px solid #C41E3A;" if n.get("unread") else ""
            bg = "rgba(196,30,58,0.04)" if n.get("unread") else "#fff"
            st.markdown(f"""
            <div style="background:{bg};border-radius:12px;padding:14px;
                        margin-bottom:8px;box-shadow:0 2px 10px rgba(26,26,46,0.06);
                        {unread_style}display:flex;gap:12px;align-items:flex-start;">
                <div style="font-size:22px;flex-shrink:0;">{icon}</div>
                <div style="flex:1;">
                    <div style="font-weight:{'700' if n.get('unread') else '600'};font-size:14px;">
                        {n.get('title','')}</div>
                    <div style="font-size:13px;color:#6B6B8A;margin-top:2px;">{n.get('desc','')}</div>
                    <div style="font-size:11px;color:#9999BB;margin-top:4px;">{n.get('time','')}</div>
                </div>
                {f'<div style="width:8px;height:8px;border-radius:4px;background:#C41E3A;flex-shrink:0;margin-top:4px;"></div>' if n.get('unread') else ''}
            </div>""", unsafe_allow_html=True)

# ─── PAGE: SUPPORT (CHAT) ────────────────────────────────────────────────────
def page_support():
    st.markdown("## 💬 Soporte JJGT")

    st.markdown("""
    <div style="background:linear-gradient(135deg,#C41E3A,#1A1A2E);border-radius:16px;
                padding:20px;margin-bottom:20px;text-align:center;color:#fff;">
        <div style="font-size:22px;font-weight:800;margin-bottom:4px;">¿Necesitas ayuda?</div>
        <div style="font-size:13px;opacity:0.7;margin-bottom:16px;">Lun–Sáb 8:00am – 6:00pm</div>
        <div style="display:flex;gap:10px;justify-content:center;flex-wrap:wrap;">
            <span>📞 Llamar</span> · <span>💬 WhatsApp</span> · <span>✉️ Email</span>
        </div>
    </div>""", unsafe_allow_html=True)

    # Chat
    st.markdown("**🤖 Asistente virtual JJGT**")

    if not st.session_state.chat_messages:
        st.session_state.chat_messages = [{
            "role": "bot",
            "text": "¡Hola! Soy el asistente de JJGT 🚗. ¿En qué puedo ayudarte hoy?"
        }]

    chat_container = st.container()
    with chat_container:
        for msg in st.session_state.chat_messages:
            if msg["role"] == "bot":
                st.markdown(f"""
                <div style="display:flex;gap:10px;margin-bottom:10px;">
                    <div style="width:32px;height:32px;border-radius:16px;flex-shrink:0;
                                background:linear-gradient(135deg,#C41E3A,#1A1A2E);
                                display:flex;align-items:center;justify-content:center;
                                font-size:14px;">🚗</div>
                    <div style="background:#F4F5F7;border-radius:0 12px 12px 12px;
                                padding:12px 16px;max-width:75%;font-size:14px;
                                line-height:1.5;">{msg['text']}</div>
                </div>""", unsafe_allow_html=True)
            else:
                st.markdown(f"""
                <div style="display:flex;justify-content:flex-end;margin-bottom:10px;">
                    <div style="background:linear-gradient(135deg,#C41E3A,#9B1729);
                                color:#fff;border-radius:12px 0 12px 12px;
                                padding:12px 16px;max-width:75%;font-size:14px;
                                line-height:1.5;">{msg['text']}</div>
                </div>""", unsafe_allow_html=True)

    # Respuestas rápidas
    st.markdown("**Preguntas frecuentes:**")
    qr_cols = st.columns(3)
    quick_replies = [
        ("¿Cómo publico?", "publicar"),
        ("¿Cómo hago una permuta?", "permuta"),
        ("Verificar precio", "precio"),
        ("Documentos requeridos", "soat"),
        ("Pagos seguros", "pago"),
        ("Hablar con agente", "default"),
    ]
    for i, (label, key) in enumerate(quick_replies):
        with qr_cols[i % 3]:
            if st.button(label, key=f"qr_{key}", use_container_width=True):
                st.session_state.chat_messages.append({"role":"user","text":label})
                reply = CHATBOT_REPLIES.get(key, CHATBOT_REPLIES["default"])
                st.session_state.chat_messages.append({"role":"bot","text":reply})
                st.rerun()

    # Input
    with st.form("chat_form", clear_on_submit=True):
        ci1, ci2 = st.columns([4,1])
        with ci1:
            user_msg = st.text_input("Escribe tu mensaje...", key="chat_in", label_visibility="collapsed")
        with ci2:
            send = st.form_submit_button("Enviar →", use_container_width=True, type="primary")
        if send and user_msg.strip():
            st.session_state.chat_messages.append({"role":"user","text":user_msg.strip()})
            key = next((k for k in CHATBOT_REPLIES if k in user_msg.lower()), "default")
            st.session_state.chat_messages.append({"role":"bot","text":CHATBOT_REPLIES[key]})
            st.rerun()

    # FAQ
    st.divider()
    st.markdown("**📚 Recursos de ayuda**")
    faqs = [
        ("¿Cómo publico un vehículo?",
         "Ve a 'Publicar' en el menú, completa los datos, agrega fotos/video y establece el precio. Tu aviso será revisado en menos de 2 horas."),
        ("¿Qué es una permuta?",
         "Es el intercambio de tu vehículo por otro. Propones tu carro a cambio del que te interesa, con o sin diferencia de precio."),
        ("¿Es seguro negociar en JJGT?",
         "Verificamos identidad de usuarios y historial de vehículos. Siempre revisa el vehículo en persona antes de cerrar el trato."),
        ("¿Cuánto cuesta publicar?",
         "¡Es completamente gratis! Puedes tener hasta 3 avisos activos simultáneamente sin ningún costo."),
        ("¿Cómo funciona el programa de puntos?",
         "Ganas puntos por publicar, completar ventas, invitar amigos y mantener tu perfil verificado. Canjéalos por avisos destacados."),
    ]
    for q, a in faqs:
        with st.expander(q):
            st.markdown(a)

# ─── PAGE: PROFILE ───────────────────────────────────────────────────────────
def page_profile():
    if not st.session_state.logged_in:
        st.markdown("## 👤 Mi Perfil")
        st.info("🔐 Inicia sesión para ver tu perfil")
        c1, c2 = st.columns(2)
        with c1:
            if st.button("Ingresar", type="primary", use_container_width=True):
                st.session_state.page = "login"; st.rerun()
        with c2:
            if st.button("Crear cuenta", use_container_width=True):
                st.session_state.page = "register"; st.rerun()
        return

    # Header
    initials = "".join(w[0].upper() for w in st.session_state.user_name.split()[:2])
    st.markdown(f"""
    <div style="background:linear-gradient(135deg,#C41E3A,#1A1A2E);border-radius:20px;
                padding:28px;margin-bottom:20px;text-align:center;color:#fff;">
        <div style="width:72px;height:72px;border-radius:36px;margin:0 auto 12px;
                    background:linear-gradient(135deg,#E8384F,#9B1729);
                    display:flex;align-items:center;justify-content:center;
                    font-size:28px;font-weight:700;
                    box-shadow:0 4px 20px rgba(0,0,0,0.3);">{initials}</div>
        <div style="font-size:22px;font-weight:800;">{st.session_state.user_name}</div>
        <div style="font-size:13px;opacity:0.7;margin-top:4px;">{st.session_state.user_email}</div>
        <div style="display:flex;justify-content:center;gap:28px;margin-top:18px;">
            <div style="text-align:center;">
                <div style="font-size:26px;font-weight:800;">{len(st.session_state.history_items)}</div>
                <div style="font-size:11px;opacity:0.6;">Avisos</div>
            </div>
            <div style="width:1px;background:rgba(255,255,255,0.2);"></div>
            <div style="text-align:center;">
                <div style="font-size:26px;font-weight:800;">
                    {sum(1 for h in st.session_state.history_items if h.get('status')=='completado')}</div>
                <div style="font-size:11px;opacity:0.6;">Ventas</div>
            </div>
            <div style="width:1px;background:rgba(255,255,255,0.2);"></div>
            <div style="text-align:center;">
                <div style="font-size:26px;font-weight:800;">{st.session_state.loyalty_points}</div>
                <div style="font-size:11px;opacity:0.6;">Puntos</div>
            </div>
        </div>
    </div>""", unsafe_allow_html=True)

    # Tarjeta de lealtad
    pts = st.session_state.loyalty_points
    next_pts = 500
    progress = min(pts / next_pts, 1.0)
    st.markdown(f"""
    <div style="background:linear-gradient(135deg,#1A1A2E,#2E2E5A);border-radius:18px;
                padding:22px;margin-bottom:20px;color:#fff;position:relative;overflow:hidden;">
        <div style="position:absolute;right:-10px;top:-10px;font-size:80px;opacity:0.04;
                    font-weight:900;font-family:'Arial Black';">JJGT</div>
        <div style="font-size:11px;font-weight:700;letter-spacing:2px;
                    color:#F5A623;text-transform:uppercase;">⭐ Miembro {st.session_state.loyalty_level}</div>
        <div style="font-size:13px;opacity:0.5;margin-top:6px;">Puntos acumulados</div>
        <div style="font-size:46px;font-weight:900;letter-spacing:1px;">{pts} pts</div>
        <div style="display:flex;justify-content:space-between;margin-top:12px;margin-bottom:6px;font-size:11px;opacity:0.5;">
            <span>Silver ({pts} pts)</span><span>Gold ({next_pts} pts)</span>
        </div>
        <div style="height:8px;background:rgba(255,255,255,0.1);border-radius:4px;">
            <div style="height:100%;width:{progress*100:.0f}%;border-radius:4px;
                        background:linear-gradient(90deg,#F5A623,#C41E3A);"></div>
        </div>
        <div style="margin-top:16px;display:flex;justify-content:space-between;align-items:center;">
            <div style="font-size:12px;opacity:0.6;">Código referido:</div>
            <div style="background:rgba(255,255,255,0.1);padding:6px 14px;border-radius:8px;
                        font-size:13px;font-weight:700;letter-spacing:2px;">JJGT-JCG</div>
        </div>
    </div>""", unsafe_allow_html=True)

    # Menú opciones
    st.markdown("**⚙️ Configuración del perfil**")
    profile_options = [
        ("👤", "Mis datos", "mydata"),
        ("📍", "Mis ciudades", "cities"),
        ("🔔", "Notificaciones", "notifconfig"),
        ("🔒", "Privacidad", "privacy"),
        ("❓", "Ayuda y soporte", "help"),
    ]
    for icon, label, key in profile_options:
        col1, col2 = st.columns([10,1])
        with col1:
            if st.button(f"{icon} {label}", key=f"prof_{key}", use_container_width=True):
                st.session_state.profile_tab = key
                st.session_state.page = f"profile_{key}"
                st.rerun()
        with col2:
            st.markdown("›")

    # Tema
    st.divider()
    dark = st.toggle("🌙 Modo oscuro", value=st.session_state.dark_mode, key="dark_toggle")
    st.session_state.dark_mode = dark

    st.divider()
    if st.button("🚪 Cerrar sesión", use_container_width=True):
        st.session_state.logged_in = False
        st.session_state.user_name = ""
        st.session_state.page = "home"
        st.rerun()

# ─── PAGE: PROFILE - MIS DATOS ──────────────────────────────────────────────
def page_profile_mydata():
    if st.button("← Volver al perfil"): st.session_state.page="profile"; st.rerun()
    st.markdown("## 👤 Mis datos")

    initials = "".join(w[0].upper() for w in st.session_state.user_name.split()[:2])
    st.markdown(f"""
    <div style="background:linear-gradient(135deg,#C41E3A,#1A1A2E);border-radius:16px;
                padding:28px;text-align:center;color:#fff;margin-bottom:20px;">
        <div style="width:72px;height:72px;border-radius:36px;margin:0 auto 12px;
                    background:rgba(255,255,255,0.15);
                    display:flex;align-items:center;justify-content:center;
                    font-size:28px;font-weight:700;">{initials}</div>
        <div style="font-size:13px;opacity:0.6;">Toca el avatar para cambiar tu foto</div>
    </div>""", unsafe_allow_html=True)

    st.markdown("**ℹ️ Información personal**")
    with st.form("mydata_form"):
        n1, n2 = st.columns(2)
        with n1:
            new_name = st.text_input("Nombre completo", value=st.session_state.user_name)
            new_email = st.text_input("Correo electrónico", value=st.session_state.user_email)
            new_phone = st.text_input("Celular", value=st.session_state.user_phone or "300 512 3456")
        with n2:
            new_doc = st.text_input("Documento de identidad", value="10.234.567")
            new_birth = st.date_input("Fecha de nacimiento")
            new_city = st.selectbox("Ciudad principal",
                ["Bogotá","Medellín","Cali","Barranquilla","Bucaramanga","Pereira","Cartagena"],
                index=["Bogotá","Medellín","Cali","Barranquilla","Bucaramanga","Pereira","Cartagena"].index(
                    st.session_state.user_city) if st.session_state.user_city in
                    ["Bogotá","Medellín","Cali","Barranquilla","Bucaramanga","Pereira","Cartagena"] else 0)

        if st.form_submit_button("💾 Guardar cambios", type="primary", use_container_width=True):
            st.session_state.user_name = new_name
            st.session_state.user_email = new_email
            st.session_state.user_phone = new_phone
            st.session_state.user_city = new_city
            st.success("✅ Datos actualizados con éxito")

    st.divider()
    st.markdown("**🔐 Verificación de cuenta**")
    verifs = [
        ("📱 Celular", "300 512 3456", True, "Verificado"),
        ("✉️ Correo", st.session_state.user_email, False, "Pendiente"),
        ("🪪 Cédula", "10.234.567", False, "Sin verificar"),
    ]
    for vicon, vval, vdone, vstatus in verifs:
        vc1, vc2 = st.columns([3,1])
        with vc1:
            color = "#00C9A7" if vdone else "#F5A623" if vstatus=="Pendiente" else "#E53935"
            st.markdown(f"""
            <div style="background:#F4F5F7;border-radius:12px;padding:12px 16px;margin-bottom:8px;
                        display:flex;justify-content:space-between;align-items:center;">
                <div>
                    <div style="font-weight:600;font-size:14px;">{vicon} {vstatus}</div>
                    <div style="font-size:12px;color:#6B6B8A;">{vval}</div>
                </div>
                <div style="color:{color};font-weight:700;font-size:12px;">
                    {'✅' if vdone else '⚠️'} {vstatus}
                </div>
            </div>""", unsafe_allow_html=True)
        if not vdone:
            with vc2:
                if st.button("Verificar", key=f"verif_{vstatus}", use_container_width=True):
                    st.success(f"Enlace enviado ✓")

# ─── PAGE: PROFILE - MIS CIUDADES ───────────────────────────────────────────
def page_profile_cities():
    if st.button("← Volver al perfil"): st.session_state.page="profile"; st.rerun()
    st.markdown("## 📍 Mis ciudades")

    st.info("💡 Configura tus ciudades de interés y recibirás alertas cuando haya vehículos nuevos.")

    st.markdown("**Ciudades activas**")
    all_cities = ["Bogotá","Medellín","Cali","Barranquilla","Bucaramanga","Pereira",
                  "Cartagena","Manizales","Ibagué","Pasto","Cúcuta","Villavicencio"]
    city_veh_count = {"Bogotá":847,"Medellín":215,"Cali":178,"Barranquilla":93,
                      "Bucaramanga":112,"Pereira":67}

    to_remove = []
    for city in st.session_state.active_cities:
        cc1, cc2 = st.columns([4,1])
        with cc1:
            count = city_veh_count.get(city, 0)
            is_main = city == st.session_state.active_cities[0]
            st.markdown(f"""
            <div style="background:#fff;border-radius:12px;padding:14px 16px;margin-bottom:8px;
                        box-shadow:0 2px 10px rgba(26,26,46,0.06);
                        display:flex;align-items:center;gap:12px;">
                <span style="font-size:20px;">📍</span>
                <div style="flex:1;">
                    <div style="font-weight:700;font-size:14px;">{city}
                        {'<span style="background:rgba(196,30,58,0.1);color:#C41E3A;font-size:10px;padding:2px 8px;border-radius:10px;margin-left:8px;">Principal</span>' if is_main else ''}</div>
                    <div style="font-size:12px;color:#6B6B8A;">{count} vehículos disponibles</div>
                </div>
            </div>""", unsafe_allow_html=True)
        if not is_main:
            with cc2:
                if st.button("✕", key=f"rem_city_{city}", use_container_width=True):
                    to_remove.append(city)

    for c in to_remove:
        if c in st.session_state.active_cities:
            st.session_state.active_cities.remove(c)
            st.success(f"{c} eliminada ✓"); st.rerun()

    st.divider()
    st.markdown("**Agregar ciudad**")
    available = [c for c in all_cities if c not in st.session_state.active_cities]
    if available:
        city_to_add = st.selectbox("Selecciona una ciudad", available, key="city_add_sel")
        if st.button("➕ Agregar ciudad", type="primary"):
            st.session_state.active_cities.append(city_to_add)
            st.success(f"✅ {city_to_add} agregada"); st.rerun()
    else:
        st.success("🎉 Tienes todas las ciudades configuradas")

# ─── PAGE: PROFILE - NOTIFICACIONES CONFIG ───────────────────────────────────
def page_profile_notifconfig():
    if st.button("← Volver al perfil"): st.session_state.page="profile"; st.rerun()
    st.markdown("## 🔔 Configuración de notificaciones")

    # Stats
    c1, c2, c3 = st.columns(3)
    with c1:
        st.metric("Sin leer", st.session_state.notif_count)
    with c2:
        st.metric("Esta semana", 12, delta="+3")
    with c3:
        st.metric("Este mes", 48, delta="+15")

    st.divider()
    st.markdown("**Preferencias**")
    prefs = st.session_state.notif_prefs
    for key, label, desc in [
        ("mensajes","💬 Mensajes nuevos","Cuando alguien te escriba"),
        ("permutas","🔄 Propuestas de permuta","Ofertas de intercambio recibidas"),
        ("visitas","👁️ Visitas a mis avisos","Cuántas personas ven tus publicaciones"),
        ("nuevos","🚗 Nuevos vehículos","En tus ciudades de interés"),
        ("resenas","⭐ Reseñas","Cuando alguien califique tu perfil"),
        ("push","📱 Notificaciones push","Alertas en tu dispositivo"),
    ]:
        nc1, nc2 = st.columns([4,1])
        with nc1:
            st.markdown(f"""
            <div style="padding:10px 0;">
                <div style="font-weight:600;font-size:14px;">{label}</div>
                <div style="font-size:12px;color:#6B6B8A;">{desc}</div>
            </div>""", unsafe_allow_html=True)
        with nc2:
            val = st.toggle("", value=prefs.get(key, True), key=f"notif_{key}")
            prefs[key] = val
    st.session_state.notif_prefs = prefs

    st.divider()
    st.markdown("**Últimas notificaciones**")
    page_notifications()

# ─── PAGE: PROFILE - PRIVACIDAD ──────────────────────────────────────────────
def page_profile_privacy():
    if st.button("← Volver al perfil"): st.session_state.page="profile"; st.rerun()
    st.markdown("## 🔒 Privacidad y seguridad")

    st.markdown("""
    <div style="background:rgba(41,121,255,0.08);border:1.5px solid rgba(41,121,255,0.2);
                border-radius:14px;padding:18px;margin-bottom:20px;">
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:8px;">
            <span style="font-size:22px;">🛡️</span>
            <div style="font-weight:700;font-size:15px;">Tu privacidad importa</div>
        </div>
        <div style="font-size:13px;color:#6B6B8A;line-height:1.5;">
            En JJGT tu información es tuya. Solo compartimos lo necesario para que puedas
            vender y permutar con confianza.
        </div>
    </div>""", unsafe_allow_html=True)

    st.markdown("**👁️ Visibilidad del perfil**")
    priv_opts = [
        ("Mostrar mi número de celular", True),
        ("Mostrar correo electrónico", False),
        ("Perfil público", True),
        ("Mostrar ciudad exacta", True),
    ]
    for label, default in priv_opts:
        st.toggle(label, value=default, key=f"priv_{label[:20]}")

    st.divider()
    st.markdown("**🔐 Seguridad de la cuenta**")
    sc1, sc2 = st.columns(2)
    with sc1:
        if st.button("🔑 Cambiar contraseña", use_container_width=True):
            st.success("✉️ Enlace enviado a tu correo")
        if st.button("📱 Verificación en dos pasos", use_container_width=True):
            st.success("✅ Autenticación de dos pasos activada")
    with sc2:
        if st.button("📲 Dispositivos activos", use_container_width=True):
            st.info("ℹ️ 1 dispositivo con sesión activa")

    st.divider()
    st.markdown("**📦 Datos y cuenta**")
    dc1, dc2 = st.columns(2)
    with dc1:
        if st.button("⬇️ Descargar mis datos", use_container_width=True):
            st.success("📧 Recibirás tu información en 24h")
    with dc2:
        if st.button("🗑️ Eliminar cuenta", use_container_width=True, type="secondary"):
            st.warning("⚠️ Esta acción es irreversible. Contacta soporte para eliminar tu cuenta.")

# ─── PAGE: PROFILE - AYUDA ──────────────────────────────────────────────────
def page_profile_help():
    if st.button("← Volver al perfil"): st.session_state.page="profile"; st.rerun()
    page_support()

# ─── PAGE: PERMUTAS ──────────────────────────────────────────────────────────
def page_permutas():
    st.markdown("## 🔄 Permutas activas")
    st.markdown("Encuentra propuestas de intercambio de vehículos en toda Colombia.")

    permutas_vehs = [v for v in VEHICLES if v["type"] in ("permuta","ambos")]

    for v in permutas_vehs:
        with st.container():
            pc1, pc2, pc3 = st.columns([2,2,1])
            price = v.get("price",0)
            with pc1:
                st.markdown(f"""
                <div style="background:#F4F5F7;border-radius:12px;padding:14px;">
                    <div style="font-weight:700;font-size:15px;">{v['name']} {v['model']}</div>
                    <div style="font-size:13px;color:#6B6B8A;">{v['year']} · {v['city']} · {v['km']:,} km</div>
                    <div style="font-size:22px;font-weight:800;color:#C41E3A;">${price/1_000_000:.0f}M</div>
                </div>""", unsafe_allow_html=True)
            with pc2:
                st.markdown("""
                <div style="text-align:center;padding:20px;">
                    <div style="font-size:28px;">⇄</div>
                    <div style="font-size:12px;color:#6B6B8A;margin-top:4px;">Intercambio</div>
                </div>""", unsafe_allow_html=True)
            with pc3:
                if st.button("Ver detalle", key=f"perm_det_{v['id']}", use_container_width=True):
                    st.session_state.selected_vehicle = v
                    st.session_state.page = "vehicle_detail"
                    st.rerun()
                if st.button("Proponer", key=f"perm_prop_{v['id']}", type="primary",
                             use_container_width=True):
                    if not st.session_state.logged_in:
                        st.error("Inicia sesión primero")
                    else:
                        st.success(f"✅ Propuesta enviada para {v['name']} {v['model']}")
            st.divider()

# ─── PAGE: LOGIN ─────────────────────────────────────────────────────────────
def page_login():
    col_center = st.columns([1,2,1])[1]
    with col_center:
        st.markdown("""
        <div style="text-align:center;padding:30px 0 20px;">
            <div style="font-size:64px;font-weight:900;letter-spacing:6px;
                        background:linear-gradient(135deg,#C41E3A,#F5A623);
                        -webkit-background-clip:text;-webkit-text-fill-color:transparent;">
                JJGT</div>
            <div style="font-size:12px;color:#6B6B8A;letter-spacing:2px;margin-top:4px;">
                VEHÍCULOS COLOMBIA</div>
        </div>""", unsafe_allow_html=True)

        st.markdown("### Ingresar a tu cuenta")

        with st.form("login_form"):
            email = st.text_input("✉️ Correo electrónico", placeholder="correo@ejemplo.com")
            password = st.text_input("🔑 Contraseña", type="password", placeholder="Tu contraseña")
            remember = st.checkbox("Recordarme")
            submitted = st.form_submit_button("🚀 Ingresar", use_container_width=True, type="primary")

            if submitted:
                if not email or not password:
                    st.error("❌ Completa todos los campos")
                else:
                    name = email.split("@")[0].replace(".", " ").replace("_", " ").title()
                    st.session_state.logged_in = True
                    st.session_state.user_name = name
                    st.session_state.user_email = email
                    st.session_state.page = "home"
                    st.success(f"✅ ¡Bienvenido {name}!")
                    st.rerun()

        st.markdown("""
        <div style="text-align:center;padding:10px 0;">
            <div style="font-size:13px;color:#6B6B8A;">¿No tienes cuenta?</div>
        </div>""", unsafe_allow_html=True)

        c1, c2 = st.columns(2)
        with c1:
            if st.button("📝 Crear cuenta", use_container_width=True):
                st.session_state.page = "register"; st.rerun()
        with c2:
            if st.button("🔓 Recuperar contraseña", use_container_width=True):
                st.session_state.page = "forgot"; st.rerun()

        st.divider()
        st.markdown("**O continúa con:**")
        g1, g2 = st.columns(2)
        with g1:
            st.button("🔵 Google", use_container_width=True)
        with g2:
            st.button("⚫ Apple", use_container_width=True)

        if st.button("🏠 Volver al inicio", use_container_width=True):
            st.session_state.page = "home"; st.rerun()

# ─── PAGE: REGISTER ──────────────────────────────────────────────────────────
def page_register():
    col_center = st.columns([1,2,1])[1]
    with col_center:
        st.markdown("""
        <div style="text-align:center;padding:20px 0;">
            <div style="font-size:48px;font-weight:900;letter-spacing:4px;
                        background:linear-gradient(135deg,#C41E3A,#F5A623);
                        -webkit-background-clip:text;-webkit-text-fill-color:transparent;">
                JJGT</div>
        </div>""", unsafe_allow_html=True)
        st.markdown("### Crear cuenta")

        with st.form("register_form"):
            name = st.text_input("👤 Nombre completo *", placeholder="Juan García")
            phone = st.text_input("📱 Celular *", placeholder="300 000 0000")
            email = st.text_input("✉️ Correo electrónico *", placeholder="correo@ejemplo.com")
            city = st.selectbox("📍 Ciudad",
                ["Bogotá","Medellín","Cali","Barranquilla","Bucaramanga","Pereira","Cartagena"])
            password = st.text_input("🔑 Contraseña *", type="password",
                                     placeholder="Mínimo 8 caracteres")
            password2 = st.text_input("🔑 Confirmar contraseña *", type="password",
                                      placeholder="Repite tu contraseña")
            terms = st.checkbox("✅ Acepto los Términos y condiciones y la Política de privacidad")
            submitted = st.form_submit_button("🎉 Crear cuenta", use_container_width=True,
                                               type="primary")

            if submitted:
                errors = []
                if not name.strip(): errors.append("Nombre")
                if not email.strip(): errors.append("Correo")
                if not phone.strip(): errors.append("Celular")
                if not password: errors.append("Contraseña")
                if password != password2: errors.append("Las contraseñas no coinciden")
                if not terms: errors.append("Debes aceptar los términos")

                if errors:
                    st.error(f"❌ {' · '.join(errors)}")
                else:
                    st.session_state.logged_in = True
                    st.session_state.user_name = name
                    st.session_state.user_email = email
                    st.session_state.user_phone = phone
                    st.session_state.user_city = city
                    st.session_state.active_cities = [city]
                    st.session_state.page = "home"
                    st.success(f"🎉 ¡Cuenta creada con éxito! Bienvenido {name.split()[0]}")
                    st.rerun()

        st.divider()
        c1, c2 = st.columns(2)
        with c1:
            if st.button("🔐 Ya tengo cuenta", use_container_width=True, type="primary"):
                st.session_state.page = "login"; st.rerun()
        with c2:
            if st.button("🏠 Volver al inicio", use_container_width=True):
                st.session_state.page = "home"; st.rerun()

# ─── PAGE: FORGOT ────────────────────────────────────────────────────────────
def page_forgot():
    col_center = st.columns([1,2,1])[1]
    with col_center:
        st.markdown("## 🔓 Recuperar contraseña")
        st.caption("Ingresa tu correo y te enviaremos un enlace para restablecer tu contraseña.")
        with st.form("forgot_form"):
            email = st.text_input("✉️ Correo electrónico", placeholder="correo@ejemplo.com")
            if st.form_submit_button("📧 Enviar enlace", use_container_width=True, type="primary"):
                if email:
                    st.success("✅ Enlace enviado a tu correo")
                    st.session_state.page = "login"; st.rerun()
        if st.button("← Volver al login"):
            st.session_state.page = "login"; st.rerun()

# ─── PAGE: HELP ──────────────────────────────────────────────────────────────
def page_help():
    st.session_state.page = "support"
    st.rerun()

# ─── MAIN ROUTER ─────────────────────────────────────────────────────────────
sidebar_nav()

# Top header
st.markdown(f"""
<div style="background:linear-gradient(135deg,#C41E3A,#9B1729);color:#fff;
            padding:12px 20px;border-radius:14px;margin-bottom:20px;
            display:flex;align-items:center;justify-content:space-between;">
    <div>
        <span style="font-size:20px;font-weight:900;letter-spacing:3px;
                     font-family:'Arial Black',sans-serif;">🚗 JJGT</span>
        <span style="font-size:11px;opacity:0.7;margin-left:12px;letter-spacing:1px;">
            VEHÍCULOS COLOMBIA</span>
    </div>
    <div style="font-size:12px;opacity:0.75;">
        {'👤 ' + st.session_state.user_name if st.session_state.logged_in else '🔐 Sin sesión'}
        &nbsp;·&nbsp; 🌐 Colombia
    </div>
</div>""", unsafe_allow_html=True)

# Route
page = st.session_state.page
routes = {
    "home": page_home,
    "explore": page_explore,
    "vehicle_detail": page_vehicle_detail,
    "publish": page_publish,
    "history": page_history,
    "notifications": page_notifications,
    "support": page_support,
    "profile": page_profile,
    "profile_mydata": page_profile_mydata,
    "profile_cities": page_profile_cities,
    "profile_notifconfig": page_profile_notifconfig,
    "profile_privacy": page_profile_privacy,
    "profile_help": page_profile_help,
    "permutas": page_permutas,
    "login": page_login,
    "register": page_register,
    "forgot": page_forgot,
    "help": page_help,
}

if page in routes:
    routes[page]()
else:
    page_home()
