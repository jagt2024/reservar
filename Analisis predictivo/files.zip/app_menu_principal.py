"""
Ejemplo de aplicación principal con menú
Integra el traductor como una opción más del menú
"""

import streamlit as st
from traductor_modular import mostrar_traductor

# Configuración de la página
st.set_page_config(
    page_title="Mi Aplicación Multiherramienta",
    page_icon="🛠️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# ========== MENÚ LATERAL ==========
with st.sidebar:
    st.image("https://via.placeholder.com/150x50/4CAF50/FFFFFF?text=Mi+App", use_column_width=True)
    st.title("🛠️ Menú Principal")
    st.markdown("---")
    
    # Selector de página/opción
    opcion_menu = st.radio(
        "Selecciona una opción:",
        [
            "🏠 Inicio",
            "🌍 Traductor Multiidioma",
            "📊 Análisis de Datos",
            "📝 Editor de Texto",
            "⚙️ Configuración"
        ],
        index=0
    )
    
    st.markdown("---")
    st.info("👤 **Usuario:** Demo\n\n📅 **Fecha:** 2025")

# ========== CONTENIDO PRINCIPAL SEGÚN OPCIÓN SELECCIONADA ==========

if opcion_menu == "🏠 Inicio":
    st.title("🏠 Bienvenido a Mi Aplicación")
    st.markdown("---")
    
    st.write("### Selecciona una opción del menú lateral:")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.info("""
        **🌍 Traductor Multiidioma**
        
        Traduce texto entre Español, Inglés, Francés y Alemán.
        Soporta entrada de texto y documentos PDF/DOCX.
        Genera salida en texto y audio.
        """)
        
        st.success("""
        **📊 Análisis de Datos**
        
        Visualiza y analiza tus datos.
        Genera gráficos y reportes.
        """)
    
    with col2:
        st.warning("""
        **📝 Editor de Texto**
        
        Edita y formatea documentos.
        Exporta en múltiples formatos.
        """)
        
        st.error("""
        **⚙️ Configuración**
        
        Ajusta las preferencias de la aplicación.
        Gestiona tu cuenta.
        """)

elif opcion_menu == "🌍 Traductor Multiidioma":
    # AQUÍ SE INTEGRA EL TRADUCTOR
    mostrar_traductor()

elif opcion_menu == "📊 Análisis de Datos":
    st.title("📊 Análisis de Datos")
    st.markdown("---")
    st.info("Esta sección está en desarrollo...")
    
    # Aquí irían tus funciones de análisis de datos
    st.write("Próximamente: herramientas de análisis y visualización de datos")

elif opcion_menu == "📝 Editor de Texto":
    st.title("📝 Editor de Texto")
    st.markdown("---")
    st.info("Esta sección está en desarrollo...")
    
    # Aquí iría tu editor de texto
    st.write("Próximamente: editor de texto avanzado")

elif opcion_menu == "⚙️ Configuración":
    st.title("⚙️ Configuración")
    st.markdown("---")
    
    st.subheader("Preferencias de Usuario")
    tema = st.selectbox("Tema:", ["Claro", "Oscuro", "Auto"])
    idioma_app = st.selectbox("Idioma de la aplicación:", ["Español", "English"])
    
    st.markdown("---")
    
    st.subheader("Notificaciones")
    notif_email = st.checkbox("Recibir notificaciones por email")
    notif_push = st.checkbox("Recibir notificaciones push")
    
    st.markdown("---")
    
    if st.button("💾 Guardar Configuración"):
        st.success("✅ Configuración guardada correctamente!")

# ========== FOOTER ==========
st.markdown("---")
st.markdown(
    """
    <div style='text-align: center; color: gray; padding: 20px;'>
        <p>🛠️ Mi Aplicación Multiherramienta v1.0 | Desarrollado con Streamlit</p>
    </div>
    """,
    unsafe_allow_html=True
)
