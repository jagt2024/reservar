# 📘 Guía de Integración del Traductor

Esta guía te muestra cómo integrar el traductor multiidioma en tu aplicación Streamlit existente.

## 📁 Archivos Necesarios

1. **traductor_modular.py** - Módulo del traductor (función principal: `mostrar_traductor()`)
2. **requirements.txt** - Dependencias necesarias

## 🔧 Método 1: Integración Simple (Recomendado)

### Paso 1: Copiar el archivo del traductor
Coloca `traductor_modular.py` en la misma carpeta que tu aplicación principal.

### Paso 2: Importar en tu aplicación
En tu archivo principal (ej: `app.py` o `main.py`):

```python
import streamlit as st
from traductor_modular import mostrar_traductor

# Tu código existente...

# En la sección donde manejas las opciones del menú:
if opcion_seleccionada == "Traductor":
    mostrar_traductor()
```

### Paso 3: Instalar dependencias
```bash
pip install gtts googletrans==4.0.0rc1 PyPDF2 python-docx
```

## 🎯 Método 2: Integración con st.radio (Menú Lateral)

```python
import streamlit as st
from traductor_modular import mostrar_traductor

st.set_page_config(page_title="Mi App", layout="wide")

# Menú lateral
with st.sidebar:
    st.title("Menú")
    opcion = st.radio(
        "Selecciona:",
        ["Inicio", "Traductor", "Otra Opción"]
    )

# Mostrar contenido según opción
if opcion == "Inicio":
    st.title("Página de Inicio")
    # Tu código de inicio...

elif opcion == "Traductor":
    mostrar_traductor()  # ← Aquí se integra el traductor

elif opcion == "Otra Opción":
    st.title("Otra Funcionalidad")
    # Tu otro código...
```

## 🎨 Método 3: Integración con st.selectbox

```python
import streamlit as st
from traductor_modular import mostrar_traductor

st.set_page_config(page_title="Mi App", layout="wide")

# Menú en selectbox
opcion = st.sidebar.selectbox(
    "Selecciona una herramienta:",
    ["Selecciona...", "Traductor", "Análisis", "Reportes"]
)

if opcion == "Traductor":
    mostrar_traductor()
elif opcion == "Análisis":
    # Tu código de análisis...
    pass
# etc...
```

## 📋 Método 4: Integración con Tabs

```python
import streamlit as st
from traductor_modular import mostrar_traductor

st.title("Mi Aplicación Multifuncional")

tab1, tab2, tab3, tab4 = st.tabs(["📊 Dashboard", "🌍 Traductor", "📈 Reportes", "⚙️ Config"])

with tab1:
    st.header("Dashboard")
    # Tu código del dashboard...

with tab2:
    mostrar_traductor()  # ← Traductor en un tab

with tab3:
    st.header("Reportes")
    # Tu código de reportes...

with tab4:
    st.header("Configuración")
    # Tu código de configuración...
```

## 🔍 Método 5: Integración con Páginas Múltiples (Multipage App)

Si usas la estructura de páginas múltiples de Streamlit:

### Estructura de carpetas:
```
mi_app/
│
├── app.py                          # Archivo principal
├── traductor_modular.py            # Módulo del traductor
├── requirements.txt
│
└── pages/
    ├── 1_📊_Dashboard.py
    ├── 2_🌍_Traductor.py          # ← Página del traductor
    └── 3_📈_Reportes.py
```

### Contenido de `pages/2_🌍_Traductor.py`:
```python
import streamlit as st
import sys
sys.path.append('..')  # Para importar desde la carpeta padre

from traductor_modular import mostrar_traductor

st.set_page_config(page_title="Traductor", page_icon="🌍", layout="wide")

# Llamar directamente a la función
mostrar_traductor()
```

## 🎛️ Personalización Avanzada

### Cambiar el diseño de columnas
Si quieres que el traductor use el sidebar real en lugar de columnas:

En `traductor_modular.py`, modifica la función `mostrar_traductor()`:

```python
def mostrar_traductor():
    st.title("🌍 Traductor Multiidioma")
    
    # Usar sidebar real
    with st.sidebar:
        st.header("⚙️ Configuración del Traductor")
        idioma_seleccionado = st.selectbox(...)
        velocidad = st.slider(...)
    
    # Resto del código principal sin columnas...
```

### Agregar parámetros personalizados
```python
from traductor_modular import mostrar_traductor

# Puedes modificar la función para aceptar parámetros
def mi_traductor_personalizado():
    st.markdown("## Mi versión personalizada")
    mostrar_traductor()
```

## ⚠️ Consideraciones Importantes

1. **Keys únicos**: El traductor usa keys únicos para evitar conflictos (ej: `key="idioma_traductor"`). Si tienes otros componentes con keys similares, asegúrate de que no colisionen.

2. **Session State**: El traductor no usa `st.session_state` globalmente, por lo que cada vez que cambies de página/opción, se reinicia.

3. **Dependencias**: Asegúrate de instalar todas las dependencias antes de ejecutar.

4. **Conexión a Internet**: El traductor requiere conexión a internet para las APIs de Google.

## 🐛 Solución de Problemas

### Error: "No module named 'traductor_modular'"
- Asegúrate de que `traductor_modular.py` está en la misma carpeta que tu archivo principal
- O agrega la ruta: `sys.path.append('/ruta/a/la/carpeta')`

### Conflicto de keys
Si ves errores sobre keys duplicados, puedes agregar un prefijo en `traductor_modular.py`:
```python
key=f"{prefix}_idioma_traductor"
```

### El traductor se reinicia al cambiar de opción
Esto es normal en Streamlit. Si necesitas persistencia, implementa `st.session_state`.

## 📞 Soporte

Si tienes problemas con la integración:
1. Verifica que todos los imports estén correctos
2. Revisa que las dependencias estén instaladas
3. Comprueba los logs de errores en la terminal

---

**¡Listo para integrar!** 🚀
